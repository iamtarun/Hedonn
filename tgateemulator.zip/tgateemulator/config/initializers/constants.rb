module Shopkeep
  module RESPONSE
    TIMEOUT = {error_msg: "Time out"}
    CONNREFUSED = {error_msg: "Connection Refused"}
    PARSEERROR = {error_msg: "Error while parsing"}
    INVALIDTRANSTYPE = {Result: "2", RespMSG: "Transaction Type is invalid."}
    FAILURE = {Result: "99", RespMSG: "Unknown Transaction Failure."}
    FORBIDDEN_ATTRIBUTE = {Result: "403", RespMSG: "Forbidden"}
    PAYMENT_SERVER_EXCEPTION = {Result: "500", RespMSG: "Host internal error"}
  end

  module PaymentServer
    URLS = YAML.load(ERB.new(File.read Rails.application.config.paths['config/url_settings'].first).result)[Rails.env]
  end

  module EMULATETGATE
    VALIDTRANSTYPE = %w(Auth Sale Void Return Force Adjustment)
    PONUM = "//PONum"
    CUSTCODE = "//CustCode"
    REGISTERNUM = "//RegisterNum"
    SERVERID = "//ServerId"
    TAXAMT = "//TaxAmt"
    FORCE = "//Force"
    SECURITYINFO = "//SecurityInfo"
    TRACK1 = "//Track1"
    TRACK2 = "//Track2"
    TIPAMT= "//TipAmt"
  end

  module GetInfo
    VALIDTRANSTYPE = %w(StatusCheck Initialize)
  end
end
