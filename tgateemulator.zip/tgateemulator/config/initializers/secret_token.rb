# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Tgateemulator::Application.config.secret_token = '061cfd3c808ab16fcde453c1c4bb2e191659b1b09bd125002ca763bc9e964637321b199a27abfe53a3354e5c5e7624439f8c5d3a1857311112a1d641df63a309'
