Tgateemulator::Application.routes.draw do
  post '/transaction_processors/process_credit_card'
  post '/smart_payments/get_info'
end
