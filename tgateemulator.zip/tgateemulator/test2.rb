#!/usr/bin/env ruby
require "highline/import"

puts "#{`clear`}"
puts ARGV[0]
STDOUT.puts <<-EOF
Please Choose API -
--------------------------------------------------------------------------------
  1. Update Partner/ add to include username and password and remove auto generate 
  2. API Method:  User/ set
  3. API Method:  User/ get
  4. API Method:  Users/ get (array of users)
  5. Change User/ add to be specific to partner_key only and remove is_sys_admin component
  6. Emulate TGate Auth Request to SK Payment Server
  7. Pass through Proxy to Processor - Part 2: Response
  
EOF

puts '-------------------------------------------------------------------------------------'

input = ask "Input API Preferences [ 1 - 19] : "
case input
  when "1"
    say("<%= color( '****************** EXECUTING Update Partner add ********************** ', GREEN) %>")
    puts "#{` curl http://localhost:3000/api/admin/partners -v -H "Content-Type: application/json" -X POST -d '{"username":"nitin_misra", "password":"password@123", "partner": {"partner_name":"Shopkeep Partner", "contact_first_name":"Nitin", "contact_last_name":"Misra", "contact_title":"nitin", "contact_phone":"8884733565", "contact_email":"nitinm@chetu.com", "address_1":"Block A","address_2":"Sector 63", "city":"Noida", "zip":"261001", "partner_username":"shopkeep_123278", "partner_password":"12345678"}}'`}"
  when "2"
    say("<%= color( '****************** EXECUTING User set ********************** ', GREEN) %>")
    puts "#{`curl -v -H "Accept: application/json" -H "Content-type: application/json" -X PUT -d'{"username":"nitin_misra", "password":"password@123", "user":{"username":"chzxx31sdsdd21","password":"qwsddddd","contact_first_name":"sss", "contact_last_name":"sdfas", "contact_title":"asdasd","mobile_phone":"56654456456", "day_phone":"56654456456", "status":"Inactive"}}' http://localhost:3000/api/admin/users/6`}"
  when "3"
    say("<%= color( '****************** EXECUTING User GET ********************** ', GREEN) %>")
    puts "#{`curl http://localhost:3000/api/admin/users/1 -v -H "Content-Type: application/json" -X GET -d '{"username":"nitin_misra", "password":"password@123"}'`}"
  when "4"
    say("<%= color( '****************** EXECUTING Users get (array of users) ********************** ', GREEN) %>")
    puts "#{`curl http://localhost:3000/api/admin/users -v -H "Content-Type: application/json" -X GET -d '{"username":"nitin_misra", "password":"password@123"}'`}"
  when "5"
    say("<%= color( '****************** EXECUTING Changed User add ********************** ', GREEN) %>")
    puts "#{`curl -v -H "Accept: application/json" -H "Content-type: application/json" -X POST -d '{"username":"nitin_misra", "password":"password@123", "user":{"username":"chetuindia123","password":"wwwwwww","contact_first_name":"sss", "contact_last_name":"sdfas", "contact_title":"asdasd", "mobile_phone":"1234567", "day_phone":"56654456456", "contact_email":"asdasd@sjdh.com","partner_id":"1"}}' http://localhost:3000/api/admin/users`}"
  when "6"
    say("<%= color( '****************** EXECUTING Emulate TGate Auth ********************** ', GREEN) %>")
    puts "#{`curl -i -H "Content-Type: application/json" -X POST http://localhost:3000/transaction_processors/process_credit_card -d @doc/process_credit_card_auth_curl.json`}"
  when "7"
    say("<%= color( '****************** EXECUTING Pass through Proxy to Processor ********************** ', GREEN) %>")
    puts "#{`curl -i -H "Content-Type: application/json" -X POST http://localhost:3000/api/transaction_processes/process_credit_card -d @doc/process_credit_card_curl.json`}"
  else
    say(" <%= color( 'Invalid option. Please try again' , RED) %>!")
end
say("<%= color( '-------------------------------------------------------------------------------------', GREEN) %>")
