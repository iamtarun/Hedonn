require 'spec_helper'

describe GetInfo::Processor do
  
  let(:get_info_params) do
    {
      UserName: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
      Password: "who_broke_the_build?",
      TransType: "StatusCheck",
      ExtData: "<Ponum>123</Ponum>"
    }
  end
  
  describe 'fetch_info' do
    it "should return object of ResponseCreator when transaction type is valid" do
      response = GetInfo::Processor.new(get_info_params).fetch_info
      response.class.should == GetInfo::ResponseCreator
    end

    it "should return TgateEmulator::InvalidTransactionType class when" do
      response = GetInfo::Processor.new({ TransType: "Invalid" }).fetch_info
      response.should == TgateEmulator::InvalidTransactionType
    end
  end
end
