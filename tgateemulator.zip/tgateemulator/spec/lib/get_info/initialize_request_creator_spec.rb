require 'spec_helper'

describe GetInfo::InitializeRequestCreator do

  describe "get_info_hash" do

    it "should return data in hash to be used for canned response" do
      GetInfo::InitializeRequestCreator.new.get_info_hash.class == Hash
    end
  end
end
