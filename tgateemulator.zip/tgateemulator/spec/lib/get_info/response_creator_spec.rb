require 'spec_helper'

describe GetInfo::ResponseCreator do

  let(:expected_response_in_xml) do
    Nokogiri::XML::Builder.new { |xml|
      xml.Response("xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance",
       "xmlns:xsd"=>"http://www.w3.org/2001/XMLSchema", "xmlns"=>"http://TPISoft.com/SmartPayments") do
        xml.Result("0")
        xml.RespMSG("Approved")
        xml.ExtData("OK")
      end
    }.to_xml
  end

  describe "initialize" do

    response_creator = GetInfo::ResponseCreator.new({ 
      Result: "0", 
      RespMSG: "Approved", 
      ExtData: "OK" 
      })

    it "should set response attribute as Nokogiri::XML::Builder object" do
      response_creator.response.class == Nokogiri::XML::Builder
    end

    it "should set success attribute to true" do
      response_creator.success.should be_true
    end

    it "should gives same xml as expected_response_in_xml when response attribute converted to xml" do
      response_creator.response.to_xml.should == expected_response_in_xml
    end
  end
end
