require 'spec_helper'

describe TgateEmulator::Sanitizer do
  describe "change hash key to snake cash" do
    
    it "should change all key of hash into snake case key" do
      TgateEmulator::Sanitizer.change_hash_key_to_snake_case({NameOnCard: "ABC"}).has_key?(:name_on_card).should == true
    end  
  end
end