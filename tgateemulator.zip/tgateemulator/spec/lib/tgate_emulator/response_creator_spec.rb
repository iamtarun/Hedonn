require 'spec_helper'

describe TgateEmulator::ResponseCreator do

  let(:expected_response_when_success) do
    Nokogiri::XML::Builder.new { |xml|
      xml.Response("xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance", "xmlns:xsd"=>"http://www.w3.org/2001/XMLSchema", "xmlns"=>"http://TPISoft.com/SmartPayments") do
        xml.Result("0")
        xml.RespMSG("Approval")
        xml.AuthCode("000146")
        xml.PNRef("361")
        xml.HostCode("000")
        xml.GetAVSResult("N")
        xml.GetAVSResultTXT("No Match")
        xml.GetCVResult("N")
        xml.GetCVResultTXT("No Match")
        xml.ExtData("Token=344005550019,CardType=VISA")
      end          
    }.to_xml
  end

  let(:expected_response_when_declined) do
    Nokogiri::XML::Builder.new { |xml|
      xml.Response("xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance", "xmlns:xsd"=>"http://www.w3.org/2001/XMLSchema", "xmlns"=>"http://TPISoft.com/SmartPayments") do
        xml.Result("50")
        xml.RespMSG("Decline")
        xml.PNRef("365")
      end
    }.to_xml
  end

  describe "initialize" do

    it "should set response attribute as Nokogiri::XML::Builder object" do
      TgateEmulator::ResponseCreator.new(
        ResponseCreatorInputHash.when_process_credit_card_approved).
      response.class == Nokogiri::XML::Builder
    end

    describe "when process credit card response is Approval"  do

      response_creator = TgateEmulator::ResponseCreator.new(
        ResponseCreatorInputHash.when_process_credit_card_approved)

      it "should set success attribute to true" do
        response_creator.success.should be_true
      end

      it "should gives same xml as expected_response_when_success when response attribute converted to xml" do
        response_creator.response.to_xml.should == expected_response_when_success
      end
    end

    describe "when process credit card response is Declined"  do

      response_creator = TgateEmulator::ResponseCreator.new(
        ResponseCreatorInputHash.when_process_credit_card_declined)

      it "should set success attribute to false" do
        response_creator.success.should be_false
      end

      it "should gives same xml as expected_response_when_declined when response attribute converted to xml" do
        response_creator.response.to_xml.should == expected_response_when_declined
      end
    end
  end
end
