require 'spec_helper'

describe TgateEmulator::InvalidTransactionType do

  let(:expected_result_for_response) do 

    Nokogiri::XML::Builder.new { |xml|
      xml.Response("xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance", "xmlns:xsd"=>"http://www.w3.org/2001/XMLSchema", "xmlns"=>"http://TPISoft.com/SmartPayments") do
        xml.Result("2")
        xml.RespMSG("Transaction Type is invalid.")
      end
    }.to_xml 
  end

  describe "success" do

    it "should return false" do
      TgateEmulator::InvalidTransactionType.success.should be false
    end
  end

  describe "response" do

    it "should  return same xml as expected_result_for_response when converted to xml" do
      TgateEmulator::InvalidTransactionType.response.to_xml.should == expected_result_for_response
    end
  end
end
