require 'spec_helper'

describe TgateEmulator::ParamsExtractor do

  param_extarctor = TgateEmulator::ParamsExtractor.new("<RegisterNum>55647</RegisterNum><CustCode>567</CustCode>")

  describe "value of param" do

    it "should returns value of passed node" do
      param_extarctor.value_of_param(Shopkeep::EMULATETGATE::REGISTERNUM).should == "55647"
    end
  end

  describe "get purchase order value" do

    it "should returns value of PONum or CustCode whichever is present in extdata" do
      param_extarctor.get_purchase_order_value.should == "567"
    end

    it "should returns value of PONum if PONum and CustCode both exist in ext_data" do
      TgateEmulator::ParamsExtractor.new("<RegisterNum>55647</RegisterNum><CustCode>567
        </CustCode><PONum>1234567890</PONum>").get_purchase_order_value.should == "1234567890"
    end
  end
end