require 'spec_helper'

describe TgateEmulator::ProcessCreditCard do
  
  let(:auth_params) do
    ProcessCreditCardAuth.params
  end
  
  describe 'process credit card method valid transaction type' do
    it "should return object of ResponseCreator", :vcr do
      response = TgateEmulator::ProcessCreditCard.new(auth_params).process_credit_card
      response.class.should == TgateEmulator::ResponseCreator
    end
  end

  describe 'process credit card method for invalid transaction type' do
    it "should return TgateEmulator::InvalidTransactionType class" do
      auth_params[:TransType] = "XYZ"
      response = TgateEmulator::ProcessCreditCard.new(auth_params).process_credit_card
      response.should == TgateEmulator::InvalidTransactionType
    end
  end
end