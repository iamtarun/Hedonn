require 'spec_helper'

describe TgateEmulator::ReturnRequestCreator do
  
  let(:params) do
    ProcessCreditCardReturn.params
  end

  let(:expected_hash) do
    {
      request_params: {
        request_data: {
          transaction_reference: "152"
        },
        request_auth: {
         user_pass: {
            terminal_id: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
            password: "who_broke_the_build?",
          }
        }
      },
      requested_url: Shopkeep::PaymentServer::URLS["process_credit_card_returns_path"]
    }
  end

  let(:amount_hash) do
    {
      invoice: {
        total_amount: "5.00"
      }
    }        
  end

  describe "process credit card return hash" do
   
    it "returns a hash with amount key" do
      expected_hash[:request_params][:request_data].merge!(amount_hash)
      TgateEmulator::ReturnRequestCreator.new(TgateEmulator::Sanitizer.change_hash_key_to_snake_case(params)).process_credit_card_hash.should == expected_hash
    end

    it "returns a hash without total_amount key" do
      TgateEmulator::ReturnRequestCreator.new(TgateEmulator::Sanitizer.change_hash_key_to_snake_case(params.except(:Amount))).process_credit_card_hash.should == expected_hash
    end
  end
end