require 'spec_helper'

describe TgateEmulator::AuthRequestCreator do
  
  let(:params) do
    ProcessCreditCardAuth.params
  end

  let(:expected_common_hash) do
    {
      request_params: {
        request_data: {
          register_id: "55647",
          cashier_id: "12",
          invoice: {
            inv_num: "1",
            total_amount: "6.00",
            tax_amount: "0.2",
            bill_to: {
              purchase_order_number: "1234567890",
              name: "Chester Cheetos",
              address: {
                street: "301 Main Street",
                zip: "94105"
              }
            }
          },
          card: {
          },
          options: {
            override_duplicate: "T"
          }            
        },
        request_auth: {
        user_pass: {
          terminal_id: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
          password: "who_broke_the_build?",
        }
      }
    },
    requested_url: Shopkeep::PaymentServer::URLS["process_credit_card_auth_path"]
  }
  end

  let(:mag_data) do
    {
      swiped: {
        track2: ";4005550000000019=16101011000023456789?"
      }
    }
  end

  let(:auth_data) do
    {
      manual: {
        pan: "4005550000000019",
        expiration_date: "1213",
        cvv_number: "475"
      }
    }
  end

  let(:encoded_mag_data) do
    {
      encoded: {
        ksn: "234234B066AC7000004",
        enc_track1: "F800324F3922E7F14033B14910E72C3064F4803EC1F0827D0A2D675E590A1EC6C4AFE44DE7B51DF39E790C9CD3F343642810F883112C3F91",
        enc_track2: "49CB7CEA2329B8B51E446922CBE3B6AA00B311F51D1849B83688CF6BE28DEBBF523A4987F31E7758",
      }
    }
  end 

  describe "process credit card auth hash" do
   
    it "returns a request hash for auth with manual node inside card" do
      expected_common_hash[:request_params][:request_data][:card].merge!(auth_data)
      TgateEmulator::AuthRequestCreator.new(TgateEmulator::Sanitizer.change_hash_key_to_snake_case(params)).process_credit_card_hash.should == expected_common_hash
    end

    it "returns a request hash for auth with swiped node inside card when mag data is present" do
      expected_common_hash[:request_params][:request_data][:card].merge!(mag_data)
      params.merge!(ProcessCreditCardAuth.mag_data_params)
      TgateEmulator::AuthRequestCreator.new(TgateEmulator::Sanitizer.change_hash_key_to_snake_case(params)).process_credit_card_hash.should == expected_common_hash
    end

    it "returns a request hash for auth with encoded node inside card when security info is present" do
      expected_common_hash[:request_params][:request_data][:card].merge!(encoded_mag_data)
      params.merge!(ProcessCreditCardAuth.encoded_mag_data_params)
      TgateEmulator::AuthRequestCreator.new(TgateEmulator::Sanitizer.change_hash_key_to_snake_case(params)).process_credit_card_hash.should == expected_common_hash
    end
  end
end