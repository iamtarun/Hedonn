require 'spec_helper'

describe TgateEmulator::RequestAuthCreator do

  describe "build_request_auth_hash" do

    let(:expected_result_hash) do
      {
        user_pass: {
          terminal_id: "username",
          password: "password",
        }
      }     
    end
   
    it "returns a hash with terminal_id and password" do
      TgateEmulator::RequestAuthCreator.build_request_auth_hash("username","password").should == expected_result_hash
    end
  end
end