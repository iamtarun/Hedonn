require 'spec_helper'

describe TgateEmulator::ForceRequestCreator do

  describe "process credit card hash" do
   
    it "returns a hash for process credit card force for payment server" do
      expected_hash = {
        request_params: {
          request_data: {
            transaction_reference: "259",
            invoice: {
              total_amount: "6.00",
              tip_amount: "0.2"
            },
            options: {
              override_duplicate: "T"
            }            
          },
          request_auth: {
            user_pass: {
              terminal_id: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
              password: "who_broke_the_build?",
            }
          }
        },
        requested_url: Shopkeep::PaymentServer::URLS["process_credit_card_force_path"]
      }

      TgateEmulator::ForceRequestCreator.new(TgateEmulator::Sanitizer.change_hash_key_to_snake_case(ProcessCreditCardForce.params)).process_credit_card_hash.should == expected_hash
    end
  end
end