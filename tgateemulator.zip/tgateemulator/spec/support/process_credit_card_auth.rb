class ProcessCreditCardAuth
    def self.params
    {
      UserName: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
      Password: "who_broke_the_build?",
      TransType: "Auth",
      CardNum: "4005550000000019",
      ExpDate: "1213",
      NameOnCard: "Chester Cheetos",
      Amount: "6.00",
      InvNum: "1",
      Zip: "94105",
      Street: "301 Main Street",
      CVNum: "475",
      ExtData: "<TaxAmt>0.2</TaxAmt><ServerId>12</ServerId><Force>T</Force>
        <RegisterNum>55647</RegisterNum><PONum>1234567890</PONum>"
    }
  end

  def self.mag_data_params
    {
      MagData: ";4005550000000019=16101011000023456789?"
    }
  end

  def self.encoded_mag_data_params
    {
      ExtData: "<Track1>F800324F3922E7F14033B14910E72C3064F4803EC1F0827D0A2D675E590A1EC6C4AFE44DE7B51DF39E790C9CD3F343642810F883112C3F91</Track1>
        <Track2>49CB7CEA2329B8B51E446922CBE3B6AA00B311F51D1849B83688CF6BE28DEBBF523A4987F31E7758</Track2>
        <TaxAmt>0.2</TaxAmt><ServerId>12</ServerId><CustCode>1234567890</CustCode>
        <Force>T</Force><RegisterNum>55647</RegisterNum><PONum>1234567890</PONum>
        <SecurityInfo>234234B066AC7000004</SecurityInfo>"
    }
  end
end