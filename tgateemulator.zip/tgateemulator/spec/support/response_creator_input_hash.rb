class ResponseCreatorInputHash

  def self.when_process_credit_card_approved
    {
      "response_id"=>"361",
      "response_data"=>{
        "transaction_reference"=>"361",
        "result"=>"0",
        "message"=>"Approval",
        "authorization_code"=>"000146",
        "host_reference"=>"000",
        "amount"=>"6.00",
        "card"=>{
          "card_type"=>"VISA",
          "token"=>"344005550019"
        },
        "cvv"=>{
          "code"=>"N",
          "match"=>"No Match"
        },
        "avs"=>{
          "code"=>"N",
          "match"=>"No Match"
        },
        "receipt_data"=>""
      }
    }    
  end

  def self.when_process_credit_card_declined
  {
    "result"=> {
      "transaction_reference"=>"365",
      "result_code"=>"50",
      "result_message"=>"Decline"
    }
  }
  end
end