class ProcessCreditCardVoid
  def self.params
    {
      UserName: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
      Password: "who_broke_the_build?",
      PNRef: "146",
      TransType: "Void",
      Amount: "6.00",
      ExtData: "<Force>T</Force>"
    }
  end
end