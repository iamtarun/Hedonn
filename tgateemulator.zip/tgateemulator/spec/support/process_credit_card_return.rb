class ProcessCreditCardReturn
  def self.params
    {
      UserName: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
      Password: "who_broke_the_build?",
      PNRef: "152",
      TransType: "Return",
      Amount: "5.00"
    }
  end
end