class ProcessCreditCardAdjustment
  def self.params
    {
      UserName: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
      Password: "who_broke_the_build?",
      PNRef: "267",
      TransType: "Adjustment",
      ExtData: "<TipAmt>0.2</TipAmt><ServerId>12</ServerId>
        <Force>T</Force><RegisterNum>55647</RegisterNum>"
    }
  end
end