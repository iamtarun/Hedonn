require 'spec_helper'

describe SmartPaymentsController do

  let(:get_info_params) do
    {
      UserName: "D3330B8B-B1D2-4EEE-A5B2-085720652C0A",
      Password: "who_broke_the_build?",
      TransType: "StatusCheck",
      ExtData: "<Ponum>123</Ponum>"
    }
  end

  describe "get info" do
    describe "when TransType is StatusCheck" do
      it "should render xml content with response code 200" do
        post :get_info, get_info_params
        response.response_code.should == 200      
        response.headers['Content-Type'].should == "application/xml; charset=utf-8"
      end
    end

    describe "when TransType is not StatusCheck" do
      it "should render xml content with response code 400" do
        post :get_info, { TransType: "Invalid" }
        response.response_code.should == 400      
        response.headers['Content-Type'].should == "application/xml; charset=utf-8"
      end
    end
  end
end