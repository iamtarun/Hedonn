require 'spec_helper'

describe TransactionProcessorsController do

  let(:process_credit_card_params) do
    ProcessCreditCardAuth.params
  end

  describe "process credit card's trasaction" do
    it "should process credit card for transaction type auth", :vcr do
      post :process_credit_card, process_credit_card_params
      response.response_code.should == 200      
      response.headers['Content-Type'].should == "application/xml; charset=utf-8"
    end

    it "should render process_credit_card_unsuccess for decline transaction", :vcr do
      post :process_credit_card, process_credit_card_params.merge({CardNum: "400555000000001"})
      response.response_code.should == 400      
      response.headers['Content-Type'].should == "application/xml; charset=utf-8"
    end
  end
end