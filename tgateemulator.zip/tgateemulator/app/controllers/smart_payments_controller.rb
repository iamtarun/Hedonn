class SmartPaymentsController < ApplicationController
  WHITELIST_FIELDS = [:UserName, :Password, :TransType, :ExtData]

  def get_info
    @pcc_response = GetInfo::Processor.new(get_info_params).fetch_info
    if @pcc_response.success
      render xml: @pcc_response.response.to_xml , status: 200
    else
      render xml: @pcc_response.response.to_xml , status: 400
    end
  end

  private

  def get_info_params
    params.permit(*WHITELIST_FIELDS)
  end
end
