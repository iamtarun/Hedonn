class ApplicationController < ActionController::Base
  protect_from_forgery

  rescue_from JSON::ParserError, with: :parsing_error
  rescue_from Errno::ECONNREFUSED, with: :connection_error
  rescue_from Timeout::Error, with: :time_out_error

  private

  def parsing_error
    render :parsing_error, status: 400
  end

  def connection_error
    render :connection_error, status: 400
  end

  def time_out_error
    render :time_out_error, status: 400
  end  
end
