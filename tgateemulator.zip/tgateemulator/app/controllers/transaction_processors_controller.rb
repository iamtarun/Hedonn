class TransactionProcessorsController < ApplicationController
  WHITELIST_FIELDS = [:UserName, :Password, :TransType, :CardNum,
    :ExpDate, :MagData, :NameOnCard, :Amount, :InvNum, :Zip,
    :Street, :CVNum, :ExtData, :PNRef
  ]

rescue_from CustomException::PaymentServerResponseIsNil, with: :nil_response_recieved
rescue_from CustomException::PaymentServerException, with: :payment_server_exception

  def process_credit_card
    begin
      @pcc_response = TgateEmulator::ProcessCreditCard.new(process_credit_card_params).process_credit_card
      
      if @pcc_response.success
        render xml: @pcc_response.response.to_xml, status: 200
      else
        render xml: @pcc_response.response.to_xml, status: 400
      end
    rescue CustomException::RequiredParameterMissing => exception
      @error_message = exception.message
      render :parameter_missing, status: 400
    end
  end

  private

  def process_credit_card_params
    params.permit(*WHITELIST_FIELDS)
  end

  def nil_response_recieved
    render xml: TgateEmulator::ForbiddenResponse.response.to_xml, status: 403
  end

  def payment_server_exception
    render xml: TgateEmulator::PaymentServerException.response.to_xml, status: 400
  end
end
