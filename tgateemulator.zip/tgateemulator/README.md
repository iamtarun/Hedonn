tgateemulator
=============

T-Gate Emulator

## Running the application

In order to run the application:

  1. SK payment server should be running at port 8000.
  2. SK cvault server should be running at port 3001.
  3. SK decryption service should be running at port 3002 for encoded magdata request.

## API Endpoints and Sample Requests

### ProcessCreditCard Auth

```
$ curl -i -H -X http://localhost:3000/transaction_processors/process_credit_card -d @doc/process_credit_card_auth.txt

HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "e9ed682ebb221708f11c17c99bc9c195"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 1f61d0e2c5cfd2bbe4031bdb3f142902
X-Runtime: 7.998000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Mon, 03 Jun 2013 18:05:44 GMT
Content-Length: 418
Connection: Keep-Alive
Set-Cookie: _tgateemulator_session=BAh7BkkiD3Nlc3Npb25faWQGOgZFRkkiJTg3MmU2Y2E2MmVmZWI4YmY3Y2I3ZjM1MjAyNWI2ODRiBjsAVA%3D%3D--6139579f8aaa6ce2f228a64914ca1c249d74d900; path=/; HttpOnly

<?xml version="1.0" encoding="UTF-8"?>
<Response xmlns="http://TPISoft.com/SmartPayments" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Result>0</Result>
  <RespMSG>Approval</RespMSG>
  <AuthCode>000149</AuthCode>
  <PNRef>19</PNRef>
  <HostCode>000</HostCode>
  <GetAVSResult>N</GetAVSResult>
  <GetAVSResultTXT>No Match</GetAVSResultTXT>
  <ExtData>Token=24005550019,CardType=VISA</ExtData>
</Response>
```

Other options:

* If you want to use magdata, replace the txt file with `doc/process_credit_card_auth_with_magdata.txt`
* If you want to use encoded magdata, replace the txt file with `doc/process_credit_card_auth_with_encoded_magdata.txt`

### ProcessCreditCard Sale

```
$ curl -i -H -X http://localhost:3000/transaction_processors/process_credit_card -d @doc/process_credit_card_sale.txt

HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "3b33c522d5449be433cdea6a14352224"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 6be4767def17a880c71e941b40c3c0cf
X-Runtime: 59.823000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Thu, 06 Jun 2013 12:07:08 GMT
Content-Length: 416
Connection: Keep-Alive
Set-Cookie: _tgateemulator_session=BAh7BkkiD3Nlc3Npb25faWQGOgZFRkkiJWQ4NGRjNGE4OGI5ZWRkM2U5MzI0NzUxMjQzYTQyMmU0BjsAVA%3D%3D--0c3170404f7f15c229f92fbd95a872cb7b9d4991; path=/; HttpOnly

<?xml version="1.0" encoding="UTF-8"?>
<Response xmlns="http://TPISoft.com/SmartPayments" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Result>0</Result>
  <RespMSG>Approval</RespMSG>
  <AuthCode>000219</AuthCode>
  <PNRef>386</PNRef>
  <HostCode>008</HostCode>
  <GetAVSResult>N</GetAVSResult>
  <GetAVSResultTXT>No Match</GetAVSResultTXT>
  <GetCVResult>N</GetCVResult>
  <GetCVResultTXT>No Match</GetCVResultTXT>
  <ExtData>Token=24005550019,CardType=VISA</ExtData>
</Response>
```

Other options:

* If you want to use magdata, replace the txt file with `doc/process_credit_card_sale_with_magdata.txt`
* If you want to use encoded magdata, replace the txt file with `doc/process_credit_card_sale_with_encoded_magdata.txt`

### ProcessCreditCard Void

```
$ curl -i -H -X http://localhost:3000/transaction_processors/process_credit_card -d @doc/process_credit_card_void.txt

HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "10dccf0f9fedebea84bcc12050a3720f"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: fd13f8321b58da08f8616fec87e6b41e
X-Runtime: 13.501000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Thu, 06 Jun 2013 13:10:51 GMT
Content-Length: 215
Connection: Keep-Alive
Set-Cookie: _tgateemulator_session=BAh7BkkiD3Nlc3Npb25faWQGOgZFRkkiJTBjYTVjNmMzODJhZWVmZmQ1MDQ2Y2I0NDg0NThjMTdjBjsAVA%3D%3D--029ac9deebf64446fd23f0c14095cb384b4d3f1c; path=/; HttpOnly

<?xml version="1.0" encoding="UTF-8"?>
<Response xmlns="http://TPISoft.com/SmartPayments" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Result>0</Result>
  <RespMSG>Approval</RespMSG>
  <PNRef>387</PNRef>
  <HostCode>008</HostCode>
</Response>
```

### ProcessCreditCard Return

```
curl -i -H -X http://localhost:3000/transaction_processors/process_credit_card -d @doc/process_credit_card_return.txt

$ HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "10791fd8a0b79e46b76fe7d6fd2be078"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 98bb1df6c5bcee12b2bf7db4fc415690
X-Runtime: 9.752000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Fri, 07 Jun 2013 13:14:37 GMT
Content-Length: 217
Connection: Keep-Alive
Set-Cookie: _tgateemulator_session=BAh7BkkiD3Nlc3Npb25faWQGOgZFRkkiJTEzMGY1NjE2MmZjYTY3MjZkMjU0N2ZhY2YxM2Y1OGVhBjsAVA%3D%3D--ef6376a1eb6646f2e18b20c932a85332ab859768; path=/; HttpOnly

<?xml version="1.0" encoding="UTF-8"?>
<Response xmlns="http://TPISoft.com/SmartPayments" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Result>0</Result>
  <RespMSG>Approval</RespMSG>
  <PNRef>389</PNRef>
  <HostCode>010</HostCode>
</Response>
```

Other options:

* If you want to provide amount in request, replace the txt file with `doc/process_credit_card_return_with_amount.txt`

### ProcessCreditCard Force

```
curl -i -H -X http://localhost:3000/transaction_processors/process_credit_card -d @doc/process_credit_card_force.txt

HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "ee61e5be4aadf221439d0186063c0488"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ebc5dbd0d766c2bb39a48341ecf960cb
X-Runtime: 10.038000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Mon, 17 Jun 2013 12:36:48 GMT
Content-Length: 224
Connection: Keep-Alive
Set-Cookie: _tgateemulator_session=BAh7BkkiD3Nlc3Npb25faWQGOgZFRkkiJTYxYzhmODY0YjQ0NmMxNDE4ZThkZTZiNDdhMzVjMmUyBjsAVA%3D%3D--8f0adab8de66bfbbafc0efb3d1e120a3ff126acb; path=/; HttpOnly

<?xml version="1.0" encoding="UTF-8"?>
<Response xmlns="http://TPISoft.com/SmartPayments" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Result>0</Result>
  <RespMSG>Approval</RespMSG>
  <AuthCode>000218</AuthCode>
  <PNRef>390</PNRef>
  <HostCode>011</HostCode>
</Response>
```

### ProcessCreditCard Adjustment

```
curl -i -H -X http://localhost:3000/transaction_processors/process_credit_card -d @doc/process_credit_card_adjustment.txt

HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "4f79084cfff0f4bcb396d3fc6672ef3e"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 566ace26c891e7b4456409f8af6c6653
X-Runtime: 27.997000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Mon, 17 Jun 2013 13:32:31 GMT
Content-Length: 213
Connection: Keep-Alive
Set-Cookie: _tgateemulator_session=BAh7BkkiD3Nlc3Npb25faWQGOgZFRkkiJTk4ZDUxZjY4YzUxMDczOTkwZjMwYTZjMWJhNTFhNWY4BjsAVA%3D%3D--952cd1e74771cd3917d32c0f5c88519e389f8160; path=/; HttpOnly

<?xml version="1.0" encoding="UTF-8"?>
<Response xmlns="http://TPISoft.com/SmartPayments" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Result>0</Result>
  <RespMSG>Approval</RespMSG>
  <PNRef>392</PNRef>
</Response>
```

### GetInfo StatusCheck 

```
curl -i -H -X http://localhost:3000/smart_payments/get_info -d "UserName=D3330B8B-B1D2-4EEE-A5B2-085720652C0A&Password=who_broke_the_build?&TransType=StatusCheck&ExtData=<Ponum>123</Ponum>"

HTTP/1.1 200 OK
Content-Type: application/xml; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "141af5826450b30d3eb41ea664989363"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: d8f9aabd5e6b4b8f2a352fb29b95d911
X-Runtime: 0.019000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Fri, 21 Jun 2013 17:18:27 GMT
Content-Length: 260
Connection: Keep-Alive
Set-Cookie: _tgateemulator_session=BAh7BkkiD3Nlc3Npb25faWQGOgZFRkkiJTJlYWQ1M2FmODBlMDdhMTFlZTFmYzY2ZjYyMDBkNDZiBjsAVA%3D%3D--370353cbbf483a8e1a68d5fb3f6d767f68ac4548; path=/; HttpOnly

<?xml version="1.0"?>
<Response xmlns="http://TPISoft.com/SmartPayments" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Result>0</Result>
  <RespMSG>Approved</RespMSG>
  <ExtData>OK</ExtData>
</Response>
```

### GetInfo Initialize

```
curl -i -H -X http://localhost:3000/smart_payments/get_info -d "UserName=D3330B8B-B1D2-4EEE-A5B2-085720652C0A&Password=who_broke_the_build?&TransType=Initialize&ExtData=<Ponum>123</Ponum>"

HTTP/1.1 200 OK
Content-Type: application/xml; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "703d8b9bd32e3d1f0a93d0193b0936f4"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: bae71b5fa869155002d66fdd10a56d7a
X-Runtime: 0.031000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Mon, 24 Jun 2013 12:18:17 GMT
Content-Length: 3439
Connection: Keep-Alive
Set-Cookie: _tgateemulator_session=BAh7BkkiD3Nlc3Npb25faWQGOgZFRkkiJWQzNDNiNTVmYWFmMTc5YTM2MGQ0OWMzNmVlZWUzMTZmBjsAVA%3D%3D--e593ab0cbec26ab131d2371b9e0f8e56ce06401c; path=/; HttpOnly

<?xml version="1.0"?>
<Response xmlns="http://TPISoft.com/SmartPayments" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <Result>0</Result>
  <RespMSG>Approved</RespMSG>
  <ExtData>&lt;Partner&gt;187&lt;/Partner&gt;&lt;Vendor&gt;568&lt;/Vendor&gt;&lt;MerchantID&gt;&lt;/MerchantID&gt;&lt;PinPadKeyManagement&gt;1&lt;/PinPadKeyManagement&gt;&lt;LiveURL&gt;https://www.richsolutions.com&lt;/LiveURL&gt;&lt;LiveURL1&gt;https://www1.richsolutions.com&lt;/LiveURL1&gt;&lt;TestURL&gt;https://test.richsolutions.com&lt;/TestURL&gt;&lt;TestURL1&gt;https://test.richsolutions.com&lt;/TestURL1&gt;&lt;EPSPay&gt;/pay/payxml.aspx&lt;/EPSPay&gt;&lt;EPSLogin&gt;/RichAdmin/login.aspx&lt;/EPSLogin&gt;&lt;Phone1&gt;425-868-0364&lt;/Phone1&gt;&lt;Phone2&gt;425-868-0364&lt;/Phone2&gt;&lt;Auto_Close_Batch&gt;Y&lt;/Auto_Close_Batch&gt;&lt;DebitCard&gt;Y&lt;/DebitCard&gt;&lt;EGC&gt;Y&lt;/EGC&gt;&lt;CreditCard&gt;Y&lt;/CreditCard&gt;&lt;PaymentTypes&gt;&lt;CardType&gt;Amex&lt;/CardType&gt;&lt;CardType&gt;Diners&lt;/CardType&gt;&lt;CardType&gt;Discover&lt;/CardType&gt;&lt;CardType&gt;Mastercard&lt;/CardType&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;/PaymentTypes&gt;&lt;ExpressPay&gt;&lt;CardType&gt;MasterCard&lt;/CardType&gt;&lt;LTAmount&gt;25&lt;/LTAmount&gt;&lt;Amount&gt;0&lt;/Amount&gt;&lt;EntryMethod&gt;S&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;N&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;MasterCard&lt;/CardType&gt;&lt;LTAmount&gt;25&lt;/LTAmount&gt;&lt;Amount&gt;0&lt;/Amount&gt;&lt;EntryMethod&gt;M&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;MasterCard&lt;/CardType&gt;&lt;LTAmount&gt;0&lt;/LTAmount&gt;&lt;Amount&gt;25&lt;/Amount&gt;&lt;EntryMethod&gt;S&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;MasterCard&lt;/CardType&gt;&lt;LTAmount&gt;0&lt;/LTAmount&gt;&lt;Amount&gt;25&lt;/Amount&gt;&lt;EntryMethod&gt;M&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;LTAmount&gt;25&lt;/LTAmount&gt;&lt;Amount&gt;0&lt;/Amount&gt;&lt;EntryMethod&gt;S&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;N&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;LTAmount&gt;25&lt;/LTAmount&gt;&lt;Amount&gt;0&lt;/Amount&gt;&lt;EntryMethod&gt;M&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;LTAmount&gt;0&lt;/LTAmount&gt;&lt;Amount&gt;25&lt;/Amount&gt;&lt;EntryMethod&gt;S&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;LTAmount&gt;0&lt;/LTAmount&gt;&lt;Amount&gt;25&lt;/Amount&gt;&lt;EntryMethod&gt;M&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;</ExtData>
</Response>
```