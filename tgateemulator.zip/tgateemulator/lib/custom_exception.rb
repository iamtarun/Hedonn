module CustomException
  class PaymentServerResponseIsNil < StandardError; end

  class PaymentServerException < StandardError; end

  class RequiredParameterMissing < StandardError
    attr_accessor :object

    def initialize(message = nil, object = nil)
      super(message)
      self.object = object
    end
  end
end