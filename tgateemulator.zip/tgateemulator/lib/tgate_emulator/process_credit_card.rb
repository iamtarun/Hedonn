module TgateEmulator
  class ProcessCreditCard
    include HTTParty
    
    attr_accessor :params

    def initialize(params = {})
      @params = Sanitizer.change_hash_key_to_snake_case(params)
    end

    def process_credit_card
      filter_request_on_trans_type
    end

    private

    def filter_request_on_trans_type
      valid_trans_type? ? send_request : InvalidTransactionType
    end

    def send_request
      request_data = "TgateEmulator::#{params[:trans_type].classify}RequestCreator".constantize.new(@params).process_credit_card_hash
      response_data = self.class.post(request_data[:requested_url], body: request_data[:request_params])
      check_response_valid(response_data)
      ResponseCreator.new(response_data.to_hash)
    end

    def valid_trans_type?
      Shopkeep::EMULATETGATE::VALIDTRANSTYPE.include? params[:trans_type]
    end

    def check_response_valid(response_object)
      raise CustomException::PaymentServerResponseIsNil if response_object.parsed_response.nil?
      raise CustomException::RequiredParameterMissing.new(response_object.parsed_response, self) if response_object.parsed_response.include?("Required parameter missing")
      raise CustomException::PaymentServerException if response_object.body.include?("Exception caught")      
    end
  end
end
