module TgateEmulator
  class ResponseCreator
    RESPONSE_MAPPING_TO_TGATE = { Result: "result", RespMSG: "message", AuthCode: "authorization_code",
      PNRef: "transaction_reference", HostCode: "host_reference",GetAVSResult: "avs_code",
      GetAVSResultTXT: "avs_match", GetCVResult: "cvv_code", GetCVResultTXT: "cvv_match" }

    RESPONSE_MAPPING_TO_TGATE_FOR_EXTDATA = { ReceiptData: "receipt_data", Token: "card_token",
      CardType: "card_card_type" }

    RESPONSE_MAPPING_TO_TGATE_FOR_DECLINED_REQUEST = { Result: "result_code", RespMSG: "result_message",
      PNRef: "transaction_reference" }

    attr_accessor :response_data, :success, :response

    def initialize(response_data = {})
      @response_data = response_data.has_key?("response_data") ? response_data["response_data"] : response_data["result"]
      build_response
    end

    private

    def build_response
      @response_data.has_key?("result") ? reconstruct_response_as_tgate_format(bring_each_node_at_root) : 
      reconstruct_response_as_tgate_format_for_declined_request
    end

    def bring_each_node_at_root
      resulted_hash = {}

      @response_data.each do|key, value|
        if value.is_a?(Hash)
          value.each do|inner_key, inner_value|
            resulted_hash.merge!({ key + "_" + inner_key => inner_value })
          end
        else
          resulted_hash.merge!({ key => value })
        end
      end
      resulted_hash
    end

    def reconstruct_response_as_tgate_format(input_hash)
      @rebuilded_hash = input_hash
      resulted_hash={}
      self.success = true

      RESPONSE_MAPPING_TO_TGATE.each do |key, value|
        resulted_hash.merge!({ key=>@rebuilded_hash[value] }) if value_present_for_key(value)
      end

      self.response = Nokogiri::XML::Builder.new { |xml|
        xml.Response("xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance", "xmlns:xsd"=>"http://www.w3.org/2001/XMLSchema", "xmlns"=>"http://TPISoft.com/SmartPayments") do
          resulted_hash.each { |key,value| xml.send key, value }
          if ext_data_exist
            xml.ExtData(build_ext_data)
          end       
        end
      }
    end

    def reconstruct_response_as_tgate_format_for_declined_request
      @rebuilded_hash = @response_data
      self.success = false
      
      self.response = Nokogiri::XML::Builder.new { |xml|
        xml.Response("xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance", "xmlns:xsd"=>"http://www.w3.org/2001/XMLSchema", "xmlns"=>"http://TPISoft.com/SmartPayments") do
          RESPONSE_MAPPING_TO_TGATE_FOR_DECLINED_REQUEST.each do |key, value|
            xml.send key, @rebuilded_hash[value] if value_present_for_key(value)
          end
        end
      }
    end

    def value_present_for_key(value)
      @rebuilded_hash.has_key?(value) && !@rebuilded_hash[value].blank?
    end
    
    def ext_data_exist
      RESPONSE_MAPPING_TO_TGATE_FOR_EXTDATA.each do |key, value|
        return true  if value_present_for_key(value)
      end
      false
    end

    def build_ext_data
      ext_result = ""
      RESPONSE_MAPPING_TO_TGATE_FOR_EXTDATA.each do |key, value|
        ext_result += "#{key.to_s}=#{@rebuilded_hash[value]}," if value_present_for_key(value)
      end
      ext_result.chop
    end
  end 
end
