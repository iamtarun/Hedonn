module TgateEmulator
  class PaymentServerException
    @@response = Nokogiri::XML::Builder.new { |xml|
      xml.Response("xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance", "xmlns:xsd"=>"http://www.w3.org/2001/XMLSchema", "xmlns"=>"http://TPISoft.com/SmartPayments") do
        Shopkeep::RESPONSE::PAYMENT_SERVER_EXCEPTION.each do |key, value|
          xml.send key, value
        end
      end
    }

    def self.response
      @@response
    end
  end
end
