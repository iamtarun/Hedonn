module TgateEmulator
  class ReturnRequestCreator
    attr_accessor :user_name, :password, :amount, :pn_ref

    def initialize(params = {})
      filter_unnecessary_fields(params).each do |name,value|
        public_send("#{name}=",value)
      end
    end

    def process_credit_card_hash
      {
        request_params: build_request_hash,
        requested_url: Shopkeep::PaymentServer::URLS["process_credit_card_returns_path"]
      }
    end

    private

    def build_request_hash
      request_hash = {
        request_data: {
          transaction_reference: self.pn_ref
        },
        request_auth: RequestAuthCreator.build_request_auth_hash(self.user_name,self.password)
      }

      request_hash[:request_data].merge!({invoice: {total_amount: self.amount}}) unless self.amount.nil?
      request_hash
    end

    def filter_unnecessary_fields(params = {})
      params.extract!(:user_name, :password, :amount, :pn_ref)
    end
  end
end