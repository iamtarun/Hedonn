module TgateEmulator
  module Sanitizer

    def self.change_hash_key_to_snake_case(params)      
      params.map do |key, value|
        {key.to_s.underscore.to_sym=>value}
      end.inject({},&:merge!)
    end
  end
end