module TgateEmulator
  class SaleRequestCreator
    attr_accessor :user_name, :password, :card_num, :exp_date, :mag_data,
      :name_on_card, :amount, :inv_num, :zip, :street, :cv_num, :ext_data

    def initialize(params = {})
      filter_unrequired_fields(params).each do |name,value|
        public_send("#{name}=",value)
      end

      @params_extractor = ParamsExtractor.new(self.ext_data)
    end

    def process_credit_card_hash
      {
        request_params: build_request_hash,
        requested_url: Shopkeep::PaymentServer::URLS["process_credit_card_sale_path"]
      }
    end

    private

    def filter_unrequired_fields(params = {})
      params.extract!(:user_name, :password, :card_num, :exp_date, :mag_data,
        :name_on_card, :amount, :inv_num, :zip, :street, :cv_num, :ext_data)
    end

    def parse_purchase_order
      ponum = @params_extractor.value_of_param(Shopkeep::EMULATETGATE::PONUM) unless self.ext_data.blank?
      return ponum unless ponum.blank?
      self.ext_data.blank? ? "" : @params_extractor.value_of_param(Shopkeep::EMULATETGATE::CUSTCODE)
    end

    def build_request_hash
      request_hash = {
        request_data: {
          register_id: @params_extractor.value_of_param(Shopkeep::EMULATETGATE::REGISTERNUM),
          cashier_id: @params_extractor.value_of_param(Shopkeep::EMULATETGATE::SERVERID),
          invoice: {
            inv_num: self.inv_num,
            total_amount: self.amount,
            tax_amount: @params_extractor.value_of_param(Shopkeep::EMULATETGATE::TAXAMT),
            bill_to: {
              purchase_order_number:  @params_extractor.get_purchase_order_value,
              name: self.name_on_card,
              address: {
                street: self.street,
                zip: self.zip
              }
            }
          },
          card: {
          },
          options: {
            override_duplicate: @params_extractor.value_of_param(Shopkeep::EMULATETGATE::FORCE)
          }
        },
        request_auth: RequestAuthCreator.build_request_auth_hash(self.user_name,self.password)
      }

      request_hash[:request_data][:card].merge!(add_card_hash) 
      request_hash
    end

    def add_card_hash
      return sale_with_encoded_mag_data unless @params_extractor.value_of_param(Shopkeep::EMULATETGATE::SECURITYINFO).empty?
      return sale_with_mag_data unless self.mag_data.blank?
      sale_card_data
    end

    def sale_with_encoded_mag_data
      {
        encoded: {
          ksn: @params_extractor.value_of_param(Shopkeep::EMULATETGATE::SECURITYINFO),
          enc_track1: @params_extractor.value_of_param(Shopkeep::EMULATETGATE::TRACK1),
          enc_track2: @params_extractor.value_of_param(Shopkeep::EMULATETGATE::TRACK2)
        }
      }
    end

    def sale_with_mag_data
      {
        swiped: {
          track2: self.mag_data
        }
      }
    end

    def sale_card_data
      {
        manual: {
          pan: self.card_num,
          expiration_date: self.exp_date,
          cvv_number: self.cv_num
        }
      }
    end
  end
end
