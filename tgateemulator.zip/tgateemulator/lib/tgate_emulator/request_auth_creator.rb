module TgateEmulator
  module RequestAuthCreator
    
    def self.build_request_auth_hash(username,password)
      {
        user_pass: {
          terminal_id: username,
          password: password,
        }
      }
    end
  end
end