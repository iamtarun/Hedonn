module TgateEmulator
  class VoidRequestCreator
    attr_accessor :user_name, :password, :amount, :ext_data, :pn_ref

    def initialize(params = {})
      filter_unrequired_fields(params).each do |name,value|
        public_send("#{name}=",value)
      end

      @params_extractor = ParamsExtractor.new(self.ext_data)
    end

    def process_credit_card_hash
      {
        request_params: build_request_hash,
        requested_url: Shopkeep::PaymentServer::URLS["process_credit_card_void_path"]
      }
    end

    private

    def filter_unrequired_fields(params = {})
      params.extract!(:user_name, :password, :amount, :ext_data, :pn_ref)
    end   
    
    def build_request_hash
      {
        request_data: {
          transaction_reference: self.pn_ref,
          invoice: {
            total_amount: self.amount
          },
          options: {
            override_duplicate: @params_extractor.value_of_param(Shopkeep::EMULATETGATE::FORCE)
          }
        },
        request_auth: RequestAuthCreator.build_request_auth_hash(self.user_name,self.password)
      }
    end
  end
end
