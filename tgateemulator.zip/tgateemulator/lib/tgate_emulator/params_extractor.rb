module TgateEmulator
  class ParamsExtractor
    attr_accessor :ext_data
    
    def initialize(extdata)
      self.ext_data = Nokogiri::XML("<extData>" + extdata + "</extData>")
    end

    def value_of_param(param_name)
      self.ext_data.xpath(param_name).text
    end

    def get_purchase_order_value
      ponum = value_of_param(Shopkeep::EMULATETGATE::PONUM) unless self.ext_data.blank?
      return ponum unless ponum.blank?
      self.ext_data.blank? ? "" : value_of_param(Shopkeep::EMULATETGATE::CUSTCODE)
    end
  end
end