module GetInfo
  class InitializeRequestCreator
    attr_accessor :user_name, :password, :ext_data

    def initialize(params = {})
      filter_unrequired_fields(params).each do |name,value|
        public_send("#{name}=",value)
      end
    end

    def get_info_hash
      # TO DO: replace this with the data recieved from payment server 
      {
        Result: "0",
        RespMSG: "Approved",
        ExtData: "<Partner>187</Partner><Vendor>568</Vendor><MerchantID></MerchantID><PinPadKeyManagement>1</PinPadKeyManagement><LiveURL>https://www.richsolutions.com</LiveURL><LiveURL1>https://www1.richsolutions.com</LiveURL1><TestURL>https://test.richsolutions.com</TestURL><TestURL1>https://test.richsolutions.com</TestURL1><EPSPay>/pay/payxml.aspx</EPSPay><EPSLogin>/RichAdmin/login.aspx</EPSLogin><Phone1>425-868-0364</Phone1><Phone2>425-868-0364</Phone2><Auto_Close_Batch>Y</Auto_Close_Batch><DebitCard>Y</DebitCard><EGC>Y</EGC><CreditCard>Y</CreditCard><PaymentTypes><CardType>Amex</CardType><CardType>Diners</CardType><CardType>Discover</CardType><CardType>Mastercard</CardType><CardType>Visa</CardType></PaymentTypes><ExpressPay><CardType>MasterCard</CardType><LTAmount>25</LTAmount><Amount>0</Amount><EntryMethod>S</EntryMethod><ProcessingRule>On-Line</ProcessingRule><PrintReceipt>N</PrintReceipt></ExpressPay><ExpressPay><CardType>MasterCard</CardType><LTAmount>25</LTAmount><Amount>0</Amount><EntryMethod>M</EntryMethod><ProcessingRule>On-Line</ProcessingRule><PrintReceipt>Y</PrintReceipt></ExpressPay><ExpressPay><CardType>MasterCard</CardType><LTAmount>0</LTAmount><Amount>25</Amount><EntryMethod>S</EntryMethod><ProcessingRule>On-Line</ProcessingRule><PrintReceipt>Y</PrintReceipt></ExpressPay><ExpressPay><CardType>MasterCard</CardType><LTAmount>0</LTAmount><Amount>25</Amount><EntryMethod>M</EntryMethod><ProcessingRule>On-Line</ProcessingRule><PrintReceipt>Y</PrintReceipt></ExpressPay><ExpressPay><CardType>Visa</CardType><LTAmount>25</LTAmount><Amount>0</Amount><EntryMethod>S</EntryMethod><ProcessingRule>On-Line</ProcessingRule><PrintReceipt>N</PrintReceipt></ExpressPay><ExpressPay><CardType>Visa</CardType><LTAmount>25</LTAmount><Amount>0</Amount><EntryMethod>M</EntryMethod><ProcessingRule>On-Line</ProcessingRule><PrintReceipt>Y</PrintReceipt></ExpressPay><ExpressPay><CardType>Visa</CardType><LTAmount>0</LTAmount><Amount>25</Amount><EntryMethod>S</EntryMethod><ProcessingRule>On-Line</ProcessingRule><PrintReceipt>Y</PrintReceipt></ExpressPay><ExpressPay><CardType>Visa</CardType><LTAmount>0</LTAmount><Amount>25</Amount><EntryMethod>M</EntryMethod><ProcessingRule>On-Line</ProcessingRule><PrintReceipt>Y</PrintReceipt></ExpressPay>"
      }
    end

    private

    def filter_unrequired_fields(params = {})
      params.extract!(:user_name, :password, :ext_data)
    end
  end
end
