module GetInfo
  class StatusCheckRequestCreator
    attr_accessor :user_name, :password, :ext_data

    def initialize(params = {})
      filter_unrequired_fields(params).each do |name,value|
        public_send("#{name}=",value)
      end
    end

    def get_info_hash
      # TO DO: replace this with the data recieved from payment server 
      {
        Result: "0",
        RespMSG: "Approved",
        ExtData: "OK"
      }
    end

    private

    def filter_unrequired_fields(params = {})
      params.extract!(:user_name, :password, :ext_data)
    end
  end
end
