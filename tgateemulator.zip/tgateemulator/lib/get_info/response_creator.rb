module GetInfo
  class ResponseCreator
    attr_accessor :success, :response

    def initialize(response_data = {})
      # TO DO: reconstruct response on basis of data recieved from payment server 
      self.success= true
      self.response = Nokogiri::XML::Builder.new { |xml|
        xml.Response("xmlns:xsi"=>"http://www.w3.org/2001/XMLSchema-instance", "xmlns:xsd"=>"http://www.w3.org/2001/XMLSchema", "xmlns"=>"http://TPISoft.com/SmartPayments") do
          response_data.each { |key,value| xml.send key, value }
        end
      }
    end
  end
end
