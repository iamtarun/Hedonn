module GetInfo
  class Processor
    attr_accessor :params

    def initialize(params = {})
      @params = TgateEmulator::Sanitizer.change_hash_key_to_snake_case(params)
    end

    def fetch_info
      filter_request_on_trans_type
    end

    private

    def filter_request_on_trans_type
      valid_trans_type? ? send_request : TgateEmulator::InvalidTransactionType
    end

    def valid_trans_type?
      Shopkeep::GetInfo::VALIDTRANSTYPE.include? params[:trans_type]
    end

    def send_request
      @response_data = "GetInfo::#{params[:trans_type].classify}RequestCreator".constantize.new(@params).get_info_hash
      canned_response
    end

    def canned_response
      ResponseCreator.new(@response_data)
    end
  end
end
