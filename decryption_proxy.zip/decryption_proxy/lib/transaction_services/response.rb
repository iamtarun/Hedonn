module TransactionServices
  module Response
    class ResponseCreator
      attr_reader :response

      def initialize(response_hash)
        @response = response_hash
      end

      def success?
        response[:result] == '0' || response[:result] == 0
      end

      def track_1?
        !response[:track_1].blank?
      end

      def track_2?
        !response[:track_2].blank?
      end

      def parse_track_and_reconstruct(track, params)
        data = split_track(track)
        params["CardNum"]     = extract_account_number(track, data[0])
        params["MagData"]     = "" if params["MagData"].nil?
        params["MagData"]     += response[track]
        params["ExtData"]     = drop_extdata_element(params["ExtData"])
        if track.eql?(:track_1)
          params["NameOnCard"]  = data[1].gsub(/[^A-Za-z]/, ' ').strip
          params["ExpDate"]     = data[2].slice(2..3)+""+data[2].slice(0..1)
        else
          params["ExpDate"]     = data[1].slice(2..3)+""+data[1].slice(0..1)
        end

        params
      end

      def to_xml
        response.to_xml(:root => 'response')
      end

      private

      def split_track(track)
        response[track].split(track.eql?(:track_1) ? "^" : "=")
      end

      def extract_account_number(track, ac_num)
        index = (track.eql? :track_2) ? 1 : 2
        ac_num = ac_num.slice(index..ac_num.length)
        (ac_num.length > Shopkeep::ProxyConstant::CREDITCARD_MAX_LENGTH) ? ac_num.slice(0...(ac_num.length - (ac_num.length - Shopkeep::ProxyConstant::CREDITCARD_MAX_LENGTH))) : ac_num
      end

      def drop_extdata_element(data)
        ext_data = Nokogiri::XML("<ExtData>" +data+ "</ExtData>")
        ["SecurityInfo", "Track1", "Track2", "SecureFormat"].each do |tags|
          ext_data.xpath("//#{tags}").remove
        end
        ext_data.root.inner_html
      end

    end
  end
end
