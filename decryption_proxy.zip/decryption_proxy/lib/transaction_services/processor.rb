module TransactionServices
  module Processor
    class TransactionHandler
      require "net/http"
      require "uri"
      require "json"
      require "timeout"

      attr_accessor :params
      attr_reader :client, :request

      def initialize(args = {}, request)
        @request = request
        request.fullpath.split('?').first.slice(Regexp.new("#{DecryptionProxy::Application.config.relative_url_root}(.*)"))
        @client = TransactionServices::Request::Base::client_for($1, request)
  
        # Soap11 comes in as a hash, but Soap1.2 does not (text/xml); just do them both.
        @params = params_hash(soap? ? Hash.from_xml(request.raw_post) : args)
      end

      # TODO: Turn this into classes
      def soap?
        (/urlencoded/ =~ request.headers["CONTENT_TYPE"]).nil?
      end

      def process
        timeout(Shopkeep::ProxyConstant::TIMEOUT_PERIOD) do
          if check_element?
            p2p_response = filter_elements
            if p2p_response.success?
              request_param = reconstruct_params(p2p_response)
            else
              return p2p_response
            end
          else
            request_param = soap? ? request.raw_post : params
          end

          client.process(request_param)

        end
      rescue Errno::ECONNREFUSED => exception
        Error::ErrorHandler.new(Shopkeep::ProxyConstant::CONNECTION_ERROR)
      rescue Timeout::Error => exception
        Error::ErrorHandler.new(Shopkeep::ProxyConstant::TIMEOUT_ERROR)
      end

      private

      def params_hash(args)
        new_params = {}
        node = soap? ? args["Envelope"]["Body"]["ProcessCreditCard"] : args
        node.each do |key, value|
          new_params[key] = value if !(["transactions","controller", "action", "xmlns"].include?(key))
        end
        new_params
      end

      def check_element?
        !params['ExtData'].nil? && params['ExtData'].include?("<SecurityInfo>")
      end

      def parse_ext_data_to_p2p_params
        ext_data = Nokogiri::XML("<ExtData>" + params['ExtData'] + "</ExtData>")
        Hash['decryption[ksn]', ext_data.xpath("//SecurityInfo").text,
        'decryption[enc_track_1]', ext_data.xpath("//Track1").text,
        'decryption[enc_track_2]', ext_data.xpath("//Track2").text,
        'username', Shopkeep::ServerSetting::CREDENTIAL["username"],
        'password', Shopkeep::ServerSetting::CREDENTIAL["password"]]
      end

      def build_response_hash(response)
        if response['result']['code'] == 0
          Hash[:result, response['result']['code'],
          :resp_msg, response['result']['message'],
          :track_1, response['result']['track_1'],
          :track_2, response['result']['track_2']]
        else
          Hash[:result, response['result']['code'],
          :resp_msg, response['result']['message']]
        end
      end

      def response_format(response_data)
        Response::ResponseCreator.new(response_data)
      end

      def build_response(p2p_response)
        response_format(build_response_hash(JSON.parse(p2p_response)))
      end

      def error_message(params, url)
        Hash[code: params.code, message: params.message+", from server "+url.to_s]
      end

      def filter_elements
        uri = URI.parse(Shopkeep::ServerSetting::URLS["decryption_service_p2p_url"])
        p2p_response = Net::HTTP.post_form(uri, parse_ext_data_to_p2p_params)
        if !p2p_response.body.include?("Exception caught") && p2p_response.is_a?(Net::HTTPSuccess)
          return build_response(p2p_response.body)
        else
          return Error::ErrorHandler.new(error_message(p2p_response, uri))
        end
      rescue URI::InvalidURIError => exception
        Error::ErrorHandler.new({code: "400", message: exception.message})
      rescue Errno::ECONNREFUSED => exception
        Error::ErrorHandler.new(Shopkeep::ProxyConstant::CONNECTION_ERROR)
      end

      def reconstruct_params(response)
        
        response.parse_track_and_reconstruct(:track_1, params) if response.track_1?
        response.parse_track_and_reconstruct(:track_2, params)  if response.track_2?

        # Now that the params are straightened out, see if we 
        # hae any work to do on the request
        request_param = reconstruct_request(params)

      end

      def reconstruct_request(params)

        # We're just going to see if this is a Soap request. If it is
        # transfer the data into the XML, if it isn't leave it alone.
        # The long and the short of it is that we want to just utilize
        # the existing Soap envelope instead of rebuilding it.
        #
        result = params
        if soap?
          result = Nokogiri::XML(request.raw_post)

          ["CardNum", "MagData", "ExtData", "NameOnCard", "ExpDate"].each do |element|
            result.xpath("//tpi:#{element}", 'tpi' => 'http://TPISoft.com/SmartPayments/').first.content = params[element]
          end

          result  = result.inner_html
        end
        result

      end

    end
  end
end
