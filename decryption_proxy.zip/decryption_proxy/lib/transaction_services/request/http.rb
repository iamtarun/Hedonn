module TransactionServices
    module Request
    
      class Http < TransactionServices::Request::Base
      
        def initialize (request_path, request)
          super request_path, request
        end

        def process(params)

          Rails.logger.info("HTTP Post params: #{params}")

          @response = HTTParty.post(Shopkeep::ServerSetting::URLS["tgate_wsdl_url"] + @request_path, 
                                    body: params,
                                    headers: {'Content-Type' => @request.headers["CONTENT_TYPE"]})
          self
        end

        def to_xml
          # it already is xml
          @response.body

        end
 
      end

  end
end
