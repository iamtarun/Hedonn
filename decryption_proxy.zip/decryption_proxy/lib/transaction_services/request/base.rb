module TransactionServices
  module Request

    class Base

      attr_reader :response
      
      def self.client_for(request_path, request)

        # The only one we do at the moment
        TransactionServices::Request::Http.new request_path, request

        # Works (no tests), but we will most likely rid ourselves of it
        # TransactionServices::Request::SavonHeavy.new request_path, request
      end

      def initialize(request_path, request)
        @request_path = request_path
        @request = request
      end

    end
  end
end
