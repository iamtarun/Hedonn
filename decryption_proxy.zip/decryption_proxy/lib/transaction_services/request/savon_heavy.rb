module TransactionServices
    module Request
      require "savon"

      class SavonHeavy < TransactionServices::Request::Base

        def initialize (request_path, request)
          super request_path, request
        end

        def process(params)
          options = {filters: [:password, :card_number, :magnetic_data, :cv_number], pretty_print_xml: true, log: !Rails.env.test?, wsdl: tgate_url(@request_path)}
          action_name = @request_path.split('/').last.underscore.to_sym
          @response = Savon.client(options).call(action_name, message: params)      

        rescue Savon::SOAPFault => exception
          Error::ErrorHandler.new(Shopkeep::ProxyConstant::CONNECTION_ERROR)
        rescue Savon::UnknownOperationError => exception
          Error::ErrorHandler.new({code: 400, message: exception})
        rescue Wasabi::Resolver::HTTPError => exception
          Error::ErrorHandler.new(Shopkeep::ProxyConstant::CONNECTION_ERROR)
   
        end

        def tgate_url(request_path)
          path = request_path.gsub('/'+request_path.split('/').last, '') 
          Shopkeep::ServerSetting::URLS["tgate_wsdl_url"].to_s + path+"?WSDL"
        end 

      end
  end
end
