module TransactionServices
  module Error
    class ErrorHandler < StandardError
      attr_accessor :response

      def initialize(errors)
        @response = {
          result: errors[:code],
          resp_msg: errors[:message]
        }
      end

      def success?
        false
      end

      def to_xml
        response.to_xml(:root => 'errors')
      end
    end
  end
end