ENV["RAILS_ENV"] ||= 'test'

require File.expand_path("../../config/environment", __FILE__)
require 'rspec/rails'

# Requires supporting ruby files with custom matchers and macros, etc,
# in spec/support/ and its subdirectories.
Dir[Rails.root.join("spec/support/**/*.rb")].each { |f| require f }

VCR.configure do |c|
  c.cassette_library_dir = 'spec/cassettes'
  c.hook_into :webmock
  c.default_cassette_options = { record: :none }
  c.allow_http_connections_when_no_cassette = false
end

RSpec.configure do |config|
  config.infer_base_class_for_anonymous_controllers = true
  config.order = "random"

  # Adding a :vcr tag to the specs that need to use VCR so that they use it
  # automatically and create a cassette based on the spec’s name
  config.treat_symbols_as_metadata_keys_with_true_values = true
  config.around(:each, :vcr) do |example|
    name = example.metadata[:full_description].split(/\s+/, 2).join("/").
      underscore.gsub(/[^\w\/]+/, "_")

    VCR.use_cassette(name, match_requests_on: [:method, :uri, :body] ) { example.call }
  end
end
