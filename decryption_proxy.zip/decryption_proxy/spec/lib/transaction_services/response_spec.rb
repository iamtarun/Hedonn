require 'spec_helper'
include TransactionServices::Response

describe TransactionServices::Response::ResponseCreator do

  describe "#success?" do
    it "when params[:result] is zero it returns true" do
      params = {result: '0'}
      ResponseCreator.new(params).should be_success
    end

    it "when params[:result] is not zero it returns false" do
      params = {result: '2'}
      ResponseCreator.new(params).should_not be_success
    end
  end

  describe "#track_1?" do
    it "when params[:track_1] is not empty it returns true" do
      params = {track_1: 'F800324F3922E7F14033B14910E72C3064F4803EC1F0827D0A2D675E590A1EC6C4AFE44DE7B51DF39E790C9CD3F343642810F883112C3F91'}
      ResponseCreator.new(params).should be_track_1
    end

    it "when params[:track_1] is not empty it returns false" do
      params = {track_1: ''}
      ResponseCreator.new(params).should_not be_track_1
    end
  end

  describe "#track_2?" do
    it "when params[:track_2] is not empty it returns true" do
      params = {track_2: '49CB7CEA2329B8B51E446922CBE3B6AA00B311F51D1849B83688CF6BE28DEBBF523A4987F31E7758'}
      ResponseCreator.new(params).should be_track_2
    end

    it "when params[:track_2] is not empty it returns false" do
      params = {track_2: ''}
      ResponseCreator.new(params).should_not be_track_2
    end
  end
end
