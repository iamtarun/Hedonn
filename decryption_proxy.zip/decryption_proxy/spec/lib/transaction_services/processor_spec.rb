require 'spec_helper'
include TransactionServices::Processor

describe TransactionServices::Processor::TransactionHandler do

  let(:params) do
  {
    "UserName" => "Shop8409",
    "Password" => "V4113du3",
    "TransType" => "sale",
    "CardNum" => "4012000033330026",
    "ExpDate" => "0915",
    "MagData" => "",
    "NameOnCard" => "test store",
    "Amount" => "1.00",
    "InvNum" => "",
    "PNRef" => "",
    "Zip" => "",
    "Street" => "",
    "CVNum" => "",
    "ExtData" => "<SecurityInfo>234234B066AC7000004</SecurityInfo>
      <Track1>F800324F3922E7F14033B14910E72C3064F4803EC1F0827D0A2D675E590A1EC6C4AFE44DE7B51DF39E790C9CD3F343642810F883112C3F91</Track1>
      <Track2>49CB7CEA2329B8B51E446922CBE3B6AA00B311F51D1849B83688CF6BE28DEBBF523A4987F31E7758</Track2>
      <SecureFormat>magne_safe</SecureFormat>
      <Force>T</Force>"
  }
  end

  let(:fullpath) { "/smartpayments/transact3.asmx/ProcessCreditCard" }
  let(:request) { double(fullpath: "/smartpayments/transact3.asmx/ProcessCreditCard", raw_post: params, headers: {"CONTENT_TYPE" => "application/x-www-form-urlencoded"})}

  describe "#process credit card" do
    it "when response with code 0", :vcr do
      response_data = TransactionHandler.new(params, request).process
      response_data = response_data.response.parsed_response["Response"] 
      response_data["Result"].should == '0'
      response_data["RespMSG"].should == 'Approved'
      response_data["AuthCode"].should =~ /\A\d+\z/
      response_data["HostCode"].should =~ /\A\d+\z/
    end

    it "when params sent are not valid", :vcr do
      params.delete("UserName")
      response_data = TransactionHandler.new(params, request).process
      response_data.response.parsed_response.should include("Missing parameter: UserName.")
    end
  end 
 
  describe "#get card type" do
  
    let(:params) { { "CardNumber" => "4005550000000019"} }

    it "touches an endpoint other than ProcessCreditCard", :vcr do
      request.stub(:fullpath) { "/smartpayments/validate.asmx/GetCardType" }
      request.stub(:raw_post)  { params }
      response_data = TransactionHandler.new(params, request).process
      response_data.response.parsed_response["string"].should eq "VISA"
    end

  end

end
