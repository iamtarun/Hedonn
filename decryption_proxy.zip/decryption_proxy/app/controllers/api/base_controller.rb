class Api::BaseController < ApplicationController
end
