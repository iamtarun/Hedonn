class Api::TransactionProcessesController < Api::BaseController
  include TransactionServices::Processor

  def transaction_process
    @pcc_transaction = TransactionHandler.new(params, request)
    @pcc_response = @pcc_transaction.process
    render xml: @pcc_response.to_xml
  end
end
