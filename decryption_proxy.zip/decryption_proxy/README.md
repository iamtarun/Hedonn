# Decryption-proxy

#transaction_processes/transaction_process

curl -i -H "Accept: application/json" -X POST -d @doc/get_info_key_value_request.txt http://localhost:3000/smartpayments/transact3.asmx/GetInfo


TGate server Process getinfo response
=============================================

HTTP/1.1 200 OK
Content-Type: application/xml; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "b85b6767d555e26405b46506d941acde"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 92805925a7e6b97338696e599eb9c8fd
X-Runtime: 8.720000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Thu, 13 Jun 2013 18:00:53 GMT
Content-Length: 3717
Connection: Keep-Alive

<?xml version="1.0" encoding="utf-8"?>
<Response xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://TPISoft.com/SmartPayments/">
  <Result>0</Result>
  <RespMSG>Approved</RespMSG>
  <ExtData>&lt;Partner&gt;187&lt;/Partner&gt;&lt;Vendor&gt;5849&lt;/Vendor&gt;&lt;MerchantID&gt;&lt;/MerchantID&gt;&lt;PinPadKeyManagement&gt;1&lt;/PinPadKeyManagement&gt;&lt;LiveURL&gt;https://www.richsolutions.com&lt;/LiveURL&gt;&lt;LiveURL1&gt;https://www1.richsolutions.com&lt;/LiveURL1&gt;&lt;TestURL&gt;https://test.richsolutions.com&lt;/TestURL&gt;&lt;TestURL1&gt;https://test.richsolutions.com&lt;/TestURL1&gt;&lt;EPSPay&gt;/pay/payxml.aspx&lt;/EPSPay&gt;&lt;EPSLogin&gt;/RichAdmin/login.aspx&lt;/EPSLogin&gt;&lt;Phone1&gt;425-868-0364&lt;/Phone1&gt;&lt;Phone2&gt;425-868-0364&lt;/Phone2&gt;&lt;Auto_Close_Batch&gt;Y&lt;/Auto_Close_Batch&gt;&lt;DebitCard&gt;Y&lt;/DebitCard&gt;&lt;EGC&gt;Y&lt;/EGC&gt;&lt;CreditCard&gt;Y&lt;/CreditCard&gt;&lt;PaymentTypes&gt;&lt;CardType&gt;Amex&lt;/CardType&gt;&lt;CardType&gt;CartBlanch&lt;/CardType&gt;&lt;CardType&gt;Diners&lt;/CardType&gt;&lt;CardType&gt;Discover&lt;/CardType&gt;&lt;CardType&gt;JAL&lt;/CardType&gt;&lt;CardType&gt;JCB&lt;/CardType&gt;&lt;CardType&gt;Mastercard&lt;/CardType&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;/PaymentTypes&gt;&lt;ExpressPay&gt;&lt;CardType&gt;MasterCard&lt;/CardType&gt;&lt;LTAmount&gt;25&lt;/LTAmount&gt;&lt;Amount&gt;0&lt;/Amount&gt;&lt;EntryMethod&gt;S&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;N&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;MasterCard&lt;/CardType&gt;&lt;LTAmount&gt;25&lt;/LTAmount&gt;&lt;Amount&gt;0&lt;/Amount&gt;&lt;EntryMethod&gt;M&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;MasterCard&lt;/CardType&gt;&lt;LTAmount&gt;0&lt;/LTAmount&gt;&lt;Amount&gt;25&lt;/Amount&gt;&lt;EntryMethod&gt;S&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;MasterCard&lt;/CardType&gt;&lt;LTAmount&gt;0&lt;/LTAmount&gt;&lt;Amount&gt;25&lt;/Amount&gt;&lt;EntryMethod&gt;M&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;LTAmount&gt;25&lt;/LTAmount&gt;&lt;Amount&gt;0&lt;/Amount&gt;&lt;EntryMethod&gt;S&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;N&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;LTAmount&gt;25&lt;/LTAmount&gt;&lt;Amount&gt;0&lt;/Amount&gt;&lt;EntryMethod&gt;M&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;LTAmount&gt;0&lt;/LTAmount&gt;&lt;Amount&gt;25&lt;/Amount&gt;&lt;EntryMethod&gt;S&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;&lt;ExpressPay&gt;&lt;CardType&gt;Visa&lt;/CardType&gt;&lt;LTAmount&gt;0&lt;/LTAmount&gt;&lt;Amount&gt;25&lt;/Amount&gt;&lt;EntryMethod&gt;M&lt;/EntryMethod&gt;&lt;ProcessingRule&gt;On-Line&lt;/ProcessingRule&gt;&lt;PrintReceipt&gt;Y&lt;/PrintReceipt&gt;&lt;/ExpressPay&gt;</ExtData>
</Response>



curl request for ProcessCreditCard
-----------------------------------

curl -i -H "Accept: application/json" -X POST -d "UserName=Shop8409&Password=V4113du3&TransType=sale&CardNum=4012000033330026&ExpDate=0915&MagData=&NameOnCard=test store&Amount=1.00&InvNum=&PNRef=&Zip=&Street=&CVNum=&ExtData=<Force>T</Force>" http://localhost:3000/smartpayments/transact3.asmx/ProcessCreditCard


TGate server Process ProcessCreditCard response
=============================================

HTTP/1.1 200 OK
Content-Type: application/xml; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "95961848fd60495fe9236f1fd6dc2dfe"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: 163b11a03cd77a21a2ed43ff6663659f
X-Runtime: 9.185000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Thu, 13 Jun 2013 18:04:07 GMT
Content-Length: 624
Connection: Keep-Alive

<?xml version="1.0" encoding="utf-8"?>
<Response xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://TPISoft.com/SmartPayments/">
  <Result>1000</Result>
  <RespMSG>Generic Host Error</RespMSG>
  <Message>An error occured while finishing the transaction.Transaction was voided.</Message>
  <ExtData>CardType=VISA</ExtData>
</Response>


curl request for ProcessCreditCard with security info tag
---------------------------------------------------------

 curl -i -H "Accept: application/json" -X POST -d @doc/process_credit_card_key_value_request.txt http://localhost:3000/smartpayments/transact3.asmx/ProcessCreditCard

TGate server Process ProcessCreditCard response
=============================================

HTTP/1.1 200 OK
Content-Type: application/xml; charset=utf-8
X-Ua-Compatible: IE=Edge
Etag: "84293f0f36b8ae383391a34d1e2666b6"
Cache-Control: max-age=0, private, must-revalidate
X-Request-Id: ae0aa6349a7345e25dc3c60e8a01da4d
X-Runtime: 28.518000
Server: WEBrick/1.3.1 (Ruby/1.9.3/2013-02-21)
Date: Fri, 14 Jun 2013 12:15:33 GMT
Content-Length: 624
Connection: Keep-Alive

<?xml version="1.0" encoding="UTF-8"?>
<errors>
  <result type="integer">400</result>
  <resp-msg>Error connecting with process.</resp-msg>
</errors>
