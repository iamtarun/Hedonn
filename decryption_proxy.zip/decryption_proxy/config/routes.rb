DecryptionProxy::Application.routes.draw do
  match "/*transactions" => "api/transaction_processes#transaction_process"
end