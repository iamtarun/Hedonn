# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DecryptionProxy::Application.config.secret_token = 'ae364c503f93d3a31cd7995a0d61df471d6121f80f7fb616228ae63c7a1b51aa9875882fc5b0a583abd61356a10f4db3628e3f4a18840994f7a1624cf444d4b7'
