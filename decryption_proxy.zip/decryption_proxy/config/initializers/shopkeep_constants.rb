module Shopkeep
  module ProxyConstant
    CREDITCARD_MAX_LENGTH = 16
    TIMEOUT_PERIOD = 40
    TIMEOUT_ERROR = {code: 504, message: "Timeout error getting response from processor"}
    CONNECTION_ERROR = {code: 400, message: "Error connecting with process."}
  end

  module ServerSetting
    SETTING = YAML.load ERB.new(File.read Rails.application.config.paths['config/proxy_settings'].first).result
    URLS = SETTING[Rails.env]
    CREDENTIAL = SETTING["p2pdecrypt_user_credential"]
  end
end
