ActionController::Routing::Routes.draw do |map|
  
  map.root :controller => "template", :action=> "index"
  
  map.connect ':controller/:action/:id.:format'
  map.connect ':controller/:action/:id'

  # Generic Resource Routes:
  map.connect ':controller/:id.:format', :action => :show, :conditions => { :method => :get }, :requirements => { :id => /\d+/ }
  map.connect ':controller/:id.:format', :action => :update, :conditions => { :method => [ :put, :post ] }, :requirements => { :id => /\d+/ }
  map.connect ':controller/:id.:format', :action => :destroy, :conditions => { :method => :delete }, :requirements => { :id => /\d+/ }

  map.connect ':controller/:action.:format'
  map.connect ':controller/:action'

  # Generic Resource Routes
  map.connect ':controller.:format', :action => :index, :conditions => { :method => :get }
  map.connect ':controller.:format', :action => :create, :conditions => { :method => [ :put, :post ] }

  
  
  #template builder routes
  map.connect '/template/show', :controller => 'template', :action=>'show', :conditions=>{:method=>:post}
  
  map.connect '/template/save', :controller => 'template', :action=>'save', :conditions=>{:method=>:post}
  
  map.connect '/template/show_form/:id', :controller => 'template', :action=>'show_form', :conditions=>{:method=>:get}
  
  #template builder api routes
  map.connect '/api/template/show', :controller => 'api/template', :action=>'show', :conditions=>{:method=>:post}
  
  map.connect '/api/template/show', :controller => 'api/template', :action=>'show', :conditions=>{:method=>:get}
  
  map.connect '/api/template/save', :controller => 'api/template', :action=>'save', :conditions=>{:method=>:post}
  
  map.connect '/api/locally/save', :controller => 'api/locally', :action=>'save', :conditions=>{:method=>:post}
  
  map.connect '/api/template/show_template_form', :controller => 'api/template', :action=>'show_template_form', :conditions=>{:method=>:post}
  
  map.connect '/api/template/show_form/:id/:library_type', :controller => 'api/template', :action=>'show_form', :conditions=>{:method=>:get}
  
  map.connect '/api/template/new/:id/:library_type/:new_form', :controller => 'api/template', :action=>'new', :conditions=>{:method=>:get}
  
  map.connect '/api/template/publish_template', :controller => 'api/template', :action=>'publish_template', :conditions=>{:method=>:post}
  
  map.connect '/api/template/edit_form/:id/:library_type/:form_id', :controller => 'api/template', :action=>'edit_form', :conditions=>{:method=>:get}
  map.connect '/api/template/edit_form/:id/:library_type', :controller => 'api/template', :action=>'edit_form', :conditions=>{:method=>:get}
  map.connect '/api/template/search_to_edit/:id/:library_type', :controller => 'api/template', :action=>'search_to_edit', :conditions=>{:method=>:get}
  
  map.connect '/api/template/publish_form', :controller => 'api/template', :action=>'publish_form', :conditions=>{:method=>:get}
	
end