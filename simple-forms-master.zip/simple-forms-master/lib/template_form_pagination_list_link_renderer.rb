class TemplateFormPaginationListLinkRenderer < WillPaginate::LinkRenderer
  def prepare(collection, options, template)
    @request_uri =  options[:params][:request_uri]
    super
  end
  def to_html
    links = @options[:page_links] ? windowed_links : []
	# previous/next buttons
	links.unshift page_link_or_span(@collection.previous_page, 'disabled prev_page', @options[:previous_label])

	# Add my first link
	links.unshift page_link_or_span(1, 'disabled first_page', 'First')
	links.push    page_link_or_span(@collection.next_page,     'disabled next_page', @options[:next_label])

	# Add my last link
	links.push    page_link_or_span(@collection.total_pages,     'disabled last_page', 'Last')

	html = links.join(@options[:separator])
	@options[:container] ? @template.content_tag(:div, html, html_attributes) : html
  end
  
protected
  
  def page_link(page, text, attributes = {})
    @template.link_to text, @request_uri + "/api/template/form_list?page=#{page}", attributes.merge({:class => 'template-form-pagination'})
  end
  
end
