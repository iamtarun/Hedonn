$(function(){
	var btnUpload=$('#upload');
	var status=$('#status');
	var imageName = '';
	new AjaxUpload(btnUpload, {
		action: 'http://192.168.14.2:3000/template/upload_image',
		name: 'uploadfile',
		onSubmit: function(file, ext){
			 if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){
				// extension is not allowed
				status.text('Only JPG, PNG or GIF files are allowed');
				return false;
			}
			status.text('Uploading...');
		},
		onComplete: function(file, response){			
			response_pre = $('<pre></pre>').html(response).text();
			response_preObj = $.parseJSON(response_pre);
			
			//On completion clear the status
			status.text('');			
			if(response_preObj[0].hasOwnProperty('success')) {
				renderImageList(response_preObj);
			} else {
				alert('Please choose correct picture to upload.');
			}
		}
	});
	
	renderImageList = function(response_preObj) {
		try {
			//$('<li></li>').appendTo('#files').html('<img src="/images/upload/'+ response_preObj[0].success +'" alt="" width="170" />');
			var imageHtml = '';
			imageHtml = '<tr id="' + response_preObj[0].id + '">' + 
						'<td valign="top" class="prop-table-value"><input type="radio" name="image_select" value="' + response_preObj[0].name + '"></td>' +
						'<td valign="top">' + response_preObj[0].name + '</td>' +
						'<td valign="top"><img src="/images/upload/' + response_preObj[0].name + '" alt="" width="60" /></td>' +
						'<td valign="top">Active</td>' +
						'<td valign="top"><input type="button" name="delete_image" id="delete_image" data-id="' + response_preObj[0].id + '" value="Delete"></td>' +
						'</tr>';
						
			$('#image-list-box-table')
				.find('#no-image-items')
				.remove();
			$('#image-list-box-table').append(imageHtml);
		} catch (e) {
			console.log(e.message, e.name);
		}
	}

});