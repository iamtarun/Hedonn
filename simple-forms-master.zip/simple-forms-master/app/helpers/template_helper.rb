module TemplateHelper
	def is_template(template_id)
		FormValue.find_all_by_template_id(template_id).last
	end
end
