class TemplateController < LoggedInController
	layout "template_builder"
	skip_all_filters
	before_filter :cross_domain_access
	def index
		user_id = 5
		@data_persistent = Template.get_persistence.to_json		
		@template_library = TemplateLibrary.get_library(user_id)
		@data_event = TemplateLifeCycleEvent.get_template_event.to_json
		@template_image = TemplateImage.get_template_image(user_id)
	end
	
	def get_template_image
		user_id = 5
		@template_image = TemplateImage.get_template_image(user_id)
		respond_to do |format|
			  format.json { render :json => @template_image, :layout => false }
		end
	end
	
	def get_persistence
		@persistence = Template.get_persistence
		respond_to do |format|
			  format.json { render :json => @persistence, :layout => false }
		end
	end
	
	def get_template_event
		@data_event = TemplateLifeCycleEvent.get_template_event
		respond_to do |format|
			  format.json { render :json => @data_event, :layout => false }
		end
	end
	
	def show_template_form
		#puts params
		@form = Template.show_template_form_value(params)
		respond_to do |format|
			format.json { render :json => @form, :layout => false }
		end
	end
	
	def get_activity_log
		#puts params
		@log = TemplateActivityLog.get_activity_log(params)
		respond_to do |format|
			format.json { render :json => @log, :layout => false }
		end
	end
	
	def get_locations
		#puts params
		user_id = 5
		@locations = Template.get_user_location(user_id)
		
		respond_to do |format|
			  format.json { render :json => @locations, :layout => false }
		end
	end
	
	def image_list
		user_id = 5
		@template_image = TemplateImage.get_template_image(user_id)
		respond_to do |format|
			  format.html { render :layout => false }
		end
	end
	
	def upload_image
		#puts params
		user_id = 5
		
		name = params[:uploadfile].original_filename
		base_name = File.basename(name, ".*")
		extension = File.extname(name)
		
		directory = "public/images/upload"
		image_name =  base_name + "_" + user_id.to_s + (rand(99999)+rand(99999)+rand(99999)).to_s + "_" + (Time.now.to_i).to_s + extension
		path = File.join(directory, image_name)
		File.open(path, "wb") { |f| f.write(params[:uploadfile].read) }
		
		template_image = TemplateImage.save_image(image_name, user_id)
		upload_msg = Array.new	
		if template_image.present?			
			@success = upload_msg.push({'success' => 1, 'name' => image_name, 'id' => template_image})
		else
			@success = upload_msg.push({'error' => 0, 'name' => image_name})
		end
		
		respond_to do |format|
			format.json { render :json => @success, :layout => false }
		end		
	end
	
	def delete_image
		@template_image_id = nil
		if params[:id].present?
			@template_image_id = TemplateImage.delete_image(params)
		end
		respond_to do |format|
			  format.json { render :json => @template_image_id, :layout => false }
		end
	end
	
	
	private
	def cross_domain_access
		headers['Access-Control-Allow-Origin'] = "*"
	end
end
