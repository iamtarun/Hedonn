class Api::LocallyController < LoggedInController
	layout nil
	skip_all_filters
	before_filter :cross_domain_access
	def save
		@template_id = nil
		respond_to do |format|
			  format.json { render :json => @template_id, :layout => false }
		end
	end
	
	private
	def cross_domain_access
		headers['Access-Control-Allow-Origin'] = "*"
	end
end
