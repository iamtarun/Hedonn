class Api::TemplateController < LoggedInController
	layout nil
	skip_all_filters
	before_filter :cross_domain_access
	def save
		#puts params
		user_id = 5
		locations = {}
		@template = 0
		check_exist_template = Api::Template.check_existing_template(params)
		if check_exist_template.present? && params[:id].blank?
			@template = 0
		else
			location_id = params[:locations]
			locations[:save_location] = Api::Template.get_user_location_details(location_id)
			requestURL =  request.env["REQUEST_URI"].gsub(request.request_uri,"")			
			@template = Api::Template.save_template(params, locations, requestURL)
		end		
		respond_to do |format|
			  format.json { render :json => @template, :layout => false }
		end
	end
	
	def show
		#puts params
		@form = Api::Template.show_template(params).paginate(:per_page => 5, :page => params[:page])
		respond_to do |format|
			  format.html
			  format.js { render :layout => false }
		end
	end
	
	def save_form_template
		#puts params
		@template_form_id = nil
		if params[:template_id].present?
			@template_form_id = Api::Template.save_form_template(params)
		end
		respond_to do |format|
			  format.json { render :json => @template_form_id, :layout => false }
		end
	end
	
	def delete
		@template_form_id = nil
		if params[:form_id].present?
			@template_form_id = Api::Template.delete_form(params)
		end
		respond_to do |format|
			  format.json { render :json => @template_form_id, :layout => false }
		end
	end
	
	def show_form
		#puts params
		if params[:id].present? && params[:library_type].present?
			@form_content = Api::Template.show_template_form(params)
			if @form_content
				render :layout => false
			else
				render_404
			end
		else
			render_404
		end		
	end
	
	def template_form
		user_id = 5	
		@template_library = TemplateLibrary.get_library(user_id)
		render :layout => 'customer'
	end
	
	def form_list
		#puts params
		@form = Api::Template.show_template(params).paginate(:per_page => 5, :page => params[:page])
		respond_to do |format|
			  format.html
			  format.js { render :layout => false }
		end
	end
	
	def new
		#puts params		
		if params[:id].present?
			@form_content = Api::Template.show_template_form(params)
			if @form_content
				render :layout => 'customer_form'
			else
				render_404
			end
		else
			render_404
		end
		
	end
	
	def edit_form
		#puts params		
		if params[:id].present?
			@form_content = Api::Template.show_template_form(params)
			if @form_content
				render :layout => 'customer_form'
			else
				render_404
			end
		else
			render_404
		end		
	end
	
	def publish_template
		template_library_id = TemplateLibrary.find_by_name(params[:library_type]).id
		TemplateLibraryList.find_by_template_id_and_template_library_id(params[:form_id].to_i, template_library_id).update_attribute(:is_template_publish, true)
		render :nothing => true
	end
	
	def render_404
		respond_to do |format|
			format.html { render :file => "#{Rails.root}/public/404.html", :layout => false, :status => :not_found }
			format.xml  { head :not_found }
			format.any  { head :not_found }
		end
	end
	
	def publish_form
		template_library_id = TemplateLibrary.find_by_name(params[:library_type]).id	
		TemplateLibraryList.find_by_template_id_and_template_library_id(params[:data_id].to_i, template_library_id).update_attribute(:is_form_publish, true)
		@form = Api::Template.show_template(params).paginate(:per_page => 5, :page => params[:page])
		respond_to do |format|
			  format.html
			  format.js { render :layout => false }
		end
	end
	
	def search_to_edit
		#puts params
		render :layout => 'customer'
	end
	
	def search
		#puts params			
		@form_value_data = Api::Template.search_template(params)		
		@form_value = @form_value_data["form_value"].paginate(:per_page => 5, :page => params[:page])
		@library_type = @form_value_data["library_type"]
		respond_to do |format|
			  format.html
			  format.js { render :layout => false }
		end
	end
	
	def create_inking_image
		#puts params
		@image_file = {}
		if params[:data_json].present?
			requestURL =  request.env["REQUEST_URI"].gsub(request.request_uri,"")
			@image_file = Api::Template.create_inking_image(params, requestURL)
		end
		respond_to do |format|
			  format.json { render :json => @image_file, :layout => false }
		end
	end
	
	def delete_inking_image
		#puts params
		if params[:image_path].present?
			@delete_overlay = Api::Template.delete_inking_image(params)
		end
		render :nothing => true
	end
	
	def get_persistent_url
		@persistent_url = nil
		if params[:data_persistent].present?
			@persistent_url = TemplatePersistent.get_persistent_url(params)
		end
		respond_to do |format|
			  format.html { render :json => @persistent_url, :layout => false }
		end
	end
	
	def get_patient_name
		@patien_name = {}
		if params[:keyword].present? && params[:template_id].present? && params[:data_persistent].present?
			@patien_name = Api::Template.get_patient_name(params)
		end
		respond_to do |format|
			  format.json { render :json => @patien_name, :layout => false }
		end
	end
	
	def get_patient_icd9
		@icd = {}
		if params[:keyword].present? && params[:template_id].present? && params[:data_persistent].present?
			@icd = Api::Template.get_patient_icd9(params)
		end
		respond_to do |format|
			  format.json { render :json => @icd, :layout => false }
		end
	end
	
	def upload_template_file
		#puts params		
		#name = params[:uploadfile].original_filename
		#base_name = File.basename(name, ".*")
		#extension = File.extname(name)		
		#file_name =  base_name + "_" + (rand(99999)+rand(99999)+rand(99999)).to_s + "_" + (Time.now.to_i).to_s + extension
		
		user_id = 5
		template_id = params[:template_id]
		content_type = params[:uploadfile].content_type.chomp
		directory = RAILS_ROOT + "/public/template_form_files"
		file_name = params[:file_name]
		path = File.join(directory, file_name)
		
		file_save = File.open(path, "wb") { |f| f.write(params[:uploadfile].read) }
		
		template_temp_file = TemplateTempFile.save_temp_file(file_name, content_type, template_id, user_id)
		
		upload_msg = Array.new
		
		if template_temp_file.present?
			@success = upload_msg.push({'success' => 1, 'name' => file_name})
		else
			@success = upload_msg.push({'error' => 0})
		end
		
		respond_to do |format|
			format.json { render :json => @success, :layout => false }
		end
	end
	
	def view_file
		#puts params	
		if params[:id].present?
			@file_content = Api::Template.show_template_file(params)
			if @file_content
				data = Base64.decode64(@file_content.file_blob)		
				#data = Zlib::Inflate.new(-Zlib::MAX_WBITS).inflate(@file_content.file_blob)
				send_data(data, :type => @file_content.content_type, :filename => @file_content.file_name, :disposition => 'attachment')				
			else
				render_404
			end
		else
			render_404
		end		
	end
	
	def show_activity_log
		if params[:id].present?
			@activity_logs = Api::Template.show_activity_log(params)
			if @activity_logs
				render :layout => false		
			else
				render_404
			end
		else
			render_404
		end	
	end
	
	private
	def cross_domain_access
		headers['Access-Control-Allow-Origin'] = "*"
	end
	
end
