class Api::Template < ActiveRecord::Base
	attr_accessible :name, :content
	###############
	##Associations
	###############
	has_many :column_types, :dependent => :destroy #so when you delete a user, his column types will be deleted
	has_many :form_values, :dependent => :destroy
	has_many :form_values, :class_name => "FormValue", :foreign_key => :template_id
	has_many :template_library_list, :dependent => :destroy
	has_many :template_data_blob, :dependent => :destroy
	has_many :template_file, :dependent => :destroy
	has_one :template_activity_log, :dependent => :destroy
	acts_as_persistent
	acts_as_token_replace
	
	validates_presence_of :name, :message => 'Name cannot be blank'
	validates_uniqueness_of :name, :message => 'Name must be unique.'
	
	
	def self.save_template(params, locations, requestURL)
		if params[:template_type] == 'new_form'
			if params[:id].present?			
				@template = self.find_by_id(params[:id].to_i)
			else
				form_data = {
						:name => params[:name]
				}
				
				@template = self.create(form_data)				
			end
		else
			@template = self.find_by_id(params[:id])
		end
		
		if @template.id.present?
			save_template_library_list(locations)
			save_column_type(params)
			save_template_data_blob(params)
			save_template_image_resize(params, requestURL)			
			save_template_activity_log(params)			
		end
		
		@template.id
	end
	
	def self.save_template_data_blob(params)		
		template_version = TemplateDataBlob.all(:select => 'version', :conditions=>["template_id =?", @template.id], :order => "version DESC").first

		blob_data = {
				:template_id => @template.id,
				:content => params[:content].html_safe,				
				:version => template_version.present? ? template_version.version.to_i + 1 : 1,
				:template_type => params[:template_type]
		}
		
		if @template.template_library_list.find_by_template_library_id(params[:locations].to_i).is_template_publish
			TemplateDataBlob.create(blob_data)
		else
			template_data_blob = TemplateDataBlob.find_or_initialize_by_template_id(@template.id)
			template_data_blob.content = params[:content].html_safe
			template_data_blob.version = 1
			template_data_blob.template_type = 	params[:template_type]
			template_data_blob.save
		end		
	end	
	
	def self.save_template_library_list(locations)
		if locations[:save_location].present?
			user_locations = locations[:save_location]
			
			user_locations.each do |loc|
				save_library_list(loc.id, @template.id)
			end
		end
	end
	
	def self.save_library_list(libraries_id, template_id)
		@template_library_list = TemplateLibraryList.find_or_initialize_by_template_id_and_template_library_id(template_id, libraries_id)	
		@template_library_list.save
	end
	
	def self.save_template_image_resize(params, requestURL)		
		html_doc = Nokogiri::HTML(params[:content])
		image_element = html_doc.css('img[class="selected_image"]')
		
		require 'RMagick'
		begin
			image_element.each do |element| 
				width = element.attr('width') 
				height = element.attr('height') 
				image_src = element.attr('src').gsub(requestURL, "")
				image_base_path = RAILS_ROOT + "/public"
				image_full_path = image_base_path + image_src
				image_split = image_src.split("/")
				image_name = image_split.last
				base_name = File.basename(image_name, ".*")
				extension = File.extname(image_name)
				image_name_new = base_name + "_" + (width.to_i).to_s + "_" + (height.to_i).to_s + extension
				image_path_new = image_base_path + "/images/upload_template_image/" + image_name_new
				img = Magick::Image::read(image_full_path).first
				thumb = img.resize(width.to_i, height.to_i)
				thumb.write(image_path_new)
			end
		rescue Exception => e
			puts e.to_s	
		end
	end
	
	def self.save_template_activity_log(params)
		if params[:activity_log].present?
			TemplateActivityLog.save_activity_log(params[:activity_log], @template.id)
		end
	end
	
	def self.save_column_type(params)
		#puts params[:column]
		if params[:column].present?
			params[:column].each do |index, fields|
				fields.each do |index, attributes|
					#puts attributes['name']
					
					master_data = { 
						:title => attributes['name'],
						:description => attributes['data-description'],
						:template_id => @template.id
					}
					
					ColumnType.create(master_data) if ColumnType.find_by_title(attributes['name']).blank?
				end
			end
		end
	end
	
	def self.save_template_old(params, template_id, locations)
		if locations[:save_location].present?
			user_locations = locations[:save_location]
			template_version = TemplateDataBlob.all(:select => 'version', :conditions=>["template_id =?", template_id], :order => "version DESC").first
			temp_version = template_version.present? ? template_version.version.to_i : 1
			template_name = make_version_number(params[:name].gsub(" ", "_"), template_id, temp_version)
			
			user_locations.each do |loc|
				create_template_file(params[:content], template_name, loc.path)
			end
		end
	end
	
	def self.create_template_file(data, template_name, path)
		dir = "#{SIMPLIFYMD_APP_ROOT}#{path}"
		if File.directory?(dir)
			html_infile_path =  File.join(dir, "#{template_name}.html")
			File.open(html_infile_path, 'wb') { |f| f.write data }
		end
	end
	
	def self.make_version_number(filename, template_id, version)
		dir = File.join('template_' + template_id.to_s + '_' + filename + '_' + version.to_s)		
	end	
	
	def self.save_form_template(params)
		if params[:data_json].present? && params[:template_id].present?
			template_data_version = FormValue.all(:select => 'version', :conditions=>["template_id =?", params[:template_id]], :order => "version DESC").first
			template_data_blob = TemplateDataBlob.all(:select => 'id, version', :conditions=>["template_id =?", params[:template_id]], :order => "version DESC").first
			form_value_data = { 
				:value => params[:data_json],
				:template_id => params[:template_id],
				:template_data_blob_id => template_data_blob.id,
				:version => template_data_version.present? ? template_data_version.version.to_i + 1 : 1
			}			
			
			template_library_id = TemplateLibrary.find_by_name(params[:library_type]).id
			if self.find_by_id(params[:template_id].to_i).template_library_list.find_by_template_library_id(template_library_id).is_form_publish
				@form_value = FormValue.create(form_value_data)
			else
				@form_value = FormValue.find_or_initialize_by_template_id(params[:template_id])
				@form_value.value = params[:data_json]
				@form_value.version = 1
				@form_value.template_data_blob_id = template_data_blob.id
				@form_value.save
			end
			template_form_id = @form_value.id
			params[:life_cycle] = 'save_template'
			template_file_array = {}
			persist_plugin(params)
			if params[:file_upload].present?
				template_file_array = save_template_file(params, template_library_id)
			end
			template_file_array['template_form_id'] = template_form_id
			template_file_array
		end	
	end
	
	def self.save_template_file(params, template_library_id)
		template_file_array = {}
		template_file_array["template_files"] = {}
		data_json = JSON.parse(params[:data_json])
		template_file_ids = Array.new
		template_file_element_ids = Array.new
		data_json.each do |controls|
			if controls["controls"].present?
				if controls["controls"]["data-type"] == 'file'
					file_id = controls["controls"]["data-file-id"]
					element_id = controls["controls"]["id"]
					if file_id.present?
						template_file_ids.push(file_id);
						template_file_element_ids.push(element_id);
					end
					if element_id.present?
						template_file_ids.push(file_id);
						template_file_element_ids.push(element_id);
					end
				end
			end
		end
		
		begin
			# Get the files content from template file directoris
			directory = RAILS_ROOT + "/public/template_form_files"
			uploaded_file = params[:file_upload].split(',')
			uploaded_file_element = params[:file_upload_element].split(',')
			
			i = 0;
			uploaded_file.each do |f|
				path = File.join(directory, f)
				if File.exists?(path)
					@file_path = path
					@file_blob = File.read(@file_path)
				else
					@file_blob = nil
				end
				
				if Base64.encode64(@file_blob).size <= 63.megabytes
					template_file_data = TemplateTempFile.find_by_file_name_and_template_id(f, params[:template_id])
					if template_file_data.present?
						file_data = {
							:template_id => params[:template_id],
							:form_value_id => @form_value.id,
							:file_name => f,
							:file_blob => Base64.encode64(@file_blob),
							#:file_blob => Zlib::Deflate.new(nil, -Zlib::MAX_WBITS).deflate(@file_blob , Zlib::FINISH),
							:content_type => template_file_data.content_type
						}
						
						#set max_allowed_packet variable at run time
						ActiveRecord::Base.connection.execute("set global max_allowed_packet=8388608;")
						
						if self.find_by_id(params[:template_id].to_i).template_library_list.find_by_template_library_id(template_library_id).is_form_publish				
							@template_file = TemplateFile.create(file_data)
						else
							if template_file_ids[ i ].present?
								@template_file = TemplateFile.find_by_id(template_file_ids[ i ])
								@template_file.template_id = params[:template_id]
								@template_file.form_value_id = @form_value.id
								@template_file.file_name = f
								@template_file.file_blob = Base64.encode64(@file_blob)
								@template_file.content_type = template_file_data.content_type
								@template_file.save
							else
								@template_file = TemplateFile.create(file_data)
							end
						end
						#remove files after insert into the blob
						TemplateTempFile.remove_temp_file(path, params[:template_id], f)
						#iniatialize template_file_id into array					
						template_file_array["template_files"][ uploaded_file_element[ i ] ] = @template_file.id
					end
				else
					raise NoMemoryError, "Document size must be less than 378KB"
				end
				i = i + 1
			end
		rescue Exception => e
			puts e.to_s	
		end
		template_file_array
	end
	
	def self.create_inking_image(params, requestURL)
		data_json = JSON.parse(params[:data_json])
		signature_file_overlay = nil
		signature_pad_file = nil
		signature_image_file = {}
		begin
			data_json.each do |controls|
				if controls["controls"].present?
					if controls["controls"]["data-type"]=='inking-overlay'
						inking_overlay_output = controls["controls"]["value"]
						if inking_overlay_output.present?
							inking_overlay_width = controls["controls"]["width"]
							inking_overlay_height = controls["controls"]["height"]
							instructions_overlay = JSON.load(inking_overlay_output).map { |h| "line #{h['mx']},#{h['my']} #{h['lx']},#{h['ly']}" } * ' '
							file_name_overlay  = (rand(99999)+rand(99999)+rand(99999)).to_s + ".png"
							tempfile= RAILS_ROOT + "/public/images/upload/signature_" + file_name_overlay
							#system "convert -size 198x55 xc:transparent -stroke blue -draw '#{instructions_overlay}' '#{tempfile}'"
							Open3.popen3("convert -size #{inking_overlay_width}x#{inking_overlay_height} xc:transparent -stroke #145394 -draw @- #{tempfile}") do |input, output, error|
								input.puts instructions_overlay
							end
							signature_file_overlay = requestURL + "/images/upload/signature_" + file_name_overlay
							signature_image_file["overlay_image_file"] = signature_file_overlay
						end
					end
					
					if controls["controls"]["data-type"]=='simple-signature'
						simple_signature_output = controls["controls"]["value"]
						if simple_signature_output.present?
							simple_signature_width = controls["controls"]["width"]
							simple_signature_height = controls["controls"]["height"]
							instructions_simple = JSON.load(simple_signature_output).map { |h| "line #{h['mx']},#{h['my']} #{h['lx']},#{h['ly']}" } * ' '
							file_name_signature  = (rand(99999)+rand(99999)+rand(99999)).to_s + ".png"
							tempfile= RAILS_ROOT + "/public/images/upload/signature_" + file_name_signature
							#system "convert -size 198x55 xc:transparent -stroke blue -draw '#{instructions_simple}' '#{tempfile}'"
							Open3.popen3("convert -size #{simple_signature_width}x#{simple_signature_height} xc:transparent -stroke #145394 -draw @- #{tempfile}") do |input, output, error|
								input.puts instructions_simple
							end
							signature_pad_file = requestURL + "/images/upload/signature_" + file_name_signature
							signature_image_file["simple_image_file"] = signature_pad_file
						end
					end
				end
			end
		rescue Exception => e
			puts e.to_s	
		end		
		signature_image_file
	end
	
	def self.delete_inking_image(params)
		begin
			image_overlay_path = params[:image_path]
			image_split = image_overlay_path.split("/")
			image_name = image_split.last
			delete_full_path = RAILS_ROOT + "/public/images/upload/"
			path = File.join(delete_full_path, image_name)
			FileUtils.rm(path) if !path.blank? && File.exists?(path)
		rescue Exception => e
			puts e.to_s	
		end
	end
	
	def self.persist_plugin(params)
		data_json = (params[:life_cycle] == 'save_template') ? JSON.parse(params[:data_json]) : params[:data_json]
		data_json.each do |controls|
			if controls["controls"]["data-persistent"].present?
				persistent_patterns = controls["controls"]["data-persistent"]
				life_cycle_id = controls["controls"]["data-event"]
				field_val = controls["controls"]["value"]
				if persistent_patterns.length > 1					
					persistent_pattern_ids = persistent_patterns.split(",")
					persistent_pattern_ids.each do |pattern_id|						
						persistent_apply(params, pattern_id, life_cycle_id, field_val)
					end					
				else
					persistent_pattern_ids = persistent_patterns
					persistent_apply(params, persistent_pattern_ids, life_cycle_id, field_val)
				end
			end
		end
	end
	
	def self.persistent_apply(params, pattern_id, life_cycle_id, field_val)
		if life_cycle_id.present?
			template_lify_cycle_event = TemplateLifeCycleEvent.find_by_id(life_cycle_id.to_i)					
			if template_lify_cycle_event.present?
				persistence_data = TemplatePersistent.find_by_id(pattern_id.to_i)
				if persistence_data.present?
					if template_lify_cycle_event.life_cycle_event == params[:life_cycle] && persistence_data.template_life_cycle_event_id == life_cycle_id.to_i					
						if field_val.present?								
							template_data = self.find_by_id(params[:template_id])
							if template_data.present?
								if persistence_data.plugin_name.present?
									template_data.update_persistent(params, persistence_data, field_val)
								end
							end
						end
					end
				end
			end
		end
	end
	
	def self.show_template(params)
		if params[:library_type].present?
		
			template_library_type = params[:library_type]
			template_library_id = TemplateLibrary.find_by_name(template_library_type)
			
			if params[:data_template].present?
				is_publish_template = params[:data_template]=="draft" ? false : true
				condition = ['template_library_list.template_library_id=? AND template_type=? AND template_library_list.is_template_publish = ?', template_library_id, 'new_form', is_publish_template]
			else			
				is_publish_form = params[:data_form]=="draft" ? false : true
				condition = ['template_library_list.template_library_id=? AND template_type=? AND template_library_list.is_template_publish = ? AND template_library_list.is_form_publish = ?', template_library_id, 'new_form', true, is_publish_form]
			end			
			form = TemplateDataBlob.all(:select => 'template_data_blob.template_id, template.name, template.id, (select template_data_blob.version from template_data_blob where template_data_blob.template_id=template.id order by template_data_blob.version DESC limit 1) as version, (select template_data_blob.content from template_data_blob where template_data_blob.template_id=template.id order by template_data_blob.version DESC limit 1) as content, template_library_list.template_library_id', :joins => 'inner join template on template.id = template_data_blob.template_id inner join template_library_list on template_library_list.template_id = template.id', :order => 'template.updated_at DESC', :conditions => condition).uniq
		end
	end
	
	def self.delete_form(params)
		if params[:library_type].present? && params[:form_id].present?
			template_library_type = params[:library_type]
			template_library_id = TemplateLibrary.find_by_name(template_library_type)
			template_library_count = TemplateLibraryList.find_all_by_template_id(params[:form_id].to_i).count		
			@template_library_list = TemplateLibraryList.find_by_template_id_and_template_library_id(params[:form_id], template_library_id)			
			
			if @template_library_list.present? && template_library_count > 1
				@template_library_list.destroy
			else
				self.find_by_id(params[:form_id]).destroy
			end
			
		end
	end
	
	def self.show_template_form(params)
		form_content = {}
		template_content = self.find_by_id(params[:id].to_i)
		if template_content.blank?
			return nil
		end
		template_data_blob = TemplateDataBlob.all(:select => 'version, content', :conditions=>["template_id =?", template_content.id], :order => "version DESC").first
		if template_data_blob.blank?
			return nil
		end
		if params[:form_id].present? && params[:id].present?
			form_values = template_content.form_values.find_by_id(params[:form_id].to_i)
			form_files = template_content.template_file.find_all_by_id(params[:form_id].to_i)
		elsif params[:id].present? && params[:new_form].present?
			form_values = []
			form_files = []
		elsif params[:id].present?
			form_values = template_content.form_values.last
			form_files = template_content.template_file.all(:select => "id", :conditions => ["template_id=?",params[:id].to_i])
		else
			form_values = [];
			form_files = [];
		end
		
		@content_blob = template_data_blob.content
		
		#TODO: make patient_id dynamic
		patient_id = 88
		
		#persist plugin when template from loading
		if !params.include?('library_type')
			persist_parameters = {}		
			persistent_controls = Array.new
			html_doc = Nokogiri::HTML(@content_blob)
			persist_element = html_doc.css('[data-persistent]')
			persist_element.each do |element| 
				data_persistent_id = element['data-persistent']
				data_event_id = element['data-event']
				persistent = {}
				persistent["data-persistent"] = data_persistent_id
				persistent["data-event"] = data_event_id
				persistent_controls.push({"controls" => persistent}) 
			end
			
			if persistent_controls.present?
				persist_parameters[:data_json] = persistent_controls
				persist_parameters[:template_id] = template_content.id
				persist_parameters[:patient_id] = patient_id
				persist_parameters[:life_cycle] = 'load_template'
				persist_plugin(persist_parameters)
			end		
		end
		
		# Convert the token into values
		vars = {}
		vars[:current_patient] = Party.find_by_id(patient_id.to_i) rescue nil
		@content = template_content.replace!(@content_blob, vars)
		
		# Assign content into form content array
		form_content['template_content_replace'] = @content.gsub('/upload/','/upload_template_image/')
		form_content['template_content'] = template_content
		form_content['form_value'] = form_values
		form_content['template_file'] = form_files.to_json
		
		form_content
	end
	
	def self.get_template_version(template_id)
		template_data_blob = TemplateDataBlob.all(:select => 'version', :conditions =>["template_id =?", template_id], :order => "version DESC").first
	end
	
	def self.get_user_location_details(location_id)
		locations = TemplateLibrary.all(:conditions => ["id=?", location_id])
	end
	
	def self.check_existing_template(params)
		exist_template = self.find_by_name(params[:name])
	end
	
	def self.search_template(params)
		keyword = nil
		template_id = nil
		@library_type = nil
		@form_value = []
		@form_value_data = {}
		if params[:data].present?
			params_search = Array.new 
			params[:data].each do |r|			
				params_search.push({r[1]["name"] => r[1]["value"]})
			end			
			params_search.each do |val|
				keyword = val["keyword"] if val["keyword"].present?	
				template_id = val["template_id"] if val["template_id"].present?					
				@library_type = val["library_type"] if val["library_type"].present?					
			end
		elsif params[:template_id].present? && params[:keyword].present?
			keyword = params[:keyword]
			template_id = params[:template_id]	
			@library_type = params[:library_type]	
		end	
		@form_value_data["library_type"] = @library_type
		if keyword.present? && template_id.present?		
			template_data = FormValue.all(:conditions=>["template_id =?", template_id.to_i], :order => "version DESC")
			template_data.each do |data|
				data_json = data.value
				data_json = JSON.parse(data_json)
				data_json.select do |controls|
					field_val = controls["controls"]["value"]					
					if field_val.present?
						if field_val.downcase.include? keyword.downcase
							@form_value	<< data
						end
					end
				end
			end
		end
		@form_value_data["form_value"] = @form_value
		@form_value_data
	end
	
	def self.show_template_file(params)
		TemplateFile.find_by_id(params[:id])
	end
	
	def self.show_activity_log(params)
		TemplateActivityLog.find_by_id(params[:id])
	end
	
	#plugin data auto suggest
	def self.get_patient_name(params)
		if params[:keyword].present?
			@patient_names = Array.new
			persistence_data = TemplatePersistent.find_by_id(params[:data_persistent].to_i)
			if persistence_data.present?
				template_data = self.find_by_id(params[:template_id])
				if template_data.present?
					if persistence_data.plugin_name.present?
						@patient_data = template_data.update_persistent(params, persistence_data, '')
						if @patient_data.present?
							@patient_data.each do |patient|
								@patient_names.push({"id" => patient.id, "value" => (patient.first_name rescue '' + " " + (patient.middle_name rescue '') + " " + patient.last_name rescue '')})
							end
						end
					end
				end
			end
			@patient_names
		end
	end
	
	def self.get_patient_icd9(params)
		if params[:keyword].present?
			@icds = Array.new
			persistence_data = TemplatePersistent.find_by_id(params[:data_persistent].to_i)
			if persistence_data.present?
				template_data = self.find_by_id(params[:template_id])
				if template_data.present?
					if persistence_data.plugin_name.present?
						@icd = template_data.update_persistent(params, persistence_data, '')
						if @icd.present?
							@icd.each do |icd|
								@icds.push({"id" => icd.code, "value" => ("[ " + (icd.code rescue '') + " ] " + (icd.caption rescue ''))})
							end
						end
					end
				end
			end
			@icds
		end
	end
	
end
