class FormValue < ActiveRecord::Base
	attr_accessible :value, :template_data_blob_id, :template_id, :version
	belongs_to :template
	belongs_to :column_type
	has_many :template_file, :dependent => :destroy
end
