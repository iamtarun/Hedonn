class TemplateLibrary < ActiveRecord::Base

	def self.get_library(user_id)
		template_library = self.all(:conditions=>["user_id=? AND status =?", user_id, 1])
	end
end
