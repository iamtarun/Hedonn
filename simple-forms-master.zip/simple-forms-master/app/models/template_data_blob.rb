class TemplateDataBlob < ActiveRecord::Base
	attr_accessible :template_id, :version, :content, :template_type
	
end
