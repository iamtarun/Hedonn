class TemplateTempFile < ActiveRecord::Base
	attr_accessible :file_name, :template_id, :content_type, :user_id
	
	def self.save_temp_file(file_name, content_type, template_id, user_id)
		file_data = {
				:user_id => user_id,
				:template_id => template_id,
				:file_name => file_name,
				:content_type => content_type
		}		
		template_tem_file = self.create(file_data)
	end
	
	def self.remove_temp_file(path, template_id, file_name)		
		FileUtils.rm(path) if !path.blank? && File.exists?(path)
		self.find_by_template_id_and_file_name(template_id, file_name).destroy
	end
end
