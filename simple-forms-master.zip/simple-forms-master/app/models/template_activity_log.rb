class TemplateActivityLog < ActiveRecord::Base
	attr_accessible :template_id, :activity_log
	belongs_to :template
	
	def self.save_activity_log(log_object, template_id)		
		template_activity_log = self.find_or_initialize_by_template_id(template_id)
		template_activity_log.activity_log = log_object.html_safe
		template_activity_log.save
	end
	
	def self.get_activity_log(params)
		self.all(:select => "id, activity_log", :conditions=>["template_id =?", params[:template_id]]).first
	end
end
