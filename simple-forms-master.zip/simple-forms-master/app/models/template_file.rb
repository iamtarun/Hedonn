class TemplateFile < ActiveRecord::Base
	attr_accessible :template_id, :form_value_id, :file_blob, :file_name, :content_type
	belongs_to :template
	belongs_to :form_value
end
