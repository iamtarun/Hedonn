class Template < ActiveRecord::Base
	attr_accessible :name
	###############
	##Associations
	###############
	has_many :column_types, :dependent => :destroy #so when you delete a user, his column types will be deleted
	has_many :form_values, :dependent => :destroy
	has_many :template_library_list, :dependent => :destroy
	has_many :template_data_blob, :dependent => :destroy	
	acts_as_token_replace
	
	def self.show_template_form_value(params)
		@template_form = {}
		if params[:form_id].present?		
			template_data_blob = get_template_blob(params[:form_id])
			if template_data_blob.present?
				#patient_id = self.find(template_data_blob.template_id).patient_id
				patient_id = '88'
				
				vars = {}
				vars[:current_patient] = Patient.find(patient_id) rescue nil
				template_tool = TemplateDataTool.new(template_data_blob.content)
				@content = template_tool.replace!(vars)
				
				@template_form['content'] = @content
				@template_form['template_id'] = params[:form_id]
			end
		end
		return @template_form
	end
	
	def self.get_persistence
		persistence = TemplatePersistent.all(:select => "id, label")
	end
	
	def self.get_template_blob(template_id)
		template_data_blob = TemplateDataBlob.all(:conditions=>["template_id =?", template_id], :order => "version DESC").first
	end
	
	def self.get_user_location(user_id)		
		locations = TemplateLibrary.all(:conditions => ["user_id=?", user_id])
	end
end
