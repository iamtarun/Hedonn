class TemplateLibraryList < ActiveRecord::Base
	attr_accessible :template_id, :template_library_id, :is_form_publish, :is_template_publish
	belongs_to :template
	belongs_to :template_library
end
