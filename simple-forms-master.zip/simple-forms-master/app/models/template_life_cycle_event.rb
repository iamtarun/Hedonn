class TemplateLifeCycleEvent < ActiveRecord::Base

	def self.get_template_event
		template_life_cycle_event = self.all(:select => 'id, life_cycle_event')
	end
end
