class TemplateDataTool
  #new regex to handle broken parens
  REGEX = /\$\[\[\(?([a-zA-Z0-9_-]+)\)?(?:\(?((?:[a-zA-Z0-9\. '"_-]+,?)+)\)?)?\]\]/
  def initialize(data)
    @data = data
  end

  def data
    @data
  end

  def replace!(vars={})
    replace_data(@data,vars)
  end

  def validate_data
    validate_template(@data)
  end

  protected

  def replace_data(rdata, vars)
    tvas = {}
    rdata1 = rdata.dup
    vars[:today] = Time.zone.now.to_date # Override everybody who passes us Date.today. =P
    #vars[:today] = Time.now.to_date
    TemplateVariableAbbreviation.find(:all).each {|tva| tvas[tva.abbreviation]=tva.variable}
    vars.each {|key, value| eval "@#{key} = vars[:#{key}]" }
    unless rdata1.nil?
      while match = rdata1.match(REGEX)
      var=match[0] rescue 'VAR-MISSING'
      varname=match[1] rescue 'VAR-MISSING'
      varparams=match[2].split(',') rescue []
      varcode = tvas.has_key?(varname) ? tvas[varname] : nil
      varcode = expand_parameters(varcode,varparams)
      rdata1.sub!(REGEX, varcode ? (eval(varcode).to_s rescue '') : "!![[#{varname}]]!!")
    end
    end
    rdata1
  end

  def expand_parameters(code,params)
    index=1
    params.each do |p|
      code=code.gsub("##{index}#",p.to_s)
      index+=1
    end
    code
  end

  def validate_template(rdata)
    rdata_copy = rdata.dup
    tvas = {}
    errors = []
    TemplateVariableAbbreviation.find(:all).each {|tva| tvas[tva.abbreviation]=tva.variable}
    while match = rdata_copy.match(REGEX)
      errors << "$[[#{match[1]}]]" if !tvas.has_key?(match[1])
      rdata_copy.sub!(REGEX, "") #this is so we can just get the next one
    end
    return errors
  end

end
