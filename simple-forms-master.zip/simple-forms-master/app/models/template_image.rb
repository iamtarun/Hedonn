class TemplateImage < ActiveRecord::Base
	attr_accessible :user_id, :image_name
	
	def self.save_image(name, user_id)
		image_data = {
				:user_id => user_id,
				:image_name => name
		}
		template_image = self.create(image_data)
		@template_image_id = template_image.id
	end
	
	def self.get_template_image(user_id)
		self.all(:conditions => ['user_id=?', user_id])
	end
	
	def self.delete_image(params)
		if params[:id].present?
			template_image = self.find(params[:id].to_i)
			directory = RAILS_ROOT + "/public/images/upload"
			path = File.join(directory, template_image.image_name)
			FileUtils.rm(path) if !path.blank? && File.exists?(path)
			self.find(params[:id]).destroy			
		end
	end

end
