class TemplatePersistent < ActiveRecord::Base
	attr_accessible :label, :plugin_name, :template_life_cycle_event_id, :url
	
	def self.get_persistent_url(params)
		self.find_by_id(params[:data_persistent]).url
	end
end
