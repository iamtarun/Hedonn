class ColumnType < ActiveRecord::Base
	attr_accessible :title, :description, :template_id
	belongs_to :template
end
