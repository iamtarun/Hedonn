# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of Active Record to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20130708102600) do

# Could not dump table "activity_log" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "activity_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "address_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "administrator_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "affiliation_specialty" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "app_query" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "app_query_category" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "app_query_parameter" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "app_query_report_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "app_query_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "appointment" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "appointment_custom_field_value" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "appointment_label" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "appointment_status" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "appointment_status_change_reason" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "appointment_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_activity" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_activity_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_container_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_custom_field_value" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_data" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_data_blob" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_data_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_external_job" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_label" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_metadata" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_mime_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_selector" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_selector_label" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_selector_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_selector_rule" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_selector_rule_label" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_source_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "artifact_static_location" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "audit", :force => true do |t|
    t.integer  "auditable_id"
    t.string   "auditable_type"
    t.integer  "user_id"
    t.string   "user_type"
    t.string   "username"
    t.string   "action"
    t.integer  "activity_log_id"
    t.text     "changes"
    t.integer  "version",         :default => 0
    t.datetime "created_at",                     :null => false
    t.datetime "updated_at",                     :null => false
    t.integer  "lock_version",    :default => 0, :null => false
  end

  add_index "audit", ["auditable_id", "auditable_type"], :name => "auditable_index"
  add_index "audit", ["created_at"], :name => "index_audit_on_created_at"
  add_index "audit", ["user_id", "user_type"], :name => "user_index"

# Could not dump table "automatemeasure" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "backup_log", :force => true do |t|
    t.string   "device"
    t.string   "serial_number"
    t.string   "make"
    t.string   "model"
    t.string   "disk_size"
    t.string   "disk_used_before"
    t.string   "disk_available_before"
    t.string   "disk_used_after"
    t.string   "disk_available_after"
    t.string   "bundles"
    t.boolean  "error"
    t.datetime "start_time"
    t.datetime "end_time"
    t.datetime "created_at",                           :null => false
    t.datetime "updated_at",                           :null => false
    t.integer  "lock_version",          :default => 0, :null => false
    t.string   "backup_size"
    t.string   "backup_type"
    t.string   "error_message"
  end

# Could not dump table "blood_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "care_unit_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "charge_capture", :force => true do |t|
    t.integer  "cc_transaction_id"
    t.integer  "patient_id"
    t.integer  "physician_id"
    t.integer  "provider_id"
    t.integer  "insurance_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "patient_medical_procedure_id"
    t.integer  "patient_problem_id"
    t.integer  "amount",                       :limit => 10, :precision => 10, :scale => 0
    t.text     "note"
    t.integer  "appointment_id"
    t.string   "copay"
    t.string   "payment_method"
  end

  create_table "charge_capture_code", :force => true do |t|
    t.integer  "cc_code_id"
    t.integer  "cc_transaction_id"
    t.integer  "code"
    t.integer  "value"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "clinician_affiliation" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "clinician_specialty" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "clinician_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "code_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "column_type", :force => true do |t|
    t.string   "title",       :null => false
    t.text     "description"
    t.integer  "template_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "communication_channel" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "condition_disposition", :force => true do |t|
    t.string   "name"
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
  end

# Could not dump table "cpt" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "cpt_charge_capture", :force => true do |t|
    t.integer  "charge_capture_id"
    t.integer  "pmp_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "cpt_type", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "cpt_id"
  end

# Could not dump table "cpt_version" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "create_template_file", :force => true do |t|
    t.integer  "template_id",                         :null => false
    t.integer  "form_value_id",                       :null => false
    t.text     "file_blob",     :limit => 2147483647
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "custom_field" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "custom_field_category" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "custom_field_default_value" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "custom_field_namespace" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "custom_field_namespace_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "custom_field_property" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "custom_field_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "custom_field_scope" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "custom_field_set", :force => true do |t|
    t.integer  "face_sheet_section_id"
    t.string   "name"
    t.integer  "record_status_id",      :default => 1, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "custom_field_set_association", :force => true do |t|
    t.integer  "custom_field_set_id"
    t.integer  "custom_field_id"
    t.integer  "record_status_id",    :default => 1
    t.integer  "position"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "custom_field_type", :force => true do |t|
    t.string   "name"
    t.integer  "record_status_id", :default => 1, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "custom_field_type_value", :force => true do |t|
    t.integer  "custom_field_type_id"
    t.string   "name"
    t.integer  "record_status_id",     :default => 1, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "data_entry_action" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "data_entry_activity" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "data_entry_activity_scope" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "data_entry_activity_value_format" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "disposition" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "drawer_folder" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "dxm_entry", :force => true do |t|
    t.string   "code"
    t.text     "caption"
    t.integer  "pmp_id"
    t.integer  "patient_problem_id"
    t.integer  "charge_capture_id",  :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "dxnum", :force => true do |t|
    t.string   "code"
    t.text     "caption"
    t.integer  "pmp_id"
    t.integer  "cc_transaction_id", :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "education_level" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "email_address_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "employment_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "encounter" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "encounter_note" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "encounter_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "episode" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "episode_encounter" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "ethnicity" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "ext_state_provider" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "external_job" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "face_sheet_section" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "face_sheet_section_extension" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "face_sheet_style" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "face_sheet_style_spec" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "face_sheet_style_spec_label_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "face_sheet_style_spec_problem_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "face_sheet_style_spec_procedure_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "face_sheet_style_spec_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "family_relationship" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "fax_system_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "feed" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "feed_access" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "feed_param" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "feed_recent_access" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "feed_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "filing_center_group_metadata_rule" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "folder_label_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "form_value", :force => true do |t|
    t.integer  "template_data_blob_id"
    t.text     "value",                 :limit => 2147483647, :null => false
    t.integer  "template_id"
    t.integer  "version"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "free_text_widget" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "gender" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "icd" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "icd_version" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "immunization" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "immunization_location", :force => true do |t|
    t.string   "caption",                         :null => false
    t.integer  "record_status_id", :default => 1, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "immunization_lookup", :force => true do |t|
    t.integer  "immunization_version_id",                :null => false
    t.string   "code",                                   :null => false
    t.string   "caption",                                :null => false
    t.string   "description"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "lock_version",            :default => 0, :null => false
    t.string   "manufacturer_name"
    t.string   "manufacturer_code"
  end

  create_table "immunization_version", :force => true do |t|
    t.integer  "year",                            :null => false
    t.string   "source",                          :null => false
    t.integer  "code_type_id",                    :null => false
    t.boolean  "active",       :default => false, :null => false
    t.integer  "position",                        :null => false
    t.text     "seed_name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "lock_version", :default => 0,     :null => false
  end

# Could not dump table "insurance_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "lab_result" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "lab_result_set" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "lab_result_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "label" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "label_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "label_scope" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "license" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "living_arrangement" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "log_level" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "maintenance_schedule", :force => true do |t|
    t.time     "business_start",      :default => '2000-01-01 08:30:00', :null => false
    t.time     "business_end",        :default => '2000-01-01 17:30:00', :null => false
    t.time     "nightly",             :default => '2000-01-01 04:00:00', :null => false
    t.integer  "annual_month_number", :default => 5,                     :null => false
    t.integer  "annual_day_number",   :default => 4,                     :null => false
    t.time     "annual_time",         :default => '2000-01-01 03:00:00', :null => false
    t.integer  "monthly_day_number",  :default => 15,                    :null => false
    t.time     "monthly_time",        :default => '2000-01-01 03:00:00', :null => false
    t.integer  "weekly_day",          :default => 0,                     :null => false
    t.time     "weekly_time",         :default => '2000-01-01 03:00:00', :null => false
    t.datetime "created_at",                                             :null => false
    t.datetime "updated_at",                                             :null => false
    t.integer  "lock_version",        :default => 0,                     :null => false
  end

  create_table "mashup", :force => true do |t|
    t.string   "type"
    t.string   "url"
    t.string   "name"
    t.string   "seed_name"
    t.string   "descriptions"
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
  end

# Could not dump table "mashup_extension" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "measure", :force => true do |t|
    t.string   "name"
    t.text     "helptext"
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
  end

# Could not dump table "medical_record" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "medication", :force => true do |t|
    t.string   "name"
    t.integer  "position"
    t.datetime "created_at",                      :null => false
    t.datetime "updated_at",                      :null => false
    t.integer  "lock_version",     :default => 0, :null => false
    t.string   "code"
    t.string   "brandname"
    t.integer  "record_status_id", :default => 1, :null => false
  end

  add_index "medication", ["name"], :name => "index_medication_on_name"

# Could not dump table "medication_status" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_action" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_artifact_document" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_custom_field_value" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_group" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_label" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_priority" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_recipient" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_recipient_group" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_status" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_subject" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "message_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "metrofax_receiver", :force => true do |t|
    t.string   "user_id"
    t.string   "password"
    t.string   "path"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "model_callback" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "modifier", :force => true do |t|
    t.string   "code"
    t.text     "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "navigation_item" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "navigation_item_extension" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_artifact" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_classification" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_event" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_event_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_extension" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_extension_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_namespace" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_participant" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_participant_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_status_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_type_license" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_value" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_value_flag_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_value_range" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_value_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_value_unit" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "observation_value_unit_conversion" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_content_contribution" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_content_contribution_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_custom_action" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_custom_field_value" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_identifier" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_label" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_model_display_name_method" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_relationship" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_relationship_label" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "party_relationship_type", :force => true do |t|
    t.boolean  "system",          :default => false, :null => false
    t.string   "name",                               :null => false
    t.string   "seed_name"
    t.integer  "source_model_id"
    t.string   "description"
    t.datetime "created_at",                         :null => false
    t.datetime "updated_at",                         :null => false
    t.integer  "lock_version",    :default => 0,     :null => false
  end

  add_index "party_relationship_type", ["name"], :name => "index_party_relationship_type_on_name"
  add_index "party_relationship_type", ["system"], :name => "index_party_relationship_type_on_system"

# Could not dump table "party_setting" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "party_setting_property" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_clinician" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "patient_custom_field_set", :force => true do |t|
    t.integer  "face_sheet_section_id"
    t.date     "capture_date"
    t.integer  "patient_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "patient_custom_field_set_statistic", :force => true do |t|
    t.integer  "patient_id"
    t.integer  "custom_field_id"
    t.integer  "record_status_id",                                           :default => 1, :null => false
    t.string   "value_text"
    t.integer  "value_int"
    t.date     "value_date"
    t.decimal  "value_decimal",               :precision => 15, :scale => 3
    t.boolean  "value_boolean"
    t.date     "capture_date"
    t.integer  "patient_custom_field_set_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "patient_employer" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_face_sheet_event" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_family_history" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_insurance" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_insurance_authorization" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_medical_procedure" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_medication" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_note" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_patient_search" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_problem" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_problem_status" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_quick_code" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "patient_reporting_code", :force => true do |t|
    t.integer  "patient_id",                                                  :null => false
    t.string   "code",                                                        :null => false
    t.integer  "modifier"
    t.string   "caption"
    t.integer  "code_type_id"
    t.datetime "occurrence_date"
    t.string   "occurrence_date_approx"
    t.text     "comments",               :limit => 2147483647
    t.integer  "record_status_id",                             :default => 1, :null => false
    t.integer  "lock_version",                                 :default => 0, :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "patient_search_association" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_search_ratio" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_social_history" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "patient_vital_statistic" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "person_title" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "phone_number_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "phr_viewable_status", :force => true do |t|
    t.string   "name"
    t.string   "description"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "plugin_code", :force => true do |t|
    t.string   "name",                        :null => false
    t.string   "seed_name",                   :null => false
    t.text     "code",                        :null => false
    t.integer  "position",                    :null => false
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
  end

  create_table "pmdnm_backup", :id => false, :force => true do |t|
    t.integer  "id",                   :default => 0, :null => false
    t.string   "model_name"
    t.string   "display_name"
    t.string   "send_message"
    t.string   "view_message"
    t.string   "list_message"
    t.string   "schedule"
    t.string   "schedule_list"
    t.string   "schedule_view"
    t.string   "display_name_profile"
    t.string   "seed_name"
    t.integer  "record_status_id",     :default => 1, :null => false
    t.datetime "created_at",                          :null => false
    t.datetime "updated_at",                          :null => false
    t.integer  "lock_version",         :default => 0, :null => false
  end

# Could not dump table "preferred_language" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "primary_specialty", :force => true do |t|
    t.string   "specialty"
    t.string   "taxonomy_code"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "process_status" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "process_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_artifact" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_classification" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_event" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_event_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_extension" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_extension_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_namespace" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_participant" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_participant_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_status_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_task" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_task_flag_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_task_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "project_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "quick_code" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "race" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "rcopia_ans_url_cache", :force => true do |t|
    t.datetime "last_update"
    t.string   "web_browser_url"
    t.string   "win_upload_url"
    t.string   "engine_upload_url"
    t.string   "engine_download_url"
    t.string   "win_download_url"
    t.string   "link_upload_url"
    t.datetime "created_at",                         :null => false
    t.datetime "updated_at",                         :null => false
    t.integer  "lock_version",        :default => 0, :null => false
  end

  create_table "rcopia_error", :force => true do |t|
    t.text     "message"
    t.text     "backtrace"
    t.text     "request"
    t.text     "details"
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
  end

  create_table "rcopia_last_update_date", :force => true do |t|
    t.string   "command"
    t.string   "patient_identifier"
    t.string   "last_update_date"
    t.datetime "created_at",                                     :null => false
    t.datetime "updated_at",                                     :null => false
    t.integer  "sync_status",        :limit => 1, :default => 1, :null => false
    t.integer  "lock_version",                    :default => 0, :null => false
    t.integer  "sync_statuss",                    :default => 1
  end

# Could not dump table "rcopia_medication_allergy" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "rcopia_notification", :force => true do |t|
    t.text     "content"
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
  end

# Could not dump table "rcopia_patient_prescription" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "rcopia_updateable_record", :force => true do |t|
    t.string   "rcopia_identifier"
    t.string   "patient_identifier"
    t.text     "properties"
    t.string   "command"
    t.datetime "created_at",                        :null => false
    t.datetime "updated_at",                        :null => false
    t.integer  "lock_version",       :default => 0, :null => false
  end

  create_table "record_status", :force => true do |t|
    t.string "name"
    t.string "seed_name"
    t.string "description"
  end

# Could not dump table "referral_source" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "religion" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "search", :force => true do |t|
    t.string   "name",                            :null => false
    t.text     "search",                          :null => false
    t.datetime "created_at",                      :null => false
    t.datetime "updated_at",                      :null => false
    t.integer  "lock_version", :default => 0,     :null => false
    t.string   "type"
    t.boolean  "realtime",     :default => false
  end

  create_table "search_association_backup", :id => false, :force => true do |t|
    t.integer  "id",                :default => 0, :null => false
    t.integer  "patient_search_id",                :null => false
    t.text     "notifications"
    t.text     "care_suggestions"
    t.datetime "created_at",                       :null => false
    t.datetime "updated_at",                       :null => false
    t.integer  "lock_version",      :default => 0, :null => false
  end

  create_table "search_backup", :id => false, :force => true do |t|
    t.integer  "id",           :default => 0, :null => false
    t.string   "name",                        :null => false
    t.text     "search",                      :null => false
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
    t.string   "type"
  end

  create_table "search_ratio_backup", :id => false, :force => true do |t|
    t.integer  "id",                                                     :default => 0, :null => false
    t.string   "name",                                                                  :null => false
    t.integer  "target_search_id",                                                      :null => false
    t.integer  "sample_search_id",                                                      :null => false
    t.decimal  "cached_ratio",             :precision => 6, :scale => 4
    t.datetime "cache_expires_at"
    t.datetime "created_at",                                                            :null => false
    t.datetime "updated_at",                                                            :null => false
    t.integer  "lock_version",                                           :default => 0, :null => false
    t.integer  "cached_denominator_count"
    t.integer  "cached_numerator_count"
    t.string   "measure_number"
    t.integer  "physician_id"
    t.date     "encounter_from_date"
    t.date     "encounter_to_date"
  end

# Could not dump table "secret_question" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "session", :force => true do |t|
    t.string   "session_id",                       :null => false
    t.text     "data",       :limit => 2147483647
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "session", ["session_id"], :name => "index_session_on_session_id"
  add_index "session", ["updated_at"], :name => "index_session_on_updated_at"

  create_table "simple_captcha_data", :force => true do |t|
    t.string   "key",          :limit => 40
    t.string   "value",        :limit => 6
    t.datetime "created_at",                                :null => false
    t.datetime "updated_at",                                :null => false
    t.integer  "lock_version",               :default => 0, :null => false
  end

# Could not dump table "smoking_status" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "social_history_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "spec_source", :force => true do |t|
    t.string   "name"
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
  end

# Could not dump table "specialty" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "standard_demo_appointments", :id => false, :force => true do |t|
    t.integer  "care_unit_id"
    t.integer  "provider_organization_id",                           :null => false
    t.integer  "patient_id",                                         :null => false
    t.integer  "clinician_id"
    t.text     "public_id"
    t.integer  "appointment_type_id",                                :null => false
    t.integer  "scheduled_by_id"
    t.integer  "appointment_status_id"
    t.integer  "appointment_status_change_reason_id"
    t.datetime "scheduled_start_time"
    t.datetime "check_in_time"
    t.datetime "check_out_time"
    t.datetime "dictation_recorded"
    t.datetime "dictation_transcribed"
    t.datetime "documentation_time"
    t.text     "comments"
    t.text     "documentation"
    t.datetime "created_at",                                         :null => false
    t.datetime "updated_at",                                         :null => false
    t.integer  "lock_version",                        :default => 0, :null => false
  end

  create_table "standard_demo_message_recipients", :id => false, :force => true do |t|
    t.integer "user_id",                              :null => false
    t.integer "message_id",                           :null => false
    t.integer "message_action_id"
    t.boolean "closed",            :default => false, :null => false
  end

  create_table "standard_demo_messages", :id => false, :force => true do |t|
    t.integer  "id",                  :default => 0,     :null => false
    t.integer  "message_type_id",                        :null => false
    t.integer  "message_priority_id",                    :null => false
    t.integer  "message_status_id",                      :null => false
    t.integer  "message_subject_id",                     :null => false
    t.integer  "from_user_id"
    t.integer  "parent_id"
    t.integer  "patient_id"
    t.integer  "care_unit_id"
    t.datetime "expires_at"
    t.string   "subject_other"
    t.text     "body"
    t.boolean  "patient_viewable",    :default => false, :null => false
  end

# Could not dump table "storage_unit" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "storage_unit_allow_notify_labeled_group" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "storage_unit_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "suggested_filename" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "system_setting" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "system_setting_property" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "system_statistic" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "system_statistic_section" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "system_statistic_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "template", :force => true do |t|
    t.string   "name",       :null => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_activity_log", :force => true do |t|
    t.integer  "template_id",                        :null => false
    t.text     "activity_log", :limit => 2147483647
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_data_blob", :force => true do |t|
    t.integer  "template_id",                         :null => false
    t.integer  "version"
    t.text     "content",       :limit => 2147483647
    t.string   "template_type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_file", :force => true do |t|
    t.integer  "template_id",                         :null => false
    t.integer  "form_value_id",                       :null => false
    t.text     "file_name"
    t.binary   "file_blob",     :limit => 2147483647
    t.string   "content_type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_image", :force => true do |t|
    t.integer  "user_id",    :null => false
    t.text     "image_name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_library", :force => true do |t|
    t.integer  "user_id"
    t.string   "name",       :null => false
    t.string   "path"
    t.string   "url"
    t.integer  "status"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_library_list", :force => true do |t|
    t.integer  "template_id",                            :null => false
    t.integer  "template_library_id",                    :null => false
    t.boolean  "is_template_publish", :default => false
    t.boolean  "is_form_publish",     :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_life_cycle_event", :force => true do |t|
    t.string   "life_cycle_event"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_persistent", :force => true do |t|
    t.string   "label"
    t.integer  "template_life_cycle_event_id"
    t.string   "plugin_name"
    t.text     "url"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "template_temp_file", :force => true do |t|
    t.integer  "user_id",      :null => false
    t.integer  "template_id",  :null => false
    t.text     "file_name"
    t.string   "content_type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "template_variable_abbreviation" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "test_type", :force => true do |t|
    t.string   "name"
    t.datetime "created_at",                  :null => false
    t.datetime "updated_at",                  :null => false
    t.integer  "lock_version", :default => 0, :null => false
  end

# Could not dump table "user" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "user_access_to_patients_restriction", :force => true do |t|
    t.integer  "user_id"
    t.integer  "patient_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

# Could not dump table "user_agreement" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_batched_artifact" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_group" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_group_member" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_login_restriction" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_message_filter" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_preference" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_preference_property" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_recent_patient" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "user_secret_question" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_table "user_session", :force => true do |t|
    t.integer  "user_id"
    t.string   "session_id",                                         :null => false
    t.string   "client_ip_address",                                  :null => false
    t.text     "client_cookies_at_login",                            :null => false
    t.text     "client_cookies_at_logout"
    t.text     "client_prerequisites_validation"
    t.string   "client_host",                                        :null => false
    t.string   "browser_info",                                       :null => false
    t.datetime "login_time",                                         :null => false
    t.datetime "logout_time"
    t.boolean  "time_out",                        :default => false, :null => false
    t.datetime "created_at",                                         :null => false
    t.datetime "updated_at",                                         :null => false
    t.integer  "lock_version",                    :default => 0,     :null => false
  end

# Could not dump table "user_tool_bar" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "variant_value_constraint" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "variant_value_constraint_option" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "variant_value_constraint_property" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "variant_value_select_style" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "variant_value_type" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "virtual_user_group_label" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "vital_statistic" because of following NoMethodError
#   private method `print' called for nil:NilClass

# Could not dump table "vital_statistic_set" because of following NoMethodError
#   private method `print' called for nil:NilClass

  create_view "custom_field_set_association_as", "select `custom_field_set_association`.`custom_field_set_id` AS `custom_field_set_id`,`custom_field_set_association`.`custom_field_id` AS `custom_field_id`,`custom_field_set_association`.`position` AS `position`,`custom_field_set_association`.`created_at` AS `created_at`,`custom_field_set_association`.`updated_at` AS `updated_at` from `custom_field_set_association`", :force => true do |v|
    v.column :custom_field_set_id
    v.column :custom_field_id
    v.column :position
    v.column :created_at
    v.column :updated_at
  end

  create_view "face_sheet_style_spec_label_restriction_as", "select `face_sheet_style_spec_label_restriction`.`face_sheet_style_spec_id` AS `face_sheet_style_spec_id`,`face_sheet_style_spec_label_restriction`.`label_id` AS `label_id`,`face_sheet_style_spec_label_restriction`.`created_at` AS `created_at`,`face_sheet_style_spec_label_restriction`.`updated_at` AS `updated_at` from `face_sheet_style_spec_label_restriction`", :force => true do |v|
    v.column :face_sheet_style_spec_id
    v.column :label_id
    v.column :created_at
    v.column :updated_at
  end

  create_view "folder_label_restriction_as", "select `folder_label_restriction`.`folder_id` AS `folder_id`,`folder_label_restriction`.`label_id` AS `label_id`,`folder_label_restriction`.`created_at` AS `created_at`,`folder_label_restriction`.`updated_at` AS `updated_at` from `folder_label_restriction`", :force => true do |v|
    v.column :folder_id
    v.column :label_id
    v.column :created_at
    v.column :updated_at
  end

  create_view "party_label_as", "select `party_label`.`party_id` AS `party_id`,`party_label`.`label_id` AS `label_id`,`party_label`.`created_at` AS `created_at`,`party_label`.`updated_at` AS `updated_at` from `party_label`", :force => true do |v|
    v.column :party_id
    v.column :label_id
    v.column :created_at
    v.column :updated_at
  end

  create_view "storage_unit_allow_notify_labeled_group_as", "select `storage_unit_allow_notify_labeled_group`.`folder_id` AS `folder_id`,`storage_unit_allow_notify_labeled_group`.`label_id` AS `label_id`,`storage_unit_allow_notify_labeled_group`.`created_at` AS `created_at`,`storage_unit_allow_notify_labeled_group`.`updated_at` AS `updated_at`,`storage_unit_allow_notify_labeled_group`.`lock_version` AS `lock_version` from `storage_unit_allow_notify_labeled_group`", :force => true do |v|
    v.column :folder_id
    v.column :label_id
    v.column :created_at
    v.column :updated_at
    v.column :lock_version
  end

  create_view "user_activity", "select `al`.`id` AS `id`,`us`.`user_id` AS `user_id`,`al`.`activity_type_id` AS `activity_type_id`,`al`.`activity` AS `activity`,`al`.`created_at` AS `activity_time` from (`user_session` `us` join `activity_log` `al`) where (`us`.`id` = `al`.`user_session_id`)", :force => true do |v|
    v.column :id
    v.column :user_id
    v.column :activity_type_id
    v.column :activity
    v.column :activity_time
  end

end
