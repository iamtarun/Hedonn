def run_sql(sql)
  print "Running SQL \"#{sql}\"\n"
  ActiveRecord::Base.connection.execute sql
end

# Make sure we don't crash if we have a hand-created batch print label
run_sql "update label set seed_name='Office Documents - Batch Print', system=1 where label='Batch Print' and seed_name is NULL;"

# Add HL7 codes for races and ethnicities
run_sql "update race set hl7_code='1002-5' where seed_name='American Indian or Alaska Native';"
run_sql "update race set hl7_code='2028-9' where seed_name='Asian';"
run_sql "update race set hl7_code='2054-5' where seed_name='Black or African American';"
run_sql "update race set hl7_code='2076-8' where seed_name='Native Hawaiian or Other Pacific Islander';"
run_sql "update race set hl7_code='2106-3' where seed_name='White';"
run_sql "update race set hl7_code='2131-1' where seed_name='Other Race';"
run_sql "update ethnicity set hl7_code='H' where seed_name='Hispanic or Latino';"
run_sql "update ethnicity set hl7_code='NH' where seed_name='Not Hispanic or Latino';"
run_sql "update ethnicity set hl7_code='U' where seed_name='Unknown';"

# Rename some face sheet widgets
run_sql "update face_sheet_section set heading='Problem List' where heading='Patient Problem';"
run_sql "update face_sheet_section set heading='Lab Orders' where heading='Lab Result Sets';"
run_sql "update face_sheet_section set heading='Lab Results' where heading='Lab Test Results';"

# Split up some of the widgets that re-used the same partial; doing so breaks the fold/unfold javascript
run_sql "update face_sheet_section set partial='patient_upcoming_appointment' where name='patient_upcoming_appointment';"
run_sql "update face_sheet_section set partial='patient_previous_appointment' where name='patient_previous_appointment';"
run_sql "update face_sheet_section set partial='patient_appointment' where name='patient_upcoming_appointment';"
run_sql "update face_sheet_section set partial='patient_appointment' where name='patient_previous_appointment';"

# Re-map problem statuses to map the new problems widget
run_sql "update patient_problem_status set name='Inactive', seed_name='Inactive' where id=2;"
run_sql "update patient_problem_status set name='Sub-acute', seed_name='Sub-acute' where id=6;"
run_sql "update patient_problem_status set name='Error', seed_name='Error' where id=7;"

# Apply correct name to support user.  For some reason it's not working in simplifyMD:seed:admin_user
run_sql "update party set first_name='Tier 1 Support', last_name='simplifyMD' where id=(select person_id from user where login='simplifyMD.support.tier-1');"

# Kick up the default word length system setting to something reasonable.  We'll probably just remove this later.
run_sql "update system_setting set value_int=80 where value_int=5 and system_setting_property_id in (select id from system_setting_property where seed_name='Maximum word length of suggested file name in Filing Center');"

# Reseed the template variables
puts 'Reseeding template variables'

`#{Rails.root.join('bin/seed-template-variables.sh')}`.each_line do |l|
  run_sql l.chomp
end

puts 'Removing invalid "Other" entries from race and ethnicity tables'
# Remove invalid "Other" entries from race and ethnicity tables
run_sql "update party set race_id=(select id from race where name='Patient Declined') where race_id=(select id from race where name='Other Race');"
run_sql "delete from race where name='Other Race';"
run_sql "update party set ethnicity_id=(select id from ethnicity where name='Patient Declined') where ethnicity_id=(select id from ethnicity where name='Other');"
run_sql "delete from ethnicity where name='Other';"

# Remove RSS and iCal system settings
run_sql "delete from system_setting where system_setting_property_id in (select id from system_setting_property where seed_name in ('Show iCal feeds in Schedule','Show RSS feeds in Task Center'));"
run_sql "delete from system_setting_property where seed_name in ('Show iCal feeds in Schedule','Show RSS feeds in Task Center');"

# Emergency phone number type
run_sql "update communication_channel set phone_number_type_id=(select id from phone_number_type where seed_name='Emergency Contact') where phone_number_type_id=(select id from phone_number_type where seed_name='Emergency');"
run_sql "delete from phone_number_type where seed_name='Emergency';"

# Remap all spuriously creates notes to chart from signatures
run_sql "update message set message_type_id=(select id from message_type where seed_name='Signature Note') where message_type_id=(select id from message_type where seed_name='Note to Chart') and subject_other='Signature';"

#save all Cpt type
['Encounter_CPT', 'Operational_CPT', 'HCPS_CPT', 'Labs_CPT'].each do |name|
  cptType = CptType.find_or_initialize_by_name(:name => name)
	cptType.save	
end

#save all Modifier code and description
[["21", "Prolonged E/M service"], ["22", "Specific unusual or difficult services"], ["23", "Unusual anesthesia"], ["24", "Unrelated E/M or eye exam during post-op by same provider"], ["25", "Separate E/M on the same day as another service by same provider"], ["26", "Professional component"], ["2P", "PQRI Performance Measure Exclusion due to patient reason"], ["32", "Services related to mandated consultation and or related service"], ["3P", "PQRI Performance Measure Exclusion due to system reason"], ["47", "Anesthesia by surgeon"], ["50", "Bilateral procedure"], ["51", "Multiple surgical procedures on same day"],["52", "Less than usual service"], ["53", "Discontinued Procedure"], ["54", "Surgical procedure only, no follow-up care"], ["55", "Follow-up care only"], ["56", "Pre-operative management only"], ["57", "Decision for surgery"], ["58", "Related service by same physician during post-operative"], ["59", "Distinct procedural service"], ["8P", "PQRI Performance Reporting-action not performed, reason NOS"], ["91", "Repeat clinical diagnostic laboratory test"], ["99", "Multiple modifiers"], ["TC", "Technical Component"]].each do |index|
	modifier = Modifier.find_or_initialize_by_code(index[0])
	modifier.description = index[1]
	modifier.save
end
#save all primary specialty and taxonomy code
[["Adult Reconstructive Orthopedics", "207XS0114X"], ["Nutrition", "111NN1001X"], ["Allergy", "207KA0200X"], ["Obstetrics", "207VX0000X"], ["Allergy/Immunology", "207K00000X"], ["Obstetrics/Gynecology", "207V00000X"], ["Anesthesiology", "207L00000X"], ["Occupational Medicine", "2083X0100X"], ["Cardiology", "207RC0000X"], ["Ophthalmology", "207W00000X"], ["Cardiovascular Surgery", "2086S0129X"], ["Optometrist", "152W00000X"], ["Colon and Rectal Surgery", "208C00000X"], ["Oral and Maxillofacial Pathology", "1223P0106X"], ["Critical Care", "207RC0200X"], ["Oral Surgery", "1223S0112X"], ["Dentistry", "122300000X"], ["Orthodontics", "1223X0400X"], ["Dermatology", "207N00000X"], ["Orthopedic Surgery", "207XP3100X"], ["Emergency Medicine", "207P00000X"], ["Otolaryngology", "207Y00000X"], ["Endocrinology", "207RE0101X"], ["Pain Medicine", "207LP2900X"], ["Endocrinology, Diabetes & Metabolism", "207RE0101X"], ["Pathology", "207ZP0102X"], ["Endodontist", "1223E0200X"], ["Pediatric Cardiology", "2080P0202X"], ["Family Practice", "207Q00000X"], ["Pediatric Dermatology", "207NP0225X"], ["Foot and Ankle Orthopedics", "207XX0004X"], ["Pediatric Orthopedics", "207XP3100X"], ["Gastroenterology", "207RG0100X"], ["Pediatrics", "208000000X"], ["General Dentistry", "1223G0001X"], ["Pedodontist", "1223P0221X"], ["General Practice", "208D00000X"], ["Periodontics", "1223P0300X"], ["Geriatric Medicine- IM", "207RG0300X"], ["Physical Medicine and Rehabilitation", "208100000X"], ["Gynecologic Oncology", "207VX0201X"], ["Plastic Surgery", "208200000X"], ["Gynecology", "207VG0400X"], ["Podiatry", "213E00000X"], ["Hematology", "207RH0000X"], ["Prosthodontist", "1223P0700X"], ["Hematology/Oncology", "207RH0003X"], ["Psychiatry", "2084P0800X"], ["Hospitalist", "208M00000X"], ["Pulmonary Medicine", "207RP1001X"], ["Immunology", "246QI0000X"], ["Radiation Oncology", "2085R0001X"], ["Infectious Diseases", "207RI0200X"], ["Radiology", "111NR0200X"], ["Infertility", "163WR1000X"], ["Reproductive Endocrinology", "207VE0102X"], ["Internal Medicine", "207R00000X"], ["Rheumatology", "207RR0500X"], ["Interventional Cardiology", "207RI0011X"], ["Spine Surgery", "207XS0117X"], ["Medical Oncology", "163WX0200X"], ["Sports Medicine", "207PS0010X"], ["Neonatology", "2080N0001X"], ["Sports Medicine- Orthopedics", "207PS0010X"], ["Nephrology", "207RN0300X"], ["Surgery General", "208600000X"], ["Neurological Surgery", "207T00000X"], ["Surgical Oncology","2086X0206X"], ["Neurology", "2084N0400X"], ["Urology", "208800000X"], ["Nuclear Medicine", "207U00000X"], ["Vascular Surgery", "2086S0129X"]].each do |index|
	primary_specialty = PrimarySpecialty.find_or_initialize_by_specialty(index[0])
	primary_specialty.taxonomy_code = index[1]
	primary_specialty.save
end

#save template repository
[{:url=>"/api/locally", :user_id=>5, :name=>"locally"}, {:url=>"/api/template", :user_id=>5, :name=>"centrally"}].each do |index|
	template_library = TemplateLibrary.find_or_initialize_by_name(index[:name])
	template_library.user_id = index[:user_id]
	template_library.url = index[:url]
	template_library.save
end

puts 'Finished seeding'
