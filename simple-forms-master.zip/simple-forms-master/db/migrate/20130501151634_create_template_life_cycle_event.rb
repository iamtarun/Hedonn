class CreateTemplateLifeCycleEvent < ActiveRecord::Migration
  def self.up
    create_table :template_life_cycle_event do |t|
	  t.string :life_cycle_event
      t.timestamps
    end
  end

  def self.down
    drop_table :template_life_cycle_event
  end
end
