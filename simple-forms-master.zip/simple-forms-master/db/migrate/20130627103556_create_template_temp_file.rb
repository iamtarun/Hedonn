class CreateTemplateTempFile < ActiveRecord::Migration
  def self.up
    create_table :template_temp_file do |t|
		t.integer :user_id, :null => false
		t.integer :template_id, :references => :template, :null => false
		t.text  :file_name
		t.string :content_type 
		t.timestamps
    end
  end

  def self.down
    drop_table :template_temp_file
  end
end
