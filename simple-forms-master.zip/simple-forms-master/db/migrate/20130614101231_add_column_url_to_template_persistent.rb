class AddColumnUrlToTemplatePersistent < ActiveRecord::Migration
  def self.up
	add_column :template_persistent, :url, :text, :after => :plugin_name
  end

  def self.down
	remove_column :template_persistent, :url
  end
end
