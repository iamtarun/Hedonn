class ChangeDataTypeFormValue < ActiveRecord::Migration
  def self.up
	change_column :form_value, :value, :text, :limit => 4294967295
  end

  def self.down
  end
end
