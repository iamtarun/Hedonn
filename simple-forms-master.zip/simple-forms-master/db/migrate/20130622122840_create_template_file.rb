class CreateTemplateFile < ActiveRecord::Migration
  def self.up
    create_table :template_file do |t|
		t.integer :template_id, :references => :template, :null => false
		t.integer :form_value_id, :references => :form_value, :null => false
		t.text  :file_name
		t.binary  :file_blob, :limit => 4294967295
		t.string :content_type 
		t.timestamps
    end
  end

  def self.down
    drop_table :template_file
  end
end
