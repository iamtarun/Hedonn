class CreateTemplatePersistent < ActiveRecord::Migration
  def self.up
    create_table :template_persistent do |t|
		t.string :label
		t.integer :template_life_cycle_event_id, :references => :template_life_cycle_event
		t.string :plugin_name		
		t.timestamps
    end
  end

  def self.down
    drop_table :template_persistent
  end
end