class CreateColumnType < ActiveRecord::Migration
  def self.up
    create_table :column_type do |t|
		t.string :title, :null => false
		t.text :description
		t.integer :template_id, :references => :templates
      t.timestamps
    end
  end

  def self.down
    drop_table :column_type
  end
end
