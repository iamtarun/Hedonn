class CreateTemplateImage < ActiveRecord::Migration
  def self.up
    create_table :template_image do |t|
		t.integer :user_id, :null => false
		t.text :image_name
		t.timestamps
    end
  end

  def self.down
    drop_table :template_image
  end
end
