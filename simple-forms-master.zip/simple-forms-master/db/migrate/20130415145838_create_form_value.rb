class CreateFormValue < ActiveRecord::Migration
  def self.up
    create_table :form_value do |t|
		t.integer :template_id, :references => :template
		t.text :value, :null => false		
		t.timestamps
    end
  end

  def self.down
    drop_table :form_value
  end
end
