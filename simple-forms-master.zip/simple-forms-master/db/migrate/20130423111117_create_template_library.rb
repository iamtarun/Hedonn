class CreateTemplateLibrary < ActiveRecord::Migration
  def self.up
    create_table :template_library do |t|
		t.integer :user_id, :null => false
		t.string :name, :null => false
		t.string :path
		t.string :url
		#t.enum :status ,:limit => [:Active, :Inactive] ,:default => :Inactive
		t.integer :status
		t.timestamps
    end
  end

  def self.down
    drop_table :template_library
  end
end