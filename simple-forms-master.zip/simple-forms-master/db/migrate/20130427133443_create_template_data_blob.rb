class CreateTemplateDataBlob < ActiveRecord::Migration
  def self.up
    create_table :template_data_blob do |t|
		t.integer :template_id, :references => :template, :null => false
		t.integer :version
		t.text :content
		t.string :template_type
		t.timestamps   
	end
  end

  def self.down
    drop_table :template_data_blob
  end
end
