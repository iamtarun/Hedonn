class AddIsPublishFieldToTemplateLibraryList < ActiveRecord::Migration
  def self.up
		add_column :template_library_list, :is_template_publish, :boolean, :default => false, :after => :template_library_id
		add_column :template_library_list, :is_form_publish, :boolean, :default => false, :after => :is_template_publish
  end

  def self.down
		remove_column :template_library_list, :is_template_publish
		remove_column :template_library_list, :is_form_publish
  end
end
