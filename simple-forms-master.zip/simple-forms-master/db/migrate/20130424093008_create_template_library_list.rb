class CreateTemplateLibraryList < ActiveRecord::Migration
  def self.up
    create_table :template_library_list do |t|
		t.integer :template_id, :references => :template, :null => false
		t.integer :template_library_id, :references => :template_library, :null => false
		t.timestamps
    end
  end

  def self.down
    drop_table :template_library_list
  end
end
