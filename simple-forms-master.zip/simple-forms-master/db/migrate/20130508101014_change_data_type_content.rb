class ChangeDataTypeContent < ActiveRecord::Migration
  def self.up
	change_column :template_data_blob, :content, :text, :limit => 4294967295
  end

  def self.down
  end
end
