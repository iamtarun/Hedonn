class CreateTemplate < ActiveRecord::Migration
  def self.up
    create_table :template do |t|
		t.string :name, :null => false		
		t.timestamps
    end
  end

  def self.down
    drop_table :template
  end
end
