class CreateTemplateActivityLog < ActiveRecord::Migration
  def self.up
    create_table :template_activity_log do |t|
		t.integer :template_id, :references => :template, :null => false
		t.text  :activity_log, :limit => 4294967295
		t.timestamps
    end
  end

  def self.down
    drop_table :template_activity_log
  end
end
