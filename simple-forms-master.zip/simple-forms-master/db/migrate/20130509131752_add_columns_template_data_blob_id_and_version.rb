class AddColumnsTemplateDataBlobIdAndVersion < ActiveRecord::Migration
  def self.up
	add_column :form_value, :template_data_blob_id, :integer, :after => :id
	add_column :form_value, :version, :integer, :after => :template_id
  end

  def self.down
	remove_column :form_value, :template_data_blob_id
	remove_column :form_value, :version
  end
end
