/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : This is common file and Development Purpose for form builder in simplifyMD
 * @ Dependency : N/A
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */
var overlayClearFlag = false;
var signatureClearFlag = true;
var dataGroupArray = [];
var groupElements = {};
var maxElementHeight = 0;
var maxElementHeight = 0;
var elementWithoutGroupTop = {};
var activityLogText = "";
var activityControlsLog = {};

common = {};

(function($) {
	
		common = {
			
			/*********
			 * @ Desc: Initialize default function with page load. Define the different types of action perform on document.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			init: function() {				
				
				/*********
				 * @ Desc: Click functin on "input[type=checkbox]" class, In this action, Set checked attributes true or false
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						common.printTemplateForm();
					}																		
				}, '.print-from');				
				
				/*********
				 * @ Desc: Click function on "dialog_close" class, In this action, close dialog box.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						$('#dialog-modal').dialog("close");
					}
				}, '.dialog_close');
				
				/*********
				 * @ Desc: Click function on "sigPad" class, In this action, to show the signature pad tab
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					mouseover: function (e) {
						e.stopPropagation();
						if(overlayClearFlag) {
							var navObj = $(this).children(':first');
							$(navObj).find('.typeIt').hide();
							$(navObj).find('.drawIt').hide();
							$(navObj).find('.clearButton').show();
							$(navObj).show();
						}
					},
					mouseout: function (e) {
						e.stopPropagation();
						var navObj = $(this).children(':first');
						$(navObj).hide();
					}
				}, '.form-inking-overlay .sigPad');
				
				/*********
				 * @ Desc: Click function on "sigPad" class, In this action, to show the signature pad tab
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					mouseover: function (e) {
						e.stopPropagation();
						if(signatureClearFlag) {
							var navObj = $(this).children(':first');
							$(navObj).find('.typeIt').hide();
							$(navObj).find('.drawIt').hide();
							$(navObj).find('.clearButton').show();
							$(navObj).show();
						}
					},
					mouseout: function (e) {
						e.stopPropagation();
						var navObj = $(this).children(':first');
						$(navObj).hide();
					}
				}, '.form-simple-signature .sigPad');
				
				/*********
				 * @ Desc: Click function on "show_inking_overlay_header" class, In this action, to show the signature pad toggle
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						if($(this).hasClass('drawIt') == true) {
							$(document).ready(function(){
								var options = {
								  drawOnly : true,
								  lineColour : '#ffffff',
								  validateFields : false
								};
								$('.form_display')
									.find(".form-inking-overlay")
									.children(':first')
									.signaturePad(options);
							});
							$('.form_display')
								.find("div.form-row")
								.css('z-index', 0);
							$('.form_display')
								.find(".form-inking-overlay")
								.parent()
								.css('z-index', 1);
							
							$('.form_display')
								.find(".form-inking-overlay")
								.find('#stop_overlay')
								.remove();
							$('.form_display')
								.find(".form-inking-overlay")
								.find('#inking_overlay_image')
								.remove();
								
							$(this).addClass('typeIt');
							$(this).removeClass('drawIt');
							$(this).css('z-index', 2);
							$('#expand_collapse img').attr('src', baseUrl + '/images/form_builder/toggle_small_collapse.png');
							$('#inking_overlay_text a').html('Click to end mark with Inking Overlay');
							overlayClearFlag = true;
							signatureClearFlag = false;
						} else {
							$('.form_display')
								.find("div.form-row")
								.css('z-index', 1);					
							$('.form_display')
								.find(".form-inking-overlay")
								.parent()
								.css('z-index', 0);
							var width = $('.form_display').find('.form-inking-overlay').width();
							var height = $('.form_display').find('.form-inking-overlay').height();
							$('.form_display')
								.find(".form-inking-overlay")
								.append('<div id="stop_overlay" style="position:absolute; top:0px; left:0px;"></div>');
							$('#stop_overlay').css('width', width);
							$('#stop_overlay').css('height', height);
							
							$('.form_display')
								.find(".form-simple-signature")
								.find('#signature_pad_image')
								.remove();
							
							$(this).addClass('drawIt');
							$(this).removeClass('typeIt');
							$(this).css('z-index', 1);
							$('#expand_collapse img').attr('src', baseUrl + '/images/form_builder/toggle_small_expand.png');
							$('#inking_overlay_text a').html('Click to start mark with Inking Overlay');
							overlayClearFlag = false;
							signatureClearFlag = true;
						}						
					}
				}, '#show_inking_overlay_header');
				
				/*********
				 * @ Desc: Auto Suggest Event on controls
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					keyup: function (e) {
						e.stopPropagation();
						if($(this).attr('autosuggest') == 'enabled' 
							&& $(this).attr('data-persistent') != undefined 
							&& $(this).attr('data-persistent') != '') {
							var keyword = $(this).val();
							var dataPersistent = $(this).attr('data-persistent');
							var currentId = $(this).attr('id');
							var dataUrl = "";
							
							if(Template.autoSuggestUrlArray.length > 0) {
								$.each(Template.autoSuggestUrlArray, function(index, item) { 
									if(dataPersistent === item.data_persistent) {
										dataUrl = item.data_url;
									}							
								});
							}
							
							if(dataUrl != "" && dataUrl != null) {									
								$('#' + currentId).autocomplete({
									source: function(request, response) {
										//clearTimeout($.data(this, 'timer'));
										//var wait = setTimeout(function(){
											var templateObj = new Template();
											templateObj.setValue('async', Template.sync);
											templateObj.setValue('url', dataUrl);							
											templateObj.setValue('keyword', keyword);							
											templateObj.setValue('template_id', $('#template_id').val());							
											templateObj.setValue('data_persistent', dataPersistent);							
											templateObj.setValue('auto_suggest_element_id', currentId);							
											templateObj.setValue('target', 'show_auto_suggest_data');
											response(eval(templateObj.getAutoSuggestData()));											
										//}, 5000);
										//$(this).data('timer', wait);
									},
									minLength: 2,
									delay: 1000,
									select: function( event, ui ) {
										if(ui.item.value != 'No results match ') {
											//ui.item.id,ui.item.value 
											//console.log(ui);
										}
									}
								});
							}							
						}
					}
				}, 'input[type="text"]');
				
				/*********
				 * @ Desc: Add more action on "addmore-group" class
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var lastElementId = '';
						var currentGroupId = $(this).attr('data-group');						
						var count = 0;
						
						$('div.form_display div.form-row a.remove-group').each(function(index) {
							if($(this).hasClass('remove-group-' + currentGroupId)) {
								lastElementId = $(this).attr('data-last-id');
								count++;
							}
						});				
						
						if(common.len(groupElements) > 0) {
						
							var addOptionsCount = parseInt($(this).attr('data-click-count'));
							if(addOptionsCount < 5) {
							
								$(this).attr('data-click-count', count + 1);
								
								common.createGroupRow(groupElements, currentGroupId, addOptionsCount, lastElementId, "");
								
							} else {
								alert("Maximum limit 5!")
							}							
						} else {
							alert("Please add group elements");
						}
					}
				}, 'a.addmore-group');
				
				/*********
				 * @ Desc: Remove Element action on "remove-group" class
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						
						var deleteIds = $(this).attr('data-delete-id');
						var deleteLastIds = $(this).attr('data-last-id');
						var currentGroupId = $(this).attr('data-group');						
						var deleteIdsArray = deleteIds.split(',');
						
						var elementHeight = {};
						$('div.form_display div.form-row').each(function(index) {
							var liId = $(this).attr('id');
							elementHeight[ liId ] = parseInt($('#' + liId).css('top'), 10);							
						});
						
						if(deleteIdsArray.length > 0) {
						
							//var deletableIDs = {};
							//deletableIDs[ $(this).attr('data-last-id').slice(3) ] = index;							
							//var undeleteID = common.maxKey(deletableIDs);
							
							$.each(deleteIdsArray, function(index, item) {
								$('#' + item).remove();
							});
							
							var removeElementExists = false;
							$('div.form_display div.form-row a.remove-group').each(function(index) {
								if($(this).hasClass('remove-group-' + currentGroupId)) {
									removeElementExists = true;
								}
							});
							
							if(!removeElementExists) {
								$('.addmore-group-' + currentGroupId)
									.attr('data-click-count', 0);
							} else {
								var currentCount = $('.addmore-group-' + currentGroupId)
									.attr('data-click-count');
								$('.addmore-group-' + currentGroupId)
									.attr('data-click-count', parseInt(currentCount) - 1);
							}						
							
							common.rePositionElement(deleteLastIds, currentGroupId);
							
							var currentHeight = $('#' + currentGroupId).height();
							var currentTop = parseInt($('#' + currentGroupId).parent().css('top'), 10);
							var groupBoxHeight = currentHeight - maxElementHeight;
							$('#' + currentGroupId).height(groupBoxHeight);
							
							
							var groupTotalHeight = groupBoxHeight + currentTop;
							var pageHeight = $('#' + currentGroupId).parent().parent().height();					
							$.each(elementHeight, function(index, item) {
								if(item >= groupTotalHeight) {
									elementWithoutGroupTop[ index ]  = item;
								}
							});
							var footerTop = parseInt($('#footer').css('margin-top'), 10);
							$.each(elementHeight, function(index, item) {						
								if($('#' + index).height()+item+maxElementHeight >= pageHeight) {														
									$('#' + currentGroupId).parent().parent().css('height', (pageHeight - maxElementHeight));
									$('#footer').css('margin-top',(footerTop - maxElementHeight));		
								}
							});

							$.each(elementWithoutGroupTop, function(index, item) {
								$('#' + index).css('top', (item - maxElementHeight));
							});
							
						}
					}
				}, 'a.remove-group');
				
				/*********
				 * @ Desc: View Activity log details action on "view_activity_log" class
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var currentElementId = $(this).attr('data-element-id');
						common.showActivityLogByElement(currentElementId);						
					}
				}, 'a.view_activity_log');
			
			},
			
			/*********
			 * @ Desc: Create the Group Row of selected element.
			 * @ Params: gorup Object, current group id, row count, last group element id, value of fields.
			 * @ Returns: boolean
			/*************/
			createGroupRow: function(groupElements, currentGroupId, addOptionsCount, lastElementId, inputVal) {
				try {
					var currentGroups = '';
					$.each(groupElements, function(index, group) {
						if(currentGroupId == index) {
							currentGroups = group;
						}
					});
					
					var elementHeight = {};
					var elementMax = '';
					
					$('div.form_display div.form-row').each(function(index) {
						var liId = $(this).attr('id');
						elementMax = liId.slice(3);
						elementHeight[ liId ] = parseInt($('#' + liId).css('top'), 10);							
					});
					
					maxElementHeight = common.getMaxElementHeight(currentGroups);
					
					var i = 1;
					var deleteIds = "";
					
					$.each(currentGroups, function(index, element) {
						
						var newElementIdCount = parseInt(elementMax) + i;
						var currentElementTop = 0;
						var elementCloneObj = $('#' + element).parent().clone();
						var childElementObj = $('#' + element);
						
						if(addOptionsCount == 0) {
							currentElementTop = parseInt($(childElementObj).parent().css('top'));
						} else {
							currentElementTop = parseInt($('#' + lastElementId).css('top'));
						}
						
						var formType = childElementObj[0].tagName != 'INPUT' ? childElementObj[0].tagName : childElementObj[0].type;
						var type = (formType.toLowerCase() == 'span') ? 'label' : formType.toLowerCase();
						var dataType = $(childElementObj).attr('data-type');								
						if(dataType != undefined && dataType != '') {
							type = dataType;
						}
						
						type = (formType.toLowerCase() == 'li') ? 'bullet' : type;
						elementCloneObj.attr("id", "id_" + newElementIdCount);
						elementCloneObj.children(':first').attr("id", type + "_" + newElementIdCount);
						elementCloneObj.children(':first').attr("name", type + "_" + newElementIdCount);
						elementCloneObj.children(':first').attr("data-row", "row_" + addOptionsCount);
						elementCloneObj.children(':first').attr("value", (common.len(inputVal) > 0) ? inputVal[ index ] : "");
						$(elementCloneObj).css('top', currentElementTop + maxElementHeight);
						$(elementCloneObj).css('left', parseInt($(elementCloneObj).css('left')));
						$(elementCloneObj).find('.addmore-group').remove();
						
						var elementId = "id_" + newElementIdCount;
						
						if(i == common.len(currentGroups))
							deleteIds = deleteIds + elementId;
						else
							deleteIds = deleteIds + elementId + ",";
							
						if(i == common.len(currentGroups)) {
							$(elementCloneObj).append('<a class="btn btn-mini remove-group remove-group-' + currentGroupId + '" data-delete-id="' + deleteIds + '" data-last-id="' + elementId + '" data-group="' + currentGroupId + '" href="javascript:void(0);" alt="remove group"><i class="btn-icon-only icon-plus icon-white"></i>&nbsp;</a>');
						}
						$('div.form_display').append(elementCloneObj);
						
						$('#' + elementId).children(':first').val((common.len(inputVal) > 0) ? inputVal[ index ] : "");
						
						// add datepicker events on element
						if($('#' + elementId).children(':first').hasClass('datepicker')) {
							if($('#' + elementId).children(":first").hasClass('hasDatepicker')) {
								$('#' + elementId)
									.find(".ui-datepicker-trigger")
									.remove();
							}
							$('#' + elementId).children(':first').removeClass('hasDatepicker');
							common.applyDatePicker($('#' + elementId).children(':first'));
						}
						
						if($('#' + elementId).children(':first').hasClass('datetimepicker')) {
							if($('#' + elementId).children(":first").hasClass('hasDatepicker')) {
								$('#' + elementId)
									.find(".ui-datepicker-trigger")
									.remove();
							}
							$('#' + elementId).children(':first').removeClass('hasDatepicker');
							common.applyDateTimePicker($('#' + elementId).children(":first"));	
						}
						i++;
					});
					
					var currentHeight = $('#' + currentGroupId).height();
					var currentTop = parseInt($('#' + currentGroupId).parent().css('top'), 10);
					var groupBoxHeight = currentHeight + maxElementHeight;					
					var groupTotalHeight = currentHeight + currentTop;					
					var pageHeight = $('#' + currentGroupId).parent().parent().height();					
					var footerTop = parseInt($('#footer').css('margin-top'), 10);
					$('#' + currentGroupId).height(groupBoxHeight);
					
					$.each(elementHeight, function(index, item) {						
						if(item >= groupTotalHeight) {
							elementWithoutGroupTop[ index ]  = item;
						}
					});
					
					$.each(elementHeight, function(index, item) {						
						if($('#' + index).height()+item+maxElementHeight >= pageHeight) {														
							$('#' + currentGroupId).parent().parent().css('height', (pageHeight + maxElementHeight));	
							$('#footer').css('margin-top',(footerTop+ maxElementHeight));	
						}
					});

					$.each(elementWithoutGroupTop, function(index, item) {
						$('#' + index).css('top', (item + maxElementHeight));
					});
					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Validate the form before save based on conditions.
			 * @ Params: Object
			 * @ Returns: boolean
			/*************/
			validate: function(attributes) {
				try {
					var valid = true;
					var attrLength = common.len(attributes);
					
					if(attrLength > 0) {					
						if(attributes.name == 'email') {
							if(attributes.value != '') {
								if(common.validEmail(attributes.value) == false) {
									valid = false;
									$('#' + attributes.id).addClass('form-builder-error');
								} else {
									$('#' + attributes.id).removeClass('form-builder-error');
								}
							}
						} else if(attributes.value == '') {
							valid = false;
							$('#' + attributes.id).addClass('form-builder-error');
						} else if(attributes.type == 'radio' || attributes.type == 'checkbox') {
							if($('#' + attributes.id).is(":checked") == false) {
								valid = false;
								$('#' + attributes.id).addClass('form-builder-error');
							} else {
								$('#' + attributes.id).removeClass('form-builder-error');
							}						
						} else {
							$('#' + attributes.id).removeClass('form-builder-error');
						}			
						
					}
					
					return valid;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Show dialog box pop up into #dialog-modal.
			 * @ Params: title of dialog box
			 * @ Returns: N/A
			/*************/
			showDialog: function(title) {
				try {
					$('#information').addClass('hide');
					$( "#dialog-modal" ).html('');
					$( "#dialog-modal" ).dialog({					 
						width: 350,
						height: 'auto',
						draggable: false,
						title: title,
						open: function(event, ui) {}
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},

			/*********
			 * @ Desc: Show dialog box pop up into #dialog-modal.
			 * @ Params: title of dialog box
			 * @ Returns: N/A
			/*************/
			showCustomeDialog: function(id, title, width, height) {
				try {
					$( "#" + id).dialog({					 
						width: width,
						height: height,
						draggable: false,
						title: title,
						open: function(event, ui) {}
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the max key from array object.
			 * @ Params: Array
			 * @ Returns: max value
			/*************/
			maxKey:	function (a) {
				try {
					var max, k; // don't set max=0, because keys may have values < 0  
					for (var key in a) {
						if (a.hasOwnProperty(key)) {
							max = parseInt(key); 
							break; 
						}
					} //get any key
					
					for (var key in a) {
						if (a.hasOwnProperty(key)) {
							if((k = parseInt(key)) > max) 
								max = k; 
						}
					}  
					return max;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the tag name of any html element.
			 * @ Params: element Object
			 * @ Returns: type
			/*************/
			getTagName: function(elementObj) {
				try {
					var formType = $(elementObj)[0].tagName != 'INPUT' ? $(elementObj)[0].tagName : $(elementObj)[0].type;
					var type = (formType.toLowerCase() == 'span') ? 'label' : formType.toLowerCase();
					return type;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the Advance tag name of any html element.
			 * @ Params: element Object
			 * @ Returns: string
			/*************/
			getAdTagName: function(elementObj) {
				try {
					var formType = $(elementObj)[0].tagName != 'INPUT' ? $(elementObj)[0].tagName : $(elementObj)[0].type;
					var type = (formType.toLowerCase() == 'span') ? 'label' : formType.toLowerCase();
					var dataType = $(elementObj).attr('data-type');
					if(dataType != undefined && dataType != '') {
						type = dataType;
					}
					type = (formType.toLowerCase() == 'li') ? 'bullet' : type;
					return type;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the length of the object
			 * @ Params: element Object
			 * @ Returns: integer
			/*************/
			len: function(obj) {
				try {
					var l = 0;
					$.each(obj, function(i, elem) {
						l++;
					});
					return l;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Function to check the email address
			 * @ Params: email
			 * @ Returns: boolean
			/*************/
			validEmail: function(email) {
				try {
					var filter = /^\s*[\w\-\+_]+(\.[\w\-\+_]+)*\@[\w\-\+_]+\.[\w\-\+_]+(\.[\w\-\+_]+)*\s*$/;
					return String(email).search(filter) != -1;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Function to convert hex format to a rgb color
			 * @ Params: element Object
			 * @ Returns: integer
			/*************/
			rgb2hex: function(rgb) {
				try {
					rgb = $.trim(rgb).match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i);
					return (rgb && rgb.length === 4) ? "#" +
					("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
					("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
					("0" + parseInt(rgb[3],10).toString(16)).slice(-2) : '';
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: check RGB color code
			 * @ Params: String
			 * @ Returns: code if true otherwise return null
			/*************/
			checkRgb:function(colorCode) {
				try {
					return rgb = $.trim(colorCode).match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Filter string , Remove "+" sign from string
			 * @ Params: String
			 * @ Returns: String
			/*************/
			filterValue: function(str) {
				try {
					var string = str.replace(/\+/g, " ");					
					return string;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Filter string , Remove "-" sign from key string
			 * @ Params: String
			 * @ Returns: String
			/*************/
			filterKey: function(key) {
				try {
					var key = key.replace('-', '');
					return key;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Filter string , Remove white space from string
			 * @ Params: String
			 * @ Returns: String
			/*************/
			filterSpace: function(str) {
				try {
					var string = str.replace(/\s/g, "");
					return string;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Filter string , Trim space both side only from string
			 * @ Params: String
			 * @ Returns: String
			/*************/
			filterSpaceTrim: function(str) {
				try {
					var string = $.trim(str);
					return string;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Remove string from html on the basis of passed value either id or class or tag 
			 * @ Params: target value and html
			 * @ Returns: String
			/*************/
			strRemove: function(theTarget, theString) {
				try {
					return $("<div/>").append(
						$(theTarget, theString).remove().end()
					).html();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Function to reset ruler on form editor screen and remove ruler before set new dimensions..
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			resetRuler: function(){
				try {
					$('#form_panel')
								.find('.ruler')
								.remove();
					$('#form_panel').ruler();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Function to alert that if properties changes at time of template creation
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			alertPropertiesChanges: function() {
				try {
					if(propertiesChanged) {
						if(confirm('Are you sure to descard properties changes!')) {
							propertiesChanged = false;
						}
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			* @ Desc: get all data-condition and store in Array.
			* @ Params: N/A
			* @ Returns: N/A
			/*************/
			dataCondition: function() {
				try {
					$('.form_display div.form-row').each(function(){
						var scriptCondition = $(this).children(':first').attr('data-condition');
						if(scriptCondition != undefined) {
							eval(scriptCondition);
						}                                                                                              
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			* @ Desc: get parameters from query string.
			* @ Params: query string
			* @ Returns: string
			/*************/
			getQueryString: function(q) {
				try {
					return (function(a) {
						if (a == "") return {};
						var b = {};
						for (var i = 0; i < a.length; ++i) {
							var p = a[i].split('=');
							if (p.length != 2) continue;
							b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
						}
						return b;
					})(q.split("&"));
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},			 

			/*********
			* @ Desc: get parameters from query string.
			* @ Params: param name
			* @ Returns: string
			/*************/
			getParameterByName: function(name) {
				try {
					name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
					var regexS = "[\\?#&]" + name + "=([^&#]*)";
					var regex = new RegExp(regexS);
					var results = regex.exec(window.location.href);
					if (results == null) return "";
					else return decodeURIComponent(results[1].replace(/\+/g, " "));
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			* @ Desc: Print the template form.
			* @ Params: print document html
			* @ Returns: N/A
			/*************/
			printForm: function(printDocument) {	
				try {
					win = window.open();
					self.focus();
					win.document.open();
					win.document.write('<'+'html'+'><'+'head'+'><'+'style'+'>');
					win.document.write('body, table { border-collapse: collapse;} th { font-family: Verdana; font-size: 15px;} td { font-family: arial; font-size: 13px;} .selected_image{ position:absolute;left:1px;top:1px; } input, textarea, select, .uneditable-input { border: 1px solid #CCCCCC; border-radius: 3px 3px 3px 3px; padding: 4px;}');
					win.document.write('<'+'/'+'style'+'><'+'/'+'head'+'><'+'body'+'>');
					win.document.write(printDocument);
					win.document.write('<'+'/'+'body'+'><'+'/'+'html'+'>');
					win.document.close();
					win.print();
					win.close();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Pirnt the template form to get the html content.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			printTemplateForm: function() {
				try {
					var valid = true;
					var paramsAttributes = new Array();
					$('div.form-row').each(function() {
						var selObj = $(this).children(':first');
						
						var attributes = {};

						$.each(selObj[0].attributes, function(index, attr) {
							if(attr.name == 'id') {
								var dataType = $('#' + attr.value).attr('data-type');
								
								if(dataType != undefined) {
									attributes[ 'data-type' ] = dataType;
									switch(dataType) {
										case 'inking-overlay':
											attributes[ 'value' ] = $('#' + attr.value).find('input.output').val();
											attributes[ 'width' ] = $('#' + attr.value).width();
											attributes[ 'height' ] = $('#' + attr.value).height();
											break;
										case 'simple-signature':
											attributes[ 'value' ] = $('#' + attr.value).find('input.output').val();
											attributes[ 'width' ] = $('#' + attr.value).width();
											attributes[ 'height' ] = $('#' + attr.value).height();
											break;
									}
								}
							}
							
						});
						
						paramsAttributes.push({controls:attributes});
						
					});
					
					var finalPrintJson = JSON.stringify(paramsAttributes);
					
					var templateObj = new Template();						
					templateObj.setValue('async', Template.sync);							
					templateObj.setValue('data_json', finalPrintJson);							
					templateObj.setValue('target', 'print_form');							
					templateObj.printTemplateFormData();
					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},			
			
			/*********
			 * @ Desc: Pirnt the template form to get the html content after image overlay markup.
			 * @ Params: template print data url
			 * @ Returns: N/A
			/*************/
			renderPrintTemplateFormData: function(data) {
				try {
					//console.log(data.simple_image_file);
					
					var widthOverlay = $('.form_display').find('.form-inking-overlay').width();
					var heightOverlay = $('.form_display').find('.form-inking-overlay').height();
					$('.form_display')
						.find(".form-inking-overlay")
						.append('<div id="inking_overlay_image" style="position:absolute; top:0px; left:0px;"></div>');
					$('#inking_overlay_image').css('width', widthOverlay);
					$('#inking_overlay_image').css('height', heightOverlay);
					
					var widthSignature = $('.form_display').find('.form-simple-signature').width();
					var heightSignature = $('.form_display').find('.form-simple-signature').height();
					$('.form_display').find('.typed').remove();
					$('.form_display')
						.find(".form-simple-signature")
						.append('<div id="signature_pad_image" style="position:absolute; top:0px; left:0px;"></div>');
					$('#signature_pad_image').css('width', widthSignature);
					$('#signature_pad_image').css('height', heightSignature);
					
					var signatureImagePath = data.simple_image_file;
					if(signatureImagePath != '' && signatureImagePath != undefined) {
						$('#signature_pad_image').html('<img src="' + signatureImagePath + '"/>');
					}
					var overlayImagePath = data.overlay_image_file;
					if(overlayImagePath != '' && overlayImagePath != undefined) {
						$('#inking_overlay_image').html('<img src="' + overlayImagePath + '"/>');
					}
					$('#dialog-modal').dialog( "close" );
					var formHtml = $.trim($('.form_display').html());
					$('#prinHtml').html(formHtml);
					$('#prinHtml').find('#show_inking_overlay_header').remove();
					//var content = $('#prinHtml').html();				
					//common.printForm(content);
					$('#prinHtml').printArea({mode: "popup", popClose: false});
					$('#prinHtml').html('');
					$('.form_display')
						.find(".form-simple-signature")
						.find("#signature_pad_image")
						.remove();
					$('.form_display')
						.find(".form-inking-overlay")
						.find("#inking_overlay_image")
						.remove();
					setTimeout(function(){
						$.each(data, function(index, item) {
							common.deleteOverlayInking(item);
						});
						
					}, 5000);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Delete image overlay after print the template form.
			 * @ Params: path of the delete image
			 * @ Returns: N/A
			/*************/
			deleteOverlayInking: function(path) {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('image_path', path);							
					templateObj.setValue('target', 'delete_print_image');							
					templateObj.deletePrintOverlay();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: render the autosuggest controls after getting the url
			 * @ Params: auto suggest url, element id
			 * @ Returns: N/A
			/*************/
			renderAutoSuggestControl: function(dataUrl, elementId) {
				try {
					if(Template.autoSuggestUrlArray.length > 0) {
						$.each(Template.autoSuggestUrlArray, function(index, item) {
							var controlElement = $('#' + item.element).children(':first');
							$(controlElement).attr('data-url-auto-suggest', item.data_url);					
						});						
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: apply date time picker on selector
			 * @ Params: element selector
			 * @ Returns: N/A
			/*************/
			applyDateTimePicker: function(selector) {
				try {
					$(selector).datetimepicker({
						changeMonth: true,
						changeYear:true,
						dateFormat: 'mm/dd/yy',
						timeformat: 'hh:mi',
						ampm:true,
						showButtonPanel:true,
						showOn: "button",
						buttonImage: "images/form_builder/calendar.gif",
						buttonImageOnly: true,
						buttonText: "Choose Date"
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: apply date time picker on selector
			 * @ Params: element selector
			 * @ Returns: N/A
			/*************/
			applyDatePicker: function(selector) {
				try {
					$(selector).datepicker({
						changeMonth: true,
						changeYear:true,
						showOn: "button",
						buttonImage: "images/form_builder/calendar.gif",
						buttonImageOnly: true,
						buttonText: "Choose Date"
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: set color picker
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			applyColorPicker: function() {
				$(".colorpicker").spectrum({
					showAlpha: true
				});
			},
			
			/*********
			 * @ Desc: render auto suggest in list
			 * @ Params: auto suggest data, element id
			 * @ Returns: N/A
			/*************/
			renderAutoSuggest: function(data, elementId) {
				try {
					$('#' + elementId).autocomplete({
						source: function(request, response) {
							$('#' + elementId).removeClass('ajax-dropdown-loading');
							response(data);						
						},
						minLength: 1,
						select: function( event, ui ) {
							if(ui.item.value != 'No results match ') {
								//ui.item.id,ui.item.value 
								//console.log(ui);
							}
						}					
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}				
			},
			
			/*********
			 * @ Desc: get Maximum Element Height the group element.
			 * @ Params: current groups array
			 * @ Returns: integer
			/*************/
			getMaxElementHeight: function(currentGroups) {
				try {
					var elementHeight = {};
					$.each(currentGroups, function(index, element) {
						var childElementObj = $('#' + element);
						elementHeight[ $(childElementObj).height() ] = 	index;						
					});
					
					return common.maxKey(elementHeight) + 15;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Reposition Element after deleted the group element.
			 * @ Params: delete ids, current group id
			 * @ Returns: N/A
			/*************/
			rePositionElement: function(deleteLastId, currentGroupId) {
				try {
					var rePositionsIDs = {};
					$('div.form_display div.form-row a.remove-group').each(function(index) {
						if($(this).hasClass('remove-group-' + currentGroupId)) {
							var currentLastId = $(this).attr('data-last-id').slice(3);
							if(parseInt(currentLastId) > parseInt(deleteLastId.slice(3))) {
								rePositionsIDs[ index ] = $(this).attr('data-delete-id');
							}									
						}
					});
					
					if(common.len(rePositionsIDs) > 0) {
						$.each(rePositionsIDs, function(index, idString) {
							var rePositionsArray = idString.split(',');
							if(rePositionsArray.length > 0) {
								$.each(rePositionsArray, function(index, item) {
									var currentRowPositionTop = parseInt($('#' + item).css('top'));
									$('#' + item).css('top', currentRowPositionTop - maxElementHeight);
								});							
							}						
						});
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Collect element by Group Name
			 * @ Params: elements
			 * @ Returns: N/A
			/*************/
			collectElementByGroupName: function(element) {
				try {
					var dataGroupName = $(element).attr('data-group-name');
					if( dataGroupName != '' && dataGroupName != undefined) {
						dataGroupArray.push({'data_group_id': $(element).attr('id'), 'data_group_name': $(element).attr('data-group-name')});
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Seperate elements by Group Name
			 * @ Params: groups array
			 * @ Returns: Array
			/*************/
			seperateElementByGroupName: function(groupArray) {
				try {
					var groupElement = {};
					$.each(groupArray, function(index, item) {
						if( Object.prototype.toString.call( groupElement[ item.data_group_name ] ) !== '[object Array]' ) groupElement[ item.data_group_name ] = [];
						groupElement[ item.data_group_name ][ index ] = item.data_group_id;
					});
					
					var newGroupElementArray = {};
					if(common.len(groupElement) > 0) {
						$.each(groupElement, function(index, elements) {
							var newGroup = {};
							var k = 0;
							$.each(elements, function(i, item) {							
								if(item != undefined && item != '') {
									newGroup[ k ] = item;
									k++;
								}
							});
							newGroupElementArray[ index ] = newGroup;
						});				
					}
					
					return newGroupElementArray;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Render group elemets with layout action
			 * @ Params: group element array
			 * @ Returns: N/A
			/*************/
			renderGroupElements: function(groupsData) {
				try {
					var firstGroupElement = {};
					var groupWidth = {};
					$.each(groupsData, function(index, item) {			
						var elementLeft = 0;
						var firstElement = '';
						var i = 0;
						$.each(item, function(inx, elementName) {
							if(i == 0) {
								firstElement = elementName;
							}
							var left = parseInt($('#' + elementName).parent().css('left'));
							elementLeft = elementLeft + left;
							i++;
						});
						firstGroupElement[ index ] = firstElement;
						groupWidth[ index ] = elementLeft;
					});
					
					if(common.len(groupsData) > 0) {
						
						$.each(groupsData, function(index, item) {							
							var j = 1;
							$.each(item, function(key, value) {
								if(j == common.len(item)) {
									$('#' + value)
										.parent()
										.append('<a class="btn btn-mini addmore-group addmore-group-' + index + '" data-group="' + index + '" data-click-count="0" href="javascript:void(0);"><i class="btn-icon-only icon-plus icon-white" alt="add group"> </i>&nbsp;</a>');								
								}
								j++							
							});
						});
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}				
			},
			
			/*********
			 * @ Desc: Render content when call api failure 
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			renderApiFailure: function() {
				try {
					var title = "Error"
					common.showCustomeDialog("dialog-modal", title, 350, 160);
					$('#dialog-modal')
						.removeClass('loading')
						.html('<div id="information" class="alert alert-error ">Template API is not working or Internal Server Error, Please try again later!</div><center><input type="button" class="btn dialog_close" value="Ok" align="center"></center>');					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Generate the uniquer number
			 * @ Params: N/A
			 * @ Returns: string
			/*************/
			generateUniqueNumber: function() {
				try {
					var date = new Date();
					var components = [
						date.getYear(),
						date.getMonth(),
						date.getDate(),
						date.getHours(),
						date.getMinutes(),
						date.getSeconds(),
						date.getMilliseconds()
					];

					return id = components.join("");
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Capture all the event on the selected element.
			 * @ Params: current event, and element DOM
			 * @ Returns: N/A
			/*************/
			captureChangesInEditor: function(event, ui, Obj, changesObj, customData, elementType) {
				try {
					var seperator = ",";
					var count = $('#activity_log_count').val();
					count++;
					
					if(changesObj && changesObj != undefined) {
						if(common.len(changesObj) > 0) {
							var propertiesChangeText = "";
							$.each(changesObj, function(index, item) {			
								var j = 1;				
								$.each(item, function(inc, properties) {
									if(j == common.len(item)) seperator = "";
									propertiesChangeText = propertiesChangeText + " (" + properties.key + "=" + properties.value + ")" + seperator ;
									j++;
								});			
							});
							
							if(elementType != undefined && elementType == 'editor-form'){
							
								var currentElementObj = $(Obj);
								
								var elementHeight = Math.floor(parseInt($(currentElementObj).height(), 10));
								var elementWidth = Math.floor(parseInt($(currentElementObj).width(), 10));
								
								var formatingArray = ['bold', 'editor'];
								var logData = {};
								logData["element_type"] = elementType;
								logData["properties_change_text"] = propertiesChangeText;
								logData["element_height"] = elementHeight;
								logData["element_width"] = elementWidth;
								common.createActivityLog('editor', currentElementObj, Obj, count, formatingArray, logData);
								
							} else {
								var currentElementObj = $(Obj).children(':first');
								fieldType = common.getAdTagName(currentElementObj);
								
								var elementPositionLeft = Math.floor(parseInt($(currentElementObj).parent().css('left'), 10));
								var elementPositionTop = Math.floor(parseInt($(currentElementObj).parent().css('top'), 10));
								
								var formatingArray = ['bold', 'edit'];
								var logData = {};
								logData["element_type"] = fieldType;
								logData["properties_change_text"] = propertiesChangeText;
								logData["element_left"] = elementPositionLeft;
								logData["element_top"] = elementPositionTop;
								common.createActivityLog('properties', currentElementObj, Obj, count, formatingArray, logData);							
							}
						}
					} else if(event == 'save-form'){
						var currentElementObj = $(Obj);
						if(common.len(customData) > 0) {
						
							var elementWidth = Math.floor(customData.width);
							var elementHeight = Math.floor(customData.height);
							
							var formatingArray = ['bold', 'save'];
							var logData = {};
							logData["element_type"] = elementType;
							logData["element_width"] = elementWidth;
							logData["element_height"] = elementHeight;
							common.createActivityLog('save', currentElementObj, Obj, count, formatingArray, logData);
						}
					} else {
						$.each(event, function(index, item) {
							var fieldType = "";
							switch(event[ index ]) {
								case 'drop':
									if(ui.draggable.hasClass('drags')) {
										var currentElementObj = $(Obj).children(':first');
										fieldType = common.getAdTagName(currentElementObj);
										
										var elementPositionLeft = Math.floor(parseInt($(currentElementObj).parent().css('left'), 10));
										var elementPositionTop = Math.floor(parseInt($(currentElementObj).parent().css('top'), 10));
										
										var formatingArray = ['bold', 'new'];
										var logData = {};
										logData["element_type"] = fieldType;
										logData["element_left"] = elementPositionLeft;
										logData["element_top"] = elementPositionTop;
										common.createActivityLog('new', currentElementObj, Obj, count, formatingArray, logData);	
										
									} else {
										var currentElementObj = $(ui.draggable).children(':first');
										fieldType = common.getAdTagName(currentElementObj);
										
										var elementPositionLeft = Math.floor(ui.position.left);
										var elementPositionTop = Math.floor(ui.position.top);
										
										var formatingArray = ['bold', 'edit'];
										var logData = {};
										logData["element_type"] = fieldType;
										logData["element_left"] = elementPositionLeft;
										logData["element_top"] = elementPositionTop;
										common.createActivityLog('drop', currentElementObj, ui.draggable, count, formatingArray, logData);
									}								
								break;
								case 'resize':
									var currentElementObj = $(ui.element);
									fieldType = common.getAdTagName(currentElementObj);
									
									var elementPositionHeight = Math.floor(ui.size.height);
									var elementPositionWidth = Math.floor(ui.size.width);
									
									var formatingArray = ['bold', 'edit'];
									var logData = {};
									logData["element_type"] = fieldType;
									logData["element_height"] = elementPositionHeight;
									logData["element_width"] = elementPositionWidth;
									common.createActivityLog('resize', currentElementObj, ui.element, count, formatingArray, logData);								
																	
								break;
								case 'click':
									var currentElementObj = $(Obj).children(':first');
									fieldType = common.getAdTagName(currentElementObj);
									if(common.len(customData) > 0) {
									
										var elementPositionLeft = Math.floor(customData.left.replace("px", ""));
										var elementPositionTop = Math.floor(customData.top.replace("px", ""));
										
										var formatingArray = ['bold', 'delete'];
										var logData = {};
										logData["element_type"] = fieldType;
										logData["element_left"] = elementPositionLeft;
										logData["element_top"] = elementPositionTop;
										common.createActivityLog('delete', currentElementObj, Obj, count, formatingArray, logData);
									}
								break;
							}
						});
					}
					common.setActivityLog(activityControlsLog);
					$('#activity_log_count').val(count);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: set activity log into box as per element controls using on form editor.
			 * @ Params: object
			 * @ Returns: N/A
			/*************/
			setActivityLog: function(activityControlsLog) {
				try {					
					if(common.len(activityControlsLog) > 0) {
						$('#activity_log_content').html('');
						var i = 0;
						var activityFullLog = activityControlsLog;
						var activityControlsSortLog = common.sortObjectByKey(activityFullLog, 'desc');						
						$.each(activityControlsSortLog, function(index, controlLog) {
							if(i >= 5) return;
							var activitySortLog = common.sortObjectByKey(controlLog, 'desc');
							var activityControlsSortKeys = common.sortObjectByKey(Object.keys(activityFullLog), 'desc');
							var j = 0;
							$.each(activitySortLog, function(inc, item) {
								if(item != null && item != "") {
									if(j >= 1) return;
									$('#activity_log_content').append('<li class="activity_log_part">' + item + '&nbsp;&nbsp;<a href="javascript:void(0);" data-element-id="' + activityControlsSortKeys[ index ] + '" class="view_activity_log" alt="see activity log">See All</a></li>');
									j++;
								}
							});
							i++;
						});				
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: create the log based on different types of parameters.
			 * @ Params: log type, current element object, count, faormating array, log custom data
			 * @ Returns: N/A
			/*************/
			createActivityLog: function(logType, currentElementObj, Obj, count, formatingArray, logData) {
				try {
					switch(logType) {
						case 'editor':
							common.setActivityLogFormating(currentElementObj, formatingArray);
							var name = $('#text_node_activity_log').html();
							var controlsId = $(Obj).attr('id');
							if( Object.prototype.toString.call( activityControlsLog[ controlsId ] ) !== '[object Array]' ) activityControlsLog[ controlsId ] = [];
							activityLogText =  name + " : " + logData['element_type'] + "'s properties " + logData['properties_change_text'] + " has been changed width dimension (" + logData['element_height'] + "px height and " + logData['element_width'] + "px width)";
							activityControlsLog[ controlsId ][ count ] = activityLogText;
						break;
						case 'new':
							common.setActivityLogFormating(currentElementObj, formatingArray);
							var name = $('#text_node_activity_log').html();
							var controlsId = $(Obj).attr('id');
							if( Object.prototype.toString.call( activityControlsLog[ controlsId ] ) !== '[object Array]' ) activityControlsLog[ controlsId ] = [];
							activityLogText =  name + " : " + logData['element_type'] + " controls has been added at the position (" + logData['element_left'] + "px left and " + logData['element_top'] + "px top)";
							activityControlsLog[ controlsId ][ count ] = activityLogText;
						break;
						case 'drop':
							common.setActivityLogFormating(currentElementObj, formatingArray);
							var name = $('#text_node_activity_log').html();
							var controlsId = $(Obj).attr('id');
							if( Object.prototype.toString.call( activityControlsLog[ controlsId ] ) !== '[object Array]' ) activityControlsLog[ controlsId ] = [];
							activityLogText = name + " : " + logData['element_type'] + " controls has been changed position at (" + logData['element_left'] + "px left and " + logData['element_top'] + "px top)";
							activityControlsLog[ controlsId ][count] = activityLogText;
						break;
						case 'resize':
							common.setActivityLogFormating(currentElementObj, formatingArray);
							var name = $('#text_node_activity_log').html();
							var controlsId = $(Obj).parent().attr('id');
							if( Object.prototype.toString.call( activityControlsLog[ controlsId ] ) !== '[object Array]' ) activityControlsLog[ controlsId ] = [];
							activityLogText = name + " : " + logData['element_type'] + " controls has been changed dimension with (" + logData['element_height'] + "px height and " + logData['element_width'] + "px width)";
							activityControlsLog[ controlsId ][ count ] = activityLogText;
						break;
						case 'delete':
							common.setActivityLogFormating(currentElementObj, formatingArray);
							var name = $('#text_node_activity_log').html();
							var controlsId = $(Obj).attr('id');
							if( Object.prototype.toString.call( activityControlsLog[ controlsId ] ) !== '[object Array]' ) activityControlsLog[ controlsId ] = [];
							activityLogText = name + " : " + logData['element_type'] + " controls has been deleted at position (" + logData['element_left'] + "px left and " + logData['element_top'] + "px top)";
							activityControlsLog[ controlsId ][ count ] = activityLogText;
						break;
						case 'properties':
							common.setActivityLogFormating(currentElementObj, formatingArray);
							var name = $('#text_node_activity_log').html();
							var controlsId = $(Obj).attr('id');
							if( Object.prototype.toString.call( activityControlsLog[ controlsId ] ) !== '[object Array]' ) activityControlsLog[ controlsId ] = [];
							activityLogText =  name + " : " + logData['element_type'] + " controls's properties " + logData['properties_change_text'] + " has been changed at the position (" + logData['element_left'] + "px left and " + logData['element_top'] + "px top)";
							activityControlsLog[ controlsId ][ count ] = activityLogText;
						break;
						case 'save':
							common.setActivityLogFormating(currentElementObj, formatingArray);
							var name = $('#text_node_activity_log').html();
							var controlsId = $(currentElementObj).html();
							if( Object.prototype.toString.call( activityControlsLog[ controlsId ] ) !== '[object Array]' ) activityControlsLog[ controlsId ] = [];
							activityLogText =  name + " : " + logData['element_type'] + " has been saved with dimension (" + logData['element_height'] + "px height and " + logData['element_width'] + "px width) at " + new Date();
							activityControlsLog[ controlsId ][ count ] = activityLogText;
						break;						
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: sort object by key according to parameter passed acsending or descending.
			 * @ Params: object, sort type
			 * @ Returns: Array
			/*************/
			sortObjectByKey: function(obj, order ) {
				try {
					var key, tempArry = [], i, tempSortArray = [];
				 
					for ( key in obj ) {
						tempArry.push(key);
					}
					
					/*tempArry.sort(
						function(a, b) {
							return parseInt(a.toLowerCase().localeCompare( b.toLowerCase() ));
						}
					);*/
				 
					if( order === 'desc' ) {
						for ( i = tempArry.length - 1; i >= 0; i-- ) {
							tempSortArray.push(obj[ tempArry[i] ]);
						}
					} else {
						for ( i = 0; i < tempArry.length; i++ ) {
							tempSortArray.push(obj[ tempArry[i] ]);
						}
					}					
					return tempSortArray;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: show activity log based on the current element id passed from activity log Object.
			 * @ Params: current element id
			 * @ Returns: N/A
			/*************/
			showActivityLogByElement: function(currentElementId) {
				try {
					var name = $('#' + currentElementId).children(':first').attr('name');
					var titleName = (name == undefined) ? 'list' : name;
					var title = 'Activity log of (' + titleName + ')';
					common.showCustomeDialog('activity-log-modal', title, 650, 350);
					if(common.len(activityControlsLog) > 0) {
						$('#activity-log-modal').find('#activity_log_details').html('');
						var i = 0;
						$.each(activityControlsLog, function(index, controlLog) {
							if(index == currentElementId) {
								var activitySortLog = common.sortObjectByKey(controlLog, 'desc');						
								$.each(activitySortLog, function(inc, item) {
									if(item != null && item != "") {
										$('#activity_log_details').append('<div class="activity_log_details_part">' + item + '</div>');
									}
								});
							}
							i++;
						});				
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: get the changes value after comparing the prvious properties object and new properties object.
			 * @ Params: Previous Object, and New Object
			 * @ Returns: Object or boolean
			/*************/
			getChanges: function (previousObj, currentObj) {
				try {
					var changes = {}, prop;
					for (prop in currentObj) {
						if (!previousObj || previousObj[ prop ] !== currentObj[ prop ]) {
							if (typeof currentObj[ prop ] == "object") {
								if(c = this.getChanges(previousObj[ prop ], currentObj[ prop ])) {
									changes[ prop ] = c;
								}
							} else {
								changes = currentObj;
							}
						}
					}
					if(common.len(changes) > 0) {
						return changes;
					} else {
						return false;
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: set the style formatting on name of the controls.
			 * @ Params: control object, styleing type
			 * @ Returns: Object or boolean
			/*************/
			setActivityLogFormating: function(Obj, styleTypeArray) {
				try {					
					$.each(styleTypeArray, function(index, type) {
						
						switch(type) {
							case 'bold':
								var name = $(Obj).attr('name');
								var s = document.createElement("strong")
								var t = document.createTextNode(name);
								s.appendChild(t);
								$('#text_node_activity_log').html(s);
							break;
							case 'new':
								var name = $(Obj).attr('name');
								var s = document.createElement("strong")
								s.style.backgroundColor = "green";
								s.style.color = "white";
								s.style.padding = "2px";
								var t = document.createTextNode(name);
								s.appendChild(t);
								$('#text_node_activity_log').html(s);
							break;
							case 'edit':
								var name = $(Obj).attr('name');
								var s = document.createElement("strong")
								s.style.backgroundColor = "yellow";
								s.style.padding = "2px";
								var t = document.createTextNode(name);
								s.appendChild(t);
								$('#text_node_activity_log').html(s);
							break;
							case 'delete':
								var name = $(Obj).attr('name');
								var s = document.createElement("strong")
								s.style.backgroundColor = "red";
								s.style.color = "white";
								s.style.padding = "2px";
								var t = document.createTextNode(name);
								s.appendChild(t);
								$('#text_node_activity_log').html(s);
							break;
							case 'editor':
								var s = document.createElement("strong")
								s.style.backgroundColor = "yellow";
								s.style.padding = "2px";
								var t = document.createTextNode('editor-form');
								s.appendChild(t);
								$('#text_node_activity_log').html(s);
							break;
							case 'save':
								var name = $(Obj).html();
								var s = document.createElement("strong")
								s.style.backgroundColor = "#CCCC66";
								s.style.padding = "2px";
								var t = document.createTextNode(name);
								s.appendChild(t);
								$('#text_node_activity_log').html(s);
							break;
						}
					});
					
					return name;
					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			}

		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
jQuery(document).ready(function($){
	common.init();
	var templateObj = new Template();
	baseUrl = templateObj.base_url;	
});