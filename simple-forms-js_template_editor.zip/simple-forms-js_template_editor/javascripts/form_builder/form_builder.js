/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD
 * @ Dependency : "common.js, config_fields.js"
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */
form_builder = {};

(function($) {
	
		form_builder = {
				
			editorFormFont: '',
			/*********
			 * @ Desc: Pre Define the all the font family
			 * @ Params: N/A
			 * @ Returns: Array
			/*************/
			fontFamily: function() {
				return new Array('Antiqua', 'Arial', 'Arial Black', 'Avqest', 
								'Blackletter', 'Calibri', 'Comic Sans', 'Courier', 
								'Charcoal', 'Decorative',	'Fraktur', 'Frosty', 'Geneva', 
								'Garamond', 'Georgia', 'Helvetica', 'Impact',
								'Minion', 'Modern', 'Monospace', 'Palatino',
								'Roman', 'Script', 'Swiss', 'Sans-serif', 
								'Times New Roman', 'Tahoma', 'Verdana');
			},
			
			/*********
			 * @ Desc: Pre Define the all the font weight property
			 * @ Params: N/A
			 * @ Returns: Array
			/*************/
			fontWeight: function(){
				return new Array('normal', 'bold', 'lighter');
			},
			
			/*********
			 * @ Desc: Pre Define the all the font style property
			 * @ Params: N/A
			 * @ Returns: Array
			/*************/
			fontStyle: function(){
				return new Array('normal', 'italic');
			},
			
			/*********
			 * @ Desc: Pre Define the all the text align property
			 * @ Params: N/A
			 * @ Returns: Array
			/*************/
			textAlign: function(){
				return new Array('left', 'right', 'center', 'justify');
			},
			
			/*********
			 * @ Desc: Pre Define the all the text decoration property
			 * @ Params: N/A
			 * @ Returns: Array
			/*************/
			textDecoration: function(){
				return new Array('none', 'underline', 'overline', 'line-through', 'blink');
			},
			
			/*********
			* @ Desc: Pre Define pattern list
			* @ Params: N/A
			* @ Returns: Array
			/*************/				
			pattern: function(){
				return new Array(
					{"Digit": "^\\d+$"},
					{"AlphaNum": "^\\w+$"},
					{"Numeric": "^-?(?:\\d+|\\d{1,3}(?:,\\d{3})+)?(?:\\.\\d+)?$"},
					{"Phone No.": "^[0-9]\\d{2}-\\d{3}-\\d{4}$"},
					{"Email": "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$"}
				);
			}, 
			
			/*********
			 * @ Desc: Initialize default function with page load. Define the different types of action perform on document.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			init: function() {
				
				//set timer for auto form save after 30 seconds.
				var stimeout = 30000;
				$(document).unbind("idle.idleTimer").bind("idle.idleTimer", function(){
					if($('ul#list').find('input[type="submit"]').length > 0 
						&& $('.form-template-name').html() != "" 
						&& $('#locations').val() != "") {
						form_builder.save();
					}
				});
				$(document).idleTimer(stimeout);
				// timer end
				
				$('#form_panel').ruler();					
				$(document).tooltip({
					tooltipClass: "custom-tooltip-styling",
					open: function( event, ui ) {
						$('.custom-tooltip-styling').css({
							'z-index': '9999999',
							'line-height': '5px',
							'padding': '5px 7px 7px 7px',
							'border': '2px solid #9AAFE5',
							'font-size': '10px',
							'font-style': 'italic'
						});
					}
				});
				var options = {
					lineColour : '#ffffff',
					bgColor : '#ffffff'
				};
				$('.sigPad').signaturePad(options);					
				$('ul#list').width($('ul#list').width());
				
				//Initialized the template class function when page load.
				var templateObj = new Template();
				this.getEvents();					
				this.getPersistent();					
				this.getLocations();					
				this.getImages();					
				
				/*********
				 * @ Desc: Click to know which element is clicked on document.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						draggableEventOn = e.target;													
					}
				}, 'html body');
				
				/*********
				 * @ Desc: Click function on "element-properties" class, In this action, Add cross button
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var id = $(this).parent().attr('id');							
						var totalCross = $(this).parent().find('div.button-container').length;
						if(totalCross == 0 ) {
							$('#' + id).append(form_builder.crossButton());
						}
						$('ul#list div.form-row').each(function() {
								var liId = $(this).attr('id');
								if(liId == id) {
									$('#' + liId).find('.button-container').show();
									$('#' + liId)
										.addClass('selected')
										.draggable({containment: 'parent'});
									draggableEventOn = this;
								} else {
									$('#' + liId).find('.button-container').hide();
									$('#' + liId)
										.removeClass('selected');
								}
						});														
					}
				}, '.element-properties');
				
				/*********
				 * @ Desc: Click function on "index-cross" class, In this action, Remove element
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var id = $(this).parent().parent().attr('id');
						if(id != '' && id != null) {
							if (confirm('Are you sure to remove this fields!')) {
								$("#" + id).hide("slow", function(){
									if($('#update_form_id').val() != undefined && $('#update_form_id').val() != "") {
										var deleteData = {};
										deleteData['left'] = $("#" + id).css('left');
										deleteData['top'] = $("#" + id).css('top');
										common.captureChangesInEditor(e, "", $("#" + id), "", deleteData);
									}
									$("#" + id).remove();
									$('#table-general tbody').html('<tr><td valign="top" class="prop-table-value">Click on the fileds to show the properties here!</td></tr>');
									$('ul#list').each(function() {
										var totalFields = $(this).find('div.form-row').length;
										if(totalFields == 0) {
											$(this).html('<li class="placeholder">Add your items here</li>');
										}
									});
								});
							}
						}							
					}											
				}, '.index-cross');
				
				/*********
				 * @ Desc: Click function on "element-properties" class, In this action, Render element properties
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var type = common.getAdTagName(this);
						var fieldsObj = config_controls.config_fields_attributes[type];
						propertiesHtml = form_builder.formPropertiesFields().properties_render(fieldsObj, this, type);
						$('input[type="button"].properties-apply')
							.attr('data-element-id', $(this).parent().attr('id'))
							.attr('data-element-type', type);
						$('#table-general tbody').html(propertiesHtml);
						common.applyColorPicker();
						var data = $('#form_properties_panel').serialize();
						if(data.length > 0) {
							previousPropertiesData = form_builder.getPropertiesApply(data);
						}
					}																		
				}, '.element-properties');
				
				/*********
				 * @ Desc: Click function on "element-properties" class, In this action, Render element properties
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var elementObj = $(this).children(':first');
						var type = common.getAdTagName(elementObj);
						var fieldsObj = config_controls.config_fields_attributes[type];
						propertiesHtml = form_builder.formPropertiesFields().properties_render(fieldsObj, elementObj[0], type);
						$('input[type="button"].properties-apply')
							.attr('data-element-id', $(this).attr('id'))
							.attr('data-element-type', type);
						$('#table-general tbody').html(propertiesHtml);
						common.applyColorPicker();
						var data = $('#form_properties_panel').serialize();
						if(data.length > 0) {
							previousPropertiesData = form_builder.getPropertiesApply(data);
						}
					}																		
				}, 'ul#list div.form-row');

				/*********
				 * @ Desc: Click function on "ul#list" class, In this action, Render element properties of form editor container
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var type = 'editor-form';
						var fieldsObj = config_controls.config_fields_attributes[type];
						propertiesHtml = form_builder.formPropertiesFields().properties_render(fieldsObj, this, type);
						$('input[type="button"].properties-apply')
							.attr('data-element-id', $(this).attr('id'))
							.attr('data-element-type', type);
						$('#table-general tbody').html(propertiesHtml);
						common.applyColorPicker();
						var data = $('#form_properties_panel').serialize();
						if(data.length > 0) {
							previousPropertiesData = form_builder.getPropertiesApply(data);
						}
					}																		
				}, 'ul#list');
				
				/*********
				 * @ Desc: Click function on "form-propbutton" class, In this action, Show properties on right window
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function () {						
						var elementObj = $(contextMenuEventOn).children(':first');							
						var type = common.getAdTagName(elementObj);	
						var fieldsObj = config_controls.config_fields_attributes[type];
						propertiesHtml = form_builder.formPropertiesFields().properties_render(fieldsObj, elementObj[0], type);	
						$('input[type="button"].properties-apply')
							.attr('data-element-id', $(elementObj).parent().attr('id'))
							.attr('data-element-type', type);
						$('#table-general tbody').html(propertiesHtml);
						common.applyColorPicker();				
						var data = $('#form_properties_panel').serialize();
						if(data.length > 0) {
							previousPropertiesData = form_builder.getPropertiesApply(data);
						}
					}																		
				}, '#show-properties');
				
				/*********
				 * @ Desc: Click function on "form-template-name" class, In this action, Add Input textbox for add form name
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						$(this).hide();
						$('#form_name').removeClass('hide');
						$('#form_template_name')
							.attr('placeholder', $(this).text())
							.focus();
					}					
				}, '.form-template-name');
				
				/*********
				 * @ Desc: Click function on "template_name_save" id, In this action, Check form name, add error class if validate false
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						var templTitle = ($('#form_template_name').val() == '') ? 'Untitled Form' : $('#form_template_name').val();
						if(templTitle == 'Untitled Form') {
							$('#form_template_name')
								.focus()
								.addClass('form-builder-error');
						} else {
							$('#form_template_name')
								.removeClass('form-builder-error');
							$('.form-template-name')
								.show()
								.html(templTitle);
							$('#form_name').addClass('hide');
						}							
					}					
				}, '#template_name_save');
				
				/*********
				 * @ Desc: Click function on "save-form" class, In this action, Validate form and Save form content
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function(e) {
						form_builder.save();						
					}
				}, '.save-form');
				
				/*********
				 * @ Desc: Click function on "all_location" id, In this action, checked all or unchecked all location
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						var dataType = $(this).attr('data-type');
						if(dataType == 'deselectall') {
							$('.save-location').prop("checked", false);
						} else {
							$('.save-location').prop('checked', true);							
						}
					}
				}, '.select-all-location');
				
				/*********
				 * @ Desc: Click function on "properties-apply" class, In this action, Apply properties on form element
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {							
						var data = $('#form_properties_panel').serialize();
						if(data.length > 0) {
							var propertiesArray = form_builder.getPropertiesApply(data);			
							var changesObj = common.getChanges(previousPropertiesData, propertiesArray);
							previousPropertiesData = propertiesArray;
							var elementId = $(this).attr('data-element-id');
							var elementType = $(this).attr('data-element-type');
							if(elementId != "") {
								if($('#update_form_id').val() != undefined && $('#update_form_id').val() != "") {
									common.captureChangesInEditor("", "", $('#' + elementId), changesObj, "", elementType);
								}
							}
							var valid = form_builder.checkPropertiesVal(propertiesArray);

							if(valid) {
								form_builder.setPropertiesVal(propertiesArray);
							}
						}
					}
				}, 'input[type="button"].properties-apply');
				
				/*********
				 * @ Desc: Click function on "show_form" class, In this action, Show list of the saved form
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						var dataTemplate = $(this).attr('data-template');
						form_builder.showListDialog(dataTemplate);
					}
				}, '.show_form');
				
				/*********
				 * @ Desc: Click function on "show-form-content" class, In this action, render the content of form
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						form_builder.renderFormContent(this);
					}
				}, '.show-form-content');
				
				/*********
				 * @ Desc: Change function on "add_select_options" class, In this action, Show dialog box for add option into select
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					change: function() {
						var selVal = $(this).val();
						if(selVal == 'add_options')
							form_builder.showOptionDialog(this);
						$(this).val('');
					}
				}, '.add_select_options');
				
				/*********
				 * @ Desc: Change function on "add_select_options" class, In this action, Show dialog box for add option into select
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					change: function() {
						var selVal = $(this).val();
						if(selVal == 'add_custom_pattern') {
							form_builder.setCustomPattern(this);
							$(this).val('');
						}
					}
				}, '.add_pattern');
				
				/*********
				 * @ Desc: Change function on "add_image_upload" class, In this action, Show dialog box for selecting uploaded images
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					change: function() {
						var selVal = $(this).val();
						if(selVal == 'choose_files')
							form_builder.showImageUploadDialog(this);
						$(this).val('');
					}
				}, '.add_image_upload');
				
				/*********
				 * @ Desc: Click function on "select_options_button" class, In this action, Set option list into select
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						form_builder.setOptionList(this);
					}
				}, '.select_options_button');
				
				/*********
				 * @ Desc: Click function on "remove-option_select" class, In this action, Remove Option
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						$(this).parent().remove();
					}
				}, '.remove-option_select');
				
				/*********
				 * @ Desc: Click function on "select_options_cancel" class, In this action, Close dialog box
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						$('#dialog-modal').dialog("close");
					}
				}, '.select_options_cancel');
				
				/*********
				 * @ Desc: Click function on "select_pattern_cancel" class, In this action, Close dialog box
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						$('#add-pattern-modal').dialog("close");
					}
				}, '.select_pattern_cancel');
				
				/*********
				 * @ Desc: Click function on "select_image_cancel" class, In this action, Close dialog box
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function() {
						$('#file-upload-modal').dialog("close");
					}
				}, '.select_image_cancel');
				
				/*********
				 * @ Desc: Click function on "select_options_done" class, In this action, Add option list into property side select dropdown
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function(e) {
						e.stopPropagation();
						var optionLength = 0;
						$('.options-list-place').each(function(){
							optionLength = $(this).find('p.options-list').length;
						});
						if(optionLength > 0) {
							var select = $('#' + $('.select_options_done').attr('data-select'));
							if(select.prop) {
							  var options = select.prop('options');
							} else {
							  var options = select.attr('options');
							}
							//$('option[value!=add_options]', select).remove();
							$(select).find('option').each(function(){
								if($(this).val() != 'no' && $(this).val() != 'add_options') {
									$(this).remove();
								}
							});

							$('.options-list-place p.options-list').each(function(){
								var optionLabel = $(this).find('input[data-type=label]').val();
								var optionValue = $(this).find('input[data-type=value]').val();
								if(optionLabel != '' && optionValue != '') {
									//console.log(optionLabel + "===========" + optionValue);
									o = new Option( optionLabel, optionValue);
									$(o).html(optionLabel);
									$(select).append(o);
									$('#dialog-modal').dialog("close");
								}
							});
							select.val('');
							
						}							
					}
				}, '.select_options_done');					
				
				/*********
				 * @ Desc: Click function on "select_pattern_done" class, In this action, Add pattern into property side select dropdown
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function(e) {
						e.stopPropagation();
						var patternLabel = $.trim($('#select_pattern_label').val());
						var patternValue = $.trim($('#select_pattern_value').val());
						if(patternLabel !=''  && patternValue !='') {
							var select = $('#' + $('.select_pattern_done').attr('data-select'));
							if(select.prop) {
							  var options = select.prop('options');
							} else {
							  var options = select.attr('options');
							}
							
							if(patternLabel != '' && patternValue != '') {
								//console.log(patternLabel + "===========" + patternValue);
								o = new Option( patternLabel, patternValue);
								$(o).html(patternLabel);
								$(select).append(o);
								patternValue = patternValue.replace(/\\/g, "\\\\");
								$(select).find("option[value='" + patternValue +"']").attr("selected","selected");
								$(select).attr('data-pattern', patternValue);
								$('#add-pattern-modal').dialog("close");
							}								
						}							
					}
				}, '.select_pattern_done');
				
				/*********
				 * @ Desc: Click function on "input[type=checkbox]" class, In this action, Set checked attributes true or false
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						if($(this).is(":checked") == false) {
							$(this).removeAttr('checked');
						} else {
							$(this).attr('checked', true);
						}
					}																		
				}, 'ul#list input[type=checkbox]');
				
				/*********
				 * @ Desc: Click function on "input[type=radio]" class, In this action, Set checked attributes true or false on same name attributes value
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var name = $(this).attr("name");
						var id = $(this).attr("id");
						$('ul#list div.form-row').each(function(index, item) {
							var radioObj = $(this).children(':first[name="' + name + '"]');
							if(radioObj.length > 0) {
								var nameAttr = $(radioObj).attr('name');
								var idAttr = $(radioObj).attr('id');
								if(id == idAttr) {
									$('#' + idAttr).attr('checked', true);
								} else {
									$('#' + idAttr).removeAttr('checked');
								}
							}
						});
					}																		
				}, 'ul#list input[type=radio]');
				
				/*********
				 * @ Desc: Click function on "show-library-data" class, In this action, show the list of form according to library selection
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var type = $(this).attr("data-type");
						var dataTemplate = $(this).attr("data-template");
						form_builder.getSavedForm(type, dataTemplate);
					}																		
				}, '.show-library-data');
				
				/*********
				 * @ Desc: Click function on "delete-template" class, In this action, show the list of form according to library selection
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var formId = $(this).attr("data-id");
						var boxType = $(this).attr("data-type");
						$('ul#list').html('<li class="placeholder">Add your items here</li>');
						$('#update_form_id').val('');
						var dataTemplate = $(this).attr("data-template");
						form_builder.deleteForm(formId, boxType, dataTemplate);
					}																		
				}, '.delete-template');
				/*********
				 * @ Desc: Click function on "publish-template" class, In this action, publish template
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var formId = $(this).attr("data-id");
						var boxType = $(this).attr("data-type");
						var dataTemplate = $(this).attr("data-template");
						form_builder.publishTemplate(formId, boxType, dataTemplate);														
					}
				}, '.publish-template');
				
				/*********
				 * @ Desc: Click function on anchor tag for pagination of form template listing.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var templateObj = new Template();
						templateObj.setValue('async', Template.async);
						templateObj.setValue('url', this.href + '&library_type=' + $('#library_type').val() + '&data_template=' + $('.delete-template').attr('data-template'));
						templateObj.setValue('library_type', $('#library_type').val());							
						templateObj.setValue('data_template', $('.delete-template').attr('data-template'));							
						templateObj.setValue('target', 'show_form');							
						templateObj.templatePagination();
						//$.getScript(this.href + '&library_type=' + $('#library_type').val() + '&data_template=' + $('.publish-template').attr('data-template'));
						return false;														
					}
				}, '#form_dialog_modal .pagination a.template-pagination');					
				
				/*********
				 * @ Desc: Click function on "edit-form" class, In this action, edit the template for value
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var formId = $(this).attr("data-id");
						var boxType = $(this).attr("data-type");
						form_builder.getTemplateForm(formId, boxType);														
					}
				}, '.edit-form');
				
				/*********
				 * @ Desc: Click function on "copy-properties" id, In this action, copy the style properties of selected element
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						if ($(contextMenuEventOn).children(':first').attr('style') != undefined) {
							var elementStyle = $(contextMenuEventOn).children(':first').attr('style');
							contextMenuEventApply = elementStyle;
						}
					}
				}, '#copy-properties');
				
				/*********
				 * @ Desc: Click function on "paste-properties" id, In this action, paste the style properties on selected element
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						if (contextMenuEventApply != '') {
							$(contextMenuEventOn).children(':first').attr('style', contextMenuEventApply);
						}
					}
				}, '#paste-properties');
				
				/*********
				 * @ Desc: Click function on "form_properties_panel input[type=text]" id, In this action, active properties change variable
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					keyup: function (e) {
						e.stopPropagation();
						propertiesChanged = true;
					}
				}, '#form_properties_panel input[type=text]');
				
				/*********
				 * @ Desc: Click function on "#form_properties_panel select" class, In this action, active properties change variable
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					change: function (e) {
						e.stopPropagation();
						propertiesChanged = true;
					}
				}, '#form_properties_panel select');
				
				/*********
				 * @ Desc: Click function on "select_image_done" class, In this action, select one image for control.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						
						var imageSelect = false;
						var imageLength = 0;
						$('#image-list-box-table').each(function(){
							imageLength = $(this).find('input[type=radio]').length;
							$('#image-list-box-table').find('input[type=radio]').each(function(){
								if($(this).is(":checked")) {
									imageSelect = $(this).prop('checked');
								}
							});
						});
						
						if(imageLength > 0) {
							if(imageSelect) {
								var select = $('#' + $('.select_image_done').attr('data-select'));
								if(select.prop) {
								  var options = select.prop('options');
								} else {
								  var options = select.attr('options');
								}
								
								$(select).find('option').each(function() {
									if($(this).val() != 'no' && $(this).val() != 'choose_files') {
										$(this).remove();
									}
								});

								$('#image-list-box-table input[type=radio]:checked').each(function(){
									var inputValue = $(this).val();
									if(inputValue != '') {
										o = new Option( inputValue, inputValue);
										$(o).html(inputValue);
										$(select).append(o);
										$(select).find("option[value='" + inputValue +"']").attr("selected","selected");
										$(select).attr('data-image', inputValue);
										$('#file-upload-modal').dialog("close");
									}
								});			
								
							} else {
								alert('Please select one from list!');
							}
						} else {
							alert('Please upload image first!');
						}
					}
				}, '.select_image_done');
				
				/*********
				 * @ Desc: Click function on "delete_image" id, In this action, delete the selected image
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						form_builder.deleteUploadedImage(this);
					}
				}, '#delete_image');
				
				/*********
				 * @ Desc: Click function on "refresh_list" id, In this action, refresh the list of template images
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						form_builder.getImages();							
					}
				}, '#refresh_list');
				
			},
			
			save: function() {
				var valid = true;
						
				if($('ul#list').find('li:first').hasClass('placeholder')) {
					alert('Please add some fields before saving template form !!!');
					return false;
				}
				
				var checkSubmit = false;
				var checkSignature = false;
				var checkInkingOverlay = false;
				var submitButtons = {};
				var signaturePad = {};
				var inkingOverlay = {};
				var formWidth = $('ul#list').width();
				var formHeight = $('ul#list').height();
				
				$('ul#list div.form-row').each(function(index) {
					var type = common.getTagName($(this).children(':first'));
					if(type == 'submit') {
						$(this).children(':first')
							.attr('data-form-width', formWidth)
							.attr('data-form-height', formHeight);
						checkSubmit = true;
						submitButtons[ index ] = type
					}
					
					if($(this).children(':first').hasClass('form-simple-signature')) {
						checkSignature	= true;
						signaturePad[ index ] = $(this).attr('id');
					}
					
					if($(this).children(':first').hasClass('form-inking-overlay')) {
						checkInkingOverlay = true;
						inkingOverlay[ index ] = $(this).attr('id');
					}
					
				});
				
				if(checkSignature) {
					if (common.len(signaturePad) > 1) {
						alert('Please add one signature pad only !!!');
						return false;
					}
				}
				
				if(checkInkingOverlay) {
					if (common.len(inkingOverlay) > 1) {
						alert('Please add one inking overlay only !!!');
						return false;
					}
				}
				
				if(!checkSubmit) {
					alert('Please add one submit button !!!');
					return false;
				} else if (common.len(submitButtons) > 1) {
					alert('Please add one submit button only !!!');
					return false;
				}
				
				var templateName = $('#form_template_name').val();
				var templateTitle = $('.form-template-name').html();
				if(templateName == '' || templateTitle == 'Untitled Form') {
					$('.form-template-name').hide();
					$('#form_name').removeClass('hide');
					$('#form_template_name')
						.focus()
						.addClass('form-builder-error')
						.attr('placeholder', $('.form-template-name').html());
					valid = false;
				}							
				
				var paramsAttributes = new Array();
				$('ul#list div.form-row').each(function() {
					var liId = $(this).attr('id');
					$('#' + liId).removeClass('selected');
					
					paramsAttributes.push({master:form_builder.getFieldsParams($(this).children(':first'))});
					
				});
				
				var formHtml = $.trim($('ul#list').html());
				var content = common.strRemove('.button-container', formHtml);
				content = common.strRemove('.ui-resizable-handle', content);
				content = common.strRemove('.ui-datepicker-trigger', content);
				
				var locations = $('#locations').val();
				var locationsUrl = "";
				if(Template.locationsArray.length > 0) {
					$.each(Template.locationsArray, function(index, item) {
						if(item.hasOwnProperty('template_library')) {
							if(locations == item.template_library.id) {
								locationsUrl = item.template_library.url;
							}
						} else {
							if(locations == item.id) {
								locationsUrl = item.url;
							}
						}							
					});
				}
				
				if(locations == "") {
					alert('Please select location!');
					saveValid = false;
				} else {
					saveValid = true;
				}
				
				// capture the activity log before save
				if($('#update_form_id').val() != undefined && $('#update_form_id').val() != "") {
					var formData = {};
					formData['width'] = formWidth;
					formData['height'] = formHeight;
					common.captureChangesInEditor("save-form", "", $('.form-template-name'), "", formData, "form");
				}
				
				// get the final activity log before save
				var finalActivityLog = "";
				if(common.len(activityControlsLog) > 0) {
					var activityLogJSON = new Array();
					activityLogJSON.push(activityControlsLog);
					finalActivityLog = JSON.stringify(activityLogJSON);
				}						
				
				//return false;
				if(saveValid && valid) {
					
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('locations_url', locationsUrl);
					templateObj.setValue('content', content);
					templateObj.setValue('name', $('.form-template-name').html());
					templateObj.setValue('id', $('#update_form_id').val());
					templateObj.setValue('column', paramsAttributes);
					templateObj.setValue('locations', locations);
					templateObj.setValue('template_type', ($('#template_form_value').val() == 0) ? 'new_form' : 'value_form');
					templateObj.setValue('activity_log', finalActivityLog);
					templateObj.setValue('target', 'save_form');								
					templateObj.save();
					
				}			
			},
			
			/*********
			 * @ Desc: Show saving location dialog pop box
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			showSaveLocationBox: function() {
				try {
					common.showDialog('Saving Form Location');
					var saveLocationHtml = $("#saving_location").html();
					$("#dialog-modal").html(saveLocationHtml);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Check properties value after apply if duplication name or id exists on form editior based on conditions
			 * @ Params: element propeties as object
			 * @ Returns: boolean
			/*************/
			checkPropertiesVal: function(properties) {
				try {
					if(properties.general.length > 0) {
						var valid = true;
						var id = '';
						var name = '';
						var tempIdArray = {};
						var tempNameArray = {};
						var selId = $('#table-general tr').attr('data-id');
						var selObj = $('#' + selId).children(":first")
						var selNameField = $(selObj).attr("name");
						var selIdField = $(selObj).attr("id");						
							
						$('ul#list div.form-row').each(function(index, item) {
							
							var element = $(this).children(':first');
							var type = common.getTagName(element);
							name = $(element).attr('name');
							id = $(element).attr('id');
							
							if(selIdField != id) {
								tempIdArray[ id ] = index;
							}
							
							if(type != 'radio' && type != 'checkbox') {
								if(selNameField != name) {
									tempNameArray[ name ] = index;
								}
							}
						});
					
						//console.log(properties.general);						
						$.each(properties.general, function(index, item) {
							switch(item.key) {
								case 'id':
									var conditions = (tempIdArray.hasOwnProperty(item.value)) ? true : false;
									var errorTitle = 'Id must be Unique!';
									valid = form_builder.setPropertiesError('.id-check-validation', conditions, valid, errorTitle);
								break;
								case 'name':
									var conditions = (tempNameArray.hasOwnProperty(item.value)) ? true : false;
									var errorTitle = 'Name must be Unique!';
									valid = form_builder.setPropertiesError('.name-check-validation', conditions, valid, errorTitle);
								break;
								case 'auto-suggest':
									var datePickerCondition = ($('.datepicker-check-validation').val() == 'datepicker') ? true : false;
									var dateTimePickerCondition = ($('.datetime-picker-check-validation').val() == 'datetimepicker') ? true : false;
									var conditions = (($(selObj).hasClass('hasDatepicker') && item.value == 'enabled') || (datePickerCondition && item.value == 'enabled') || (dateTimePickerCondition && item.value == 'enabled')) ? true : false;
									var errorTitle = 'Date Picker or Date Time Piker is applied on it. Please reset first!';
									valid = form_builder.setPropertiesError('.autosuggest-check-validation', conditions, valid, errorTitle);
								break;
								case 'date-picker':
									var autoSuggestCondition = ($('.autosuggest-check-validation').val() == 'enabled') ? true : false;
									var conditions = (($(selObj).attr('autosuggest') == 'enabled' && item.value == 'datepicker') || (autoSuggestCondition && item.value == 'datepicker')) ? true : false;
									var errorTitle = 'Auto Suggest is applied on it. Please reset first!';
									valid = form_builder.setPropertiesError('.datepicker-check-validation', conditions, valid, errorTitle);
								break;
								case 'date-time-picker':
									var autoSuggestCondition = ($('.autosuggest-check-validation').val() == 'enabled') ? true : false;
									var conditions = (($(selObj).attr('autosuggest') == 'enabled' && item.value == 'datetimepicker') || (autoSuggestCondition && item.value == 'datetimepicker')) ? true : false;
									var errorTitle = 'Auto Suggest is applied on it. Please reset first!';
									valid = form_builder.setPropertiesError('.datetime-picker-check-validation', conditions, valid, errorTitle);
								break;
							}									
						});
						
					}
					return valid;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Set the form builder properties class error apply and tooltip into appropriate properties based on conditions.
			 * @ Params: properties element, condition as boolean, valid as boolean, error title display in tooltip
			 * @ Returns: boolean
			/*************/
			setPropertiesError: function(propertiestElement, condition, valid, errorTitle) {
				try {
					var propertiesTextElement = $(propertiestElement).parent().parent().prev();
					var propertiesDesc = $(propertiesTextElement).find('span.prop-table-detail');
					var propertiesCloneObj = $(propertiesTextElement).clone();
					$(propertiesCloneObj).children(':first').remove();
					var propertiesTextLabel = $(propertiesCloneObj).text();
					var abbrPropertiesObj = $(propertiesTextElement).find('abbr');
					var propertiesFirstText = ($(abbrPropertiesObj).length) ? $(abbrPropertiesObj).text() : propertiesTextLabel;
					$(propertiesTextElement).html('');
					
					if(condition) {
						valid = false;
						$(propertiestElement).addClass('form-builder-error');
						$(propertiestElement).focus();
						
						$(propertiesTextElement).append('<abbr title="' + errorTitle + '">' + propertiesFirstText + '</abbr>');
						$(propertiesTextElement).append(propertiesDesc);
					} else {
						$(propertiestElement).removeClass('form-builder-error');						
							
						$(propertiesTextElement).append(propertiesFirstText);						
						$(propertiesTextElement).append(propertiesDesc);
					}
					
					return valid;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the properties apply value
			 * @ Params: Object
			 * @ Returns: Array
			/*************/
			getPropertiesApply: function(data) {
				try {
					var propertiesArray ={};
					if(data.length > 0) {
						var filedProperties = form_builder.getGeneralPropertiesVal(data);
						var filedStyleProperties = form_builder.getStylePropertiesVal(data);							
						propertiesArray['general'] = filedProperties;
						propertiesArray['style'] = filedStyleProperties;
					}
					return propertiesArray;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get fields parameters from attributes "name" and "data-description" before save
			 * @ Params: Object
			 * @ Returns: Array
			/*************/
			getFieldsParams: function(fieldObj) {
				try {
					//console.log(fieldObj);
					var attributes = {}; 
					var Obj = $(fieldObj)[0];
					$.each(Obj.attributes, function(index, attr) {
						attributes[ attr.name ] = attr.value;
					});

					var params = {};
					$.each(attributes, function(index, item){						
						if(index == 'name' || index == 'data-description') {
							params[index] = item;
						}
					});

					return params;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get general fields properties from attributes before properties apply
			 * @ Params: data as form post serialize
			 * @ Returns: Array Object
			/*************/
			getGeneralPropertiesVal: function(data) {
				try {
					var type = $('#table-general tr').attr('data-type');
					var fieldsObj = config_controls.config_fields_attributes[type];
					
					var fieldGeneralProperties = form_builder.getPropertiesVal(data);
					
					var attributesGeneral = {};
					var setAttributesGeneral = {};
					$.each(fieldGeneralProperties, function(index, attr) {
						if(attr.key == 'data-persistent') {
							if( Object.prototype.toString.call( attributesGeneral[ attr.key ] ) !== '[object Array]' ) attributesGeneral[ attr.key ] = [];
							attributesGeneral[ attr.key ][ index ] = attr.value;
						} else {
							attributesGeneral[ attr.key ] = attr.value;
						}
					});
					
					$.each(fieldsObj, function(index, item){
						//console.log(item.label);
						var attribute = item.label.toLowerCase();								
						if(attributesGeneral.hasOwnProperty(attribute)) {
							if( attribute == 'style') {
								return;
							} else if( attribute == 'data-persistent' ) {
								setAttributesGeneral[ attribute ] = attributesGeneral[ attribute ].join(',');
							} else {
								setAttributesGeneral[ attribute ] = attributesGeneral[ attribute ];
							}
						}	
					});
					
					var generalObjLength = common.len(setAttributesGeneral);
					var generalPropertiesArr = new Array();
					if(generalObjLength > 0) {
						$.each(setAttributesGeneral, function(index, item) {
							generalPropertiesArr.push({key:index, value:item});					
						});
					}

					return generalPropertiesArr;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Set general fields properties from attributes after apply action
			 * @ Params: data as form post serialize
			 * @ Returns: Array Object
			/*************/
			getPropertiesVal: function(data) {
				try {
					var propertiesArr = new Array();
					if(data.length != 0) {
						var proArr = data.split('&');					
						$.each(proArr, function(index, item) {						
							var proFieldsArr = item.split('=');
								propertiesArr.push({key:proFieldsArr[0], value:unescape(proFieldsArr[1])});						
						});
					}
					return propertiesArr;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},			
			
			/*********
			 * @ Desc: Set properties value on selected form element on form content editor
			 * @ Params: properties as object
			 * @ Returns: N/A
			/*************/
			setPropertiesVal: function(properties) {
				try {
					var datepickers = false;
					var type = $('#table-general tr').attr('data-type');
					var selId = $('#table-general tr').attr('data-id');
					var fieldsObj = config_controls.config_fields_attributes[type];
					if(type != 'editor-form') {
						if(properties.general.length > 0) {
							$.each(properties.general, function(index, item) {
								//console.log(item.key + "=======" + item.value);
								
								if(item.value != '' && item.value != undefined) {
								
									var fieldsKey = (item.key.substring(0, 5) == 'data-') ? item.key : common.filterKey(item.key);
									if(type == 'barcode') {
										if(fieldsKey == 'value') {
											var selectedObj = $('#' + selId).children(":first");
											$(selectedObj)
													.find('div')
													.remove();
											var barcodeType = $(selectedObj).attr('data-barcode-type');
											if(barcodeType == '2D') {
												$(selectedObj)
													.html(DrawCode39Barcode(common.filterValue(item.value),1));
											} else {
												var controlNo = selId.slice(3);
												$(selectedObj)
														.html('')
														.append('<div id="qrcode_' + controlNo + '"></div>');
												barcodeValue[0] = common.filterValue(item.value);
												$('#qrcode_' + controlNo + '').qrcode({
													render: 'div',
													width: 100,
													height: 100,
													color: '#000000',
													text: barcodeValue[0]
												});
											}
										}
									}
									
									if(type == 'label' || type == 'bullet') {									
										if(fieldsKey == 'label') {
											$('#' + selId)
												.children(":first")
												.html(common.filterValue(item.value));
											var lableVal = $('#' + selId).children(":first").html();
											var nameVal = $('#' + selId).children(":first").attr('name');
											var inputField = '';
											inputHiddenObj = document.createElement("input");
											inputHiddenObj.type = "hidden";
											inputHiddenObj.setAttribute("name", nameVal);
											inputHiddenObj.setAttribute("value", lableVal);
											inputField = $(inputHiddenObj)[0].outerHTML;
											$('#' + selId).children(":first").html(lableVal + inputField);
										}
									}
									
									if(type == 'textarea') {
										if(fieldsKey == 'value') {
											$('#' + selId)
												.children(":first")
												.html(common.filterValue(item.value));
										}
									}

									if(type == 'text') { 
										if(fieldsKey == 'value') {
											$('#' + selId)
												.children(":first")
												.val(common.filterValue(item.value));
										}										
										
										if(fieldsKey == 'datepicker') {
											if(item.value == "no") {
												if($('#' + selId).children(":first").hasClass('hasDatepicker')) {
													$('#' + selId)
														.children(":first")
														.removeAttr(fieldsKey)
														.datepicker( "destroy" )
														.find(".ui-datepicker-trigger")
														.remove();
												}
											} else {
												datepickers = true;
												if($('#' + selId).children(":first").hasClass('hasDatepicker')) {
													$('#' + selId)
														.find(".ui-datepicker-trigger")
														.remove();
												}
												$('#' + selId).children(":first").removeClass('hasDatepicker');
												common.applyDatePicker($('#' + selId).children(":first"));													
											}
										}
										if(!datepickers) {
											if(fieldsKey == 'datetime-picker') {
												if(item.value == "no") {
													if($('#' + selId).children(":first").hasClass('hasDatepicker')) {
														$('#' + selId)
															.children(":first")
															.removeAttr(fieldsKey)
															.datepicker( "destroy" );
													}
												} else {
													datepickers = false;
													if($('#' + selId).children(":first").hasClass('hasDatepicker')) {
														$('#' + selId)
															.find(".ui-datepicker-trigger")
															.remove();
													}
													$('#' + selId).children(":first").removeClass('hasDatepicker');
													common.applyDateTimePicker($('#' + selId).children(":first"));													
												}
											}
										}
									}
									
									if(type == 'select') {
										if(fieldsKey == 'options') {
											var selectObj = $('#' + selId).children(":first");
											$('option', selectObj).remove();
											var propertyObj = $('.add_select_options').clone();
											$('option[value=add_options]', propertyObj).remove();
											$(propertyObj).find('option').appendTo(selectObj);
										}
									}
									
									if(fieldsKey == 'class') {
										$('#' + selId)
											.children(":first")
											.addClass(common.filterValue(item.value));
									} else {
										if(item.value == "no") {
											$('#' + selId)
												.children(":first")
												.removeAttr(fieldsKey);
										} else {
											if(fieldsKey != 'pattern') {
												$('#' + selId)
													.children(":first")
													.attr(fieldsKey, common.filterValue(item.value))
													.removeAttr('pattern')
													.removeAttr('data-pattern-label');
											}
										}
									}
									
									if(fieldsKey == 'pattern') {
										if(item.value == "no") {
											$('#' + selId)
												.children(":first")
												.removeAttr(fieldsKey);
										} else {
											$('#' + selId)
												.children(":first")
												.attr(fieldsKey, item.value);
											
											var patternSelectObj = $('[id^=pattern-]');
											var patternSelectedVal = $(patternSelectObj).find('option:selected').text();
											$('#' + selId)
												.children(":first")
												.attr('data-pattern-label', patternSelectedVal);
										}											
									}
									
									if(type == 'image') {								
										if(fieldsKey == 'data-image') {
											var selectedObj = $('#' + selId).children(":first");
											$(selectedObj)
												.find('img')
												.remove();
											$(selectedObj)
												.append(form_builder.createImg(item.value, selectedObj));
										}
									}
								
								} else {
									$('#' + selId)
										.children(":first")
										.removeAttr(item.key);
								}
								
							});
						}

						if(properties.style.length > 0) {
							var styleVal = '';						
							$.each(properties.style, function(index, item) {
								//console.log(item.value + "=======" + item.key);
								
								if(item.value != '' && item.value != undefined) {
								
									if(type == 'barcode') {
										var selectedObj = $('#' + selId).children(":first");
										var barcodeType = $(selectedObj).attr('data-barcode-type');
										if(barcodeType == '2D') {
											if(item.key == 'height') {
												$('#' + selId).children(":first")
													.children()
													.children()
													.height(common.filterValue(item.value));
											}
										} else {
										
											var barcodeContainer = $(selectedObj).children();
											$(barcodeContainer).html('');
											
											switch (item.key) {
												case 'width':
													barcodeValue[1] = common.filterValue(item.value).replace('px', '');
													break;
												case 'height':
													barcodeValue[2] = common.filterValue(item.value).replace('px', '');
													break;
												case 'color':
													barcodeValue[3] = common.filterValue(item.value);
													break;
											}
											
											$(barcodeContainer).qrcode({
												render: 'div',
												width: (barcodeValue[1] != '' && barcodeValue[1] != undefined) ? barcodeValue[1] : 100,
												height: (barcodeValue[2] != '' && barcodeValue[2] != undefined) ? barcodeValue[2] : 100,
												color: (barcodeValue[3] != '' && barcodeValue[3] != undefined) ? barcodeValue[3] : '#000000',
												text: barcodeValue[0]
											});
										}									
									}								
									
									$('#' + selId)
										.children(":first")
										.removeAttr(item.key);
										
									if(item.value != "no") {
										styleVal += item.key + ':' + common.filterValue(item.value) + ';';
									}
									
									$('#' + selId)
										.children(":first")
										.attr('style', styleVal);
									
									if(type == 'image') {								
										var selectedObj = $('#' + selId).children(":first");										
										$(selectedObj).css('height', $(selectedObj).find('img').height());
										$(selectedObj).css('width', $(selectedObj).find('img').width());
									}
									
									// || type == 'inking-overlay'
									if(type == 'simple-signature') {								
										var selectedObj = $('#' + selId).children(":first");
										switch (item.key) {
											case 'width':
												$(selectedObj).find('canvas').attr('width', (common.filterValue(item.value).replace('px', '') - 2));
												$(selectedObj).find('.sigPad').width(common.filterValue(item.value));
												$(selectedObj).find('.sigNav').width(common.filterValue(item.value));
												break;
											case 'height':
												$(selectedObj).find('canvas').attr('height', common.filterValue(item.value).replace('px', ''));
												$(selectedObj).find('.sigWrapper').height(common.filterValue(item.value));
												break;
										}
									}
								
								}
							});
						} else {
							$('#' + selId)
								.children(":first")
								.removeAttr('style');
						}
						
					} else {
						if(properties.general.length > 0) {
							$.each(properties.general, function(index, item) {
								var fieldsKey = (item.key.substring(0, 5) == 'data-') ? item.key : common.filterKey(item.key);
								if(item.value != '' && item.value != undefined) {
									if(fieldsKey == 'class') {
										$('#' + selId).addClass(common.filterValue(item.value));
									} else {
										if(item.value == "no") {
											$('#' + selId).removeAttr(fieldsKey);
										} else {
											if(fieldsKey != 'pattern') {
												$('#' + selId).attr(fieldsKey, common.filterValue(item.value));
											}
										}
									}								
								}								
							});
						}

						if(properties.style.length > 0) {
							var styleVal = '';						
							$.each(properties.style, function(index, item) {
								if(item.value != '' && item.value != undefined) {
									if(item.key == 'font-family') {
										form_builder.editorFormFont = item.value
									}
									$('#' + selId).removeAttr(item.key);
									styleVal += item.key + ':' + common.filterValue(item.value) + ';';
									$('#' + selId).attr('style', styleVal);
								}
							});
						} else {
							$('#' + selId).removeAttr('style');
						}
						
						//Set ruler
						common.resetRuler();
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}					
			},
			
			createImg: function(value, selObj) {
				try {
					if(value != 'no' && value != 'choose_files') {
					
						var boxHeight = $(selObj).height();
						var boxWidth = $(selObj).width();
						var newImg = new Image();
						newImg.src = baseUrl + '/images/upload/' + value + '';
						var p = new Array();
						p = $(newImg).ready(function(){
							return {width: newImg.width, height: newImg.height};
						});
						
						if(p[0]['width'] == 0 && p[0]['height'] == 0) {
							setTimeout(function(){
								p = $(newImg).ready(function(){
									return {width: newImg.width, height: newImg.height};
								});
							}, 0);
								
						}
						
						var imageOriginalWidth = (p[0]['width'] != 0) ? p[0]['width'] : boxWidth;
						var imageOriginalHeight = (p[0]['height'] != 0) ? p[0]['height'] : boxHeight;
						
						var maxWidth = boxWidth;
						var maxHeight = boxHeight;
						var ratio = 0;
						var width = imageOriginalWidth;
						var height = imageOriginalHeight;

						// Check if the current width is larger than the max
						if(width > maxWidth){
							ratio = maxWidth / width;
							height = height * ratio;
							width = maxWidth;
						}
						
						// Check if current height is larger than max
						if(height > maxHeight){
							ratio = maxHeight / height;
							width = width * ratio;
							height = maxHeight;
						}			
						
						return '<img alt="' + value + '" src="' + baseUrl + '/images/upload/' + value + '" class="selected_image" height="' + height + '" width="' + width + '" />';
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Set style properties value on selected form element on form content editor
			 * @ Params: data as serialize form post object
			 * @ Returns: N/A
			/*************/
			getStylePropertiesVal: function(data) {
				try {
					var type = $('#table-general tr').attr('data-type');
					var fieldsObj = config_controls.config_fields_attributes[type];
					
					var fieldStyleProperties = form_builder.getPropertiesVal(data);
					
					var attributesStyle = {};
					var setAttributesStyle = {};
					$.each(fieldStyleProperties, function(index, attr) {
						attributesStyle[ attr.key ] = attr.value;
					});
					
					var stylePropertiesArr = new Array();
					if(fieldsObj.style != undefined) {
						$.each(fieldsObj.style.value, function(index, item){
							//console.log(item.label);
							var attribute = item.label.toLowerCase();								
							if(attributesStyle.hasOwnProperty(attribute)) {
								setAttributesStyle[ attribute ] = attributesStyle[ attribute ];
							}	
						});

						var styleObj = common.len(setAttributesStyle);						
						if(styleObj > 0) {
							$.each(setAttributesStyle, function(index, item) {
								stylePropertiesArr.push({key:index, value:item});					
							});
						}
					}
					
					return stylePropertiesArr;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Extract style properties value.
			 * @ Params: properties of style attribues value as object
			 * @ Returns: Array Object
			/*************/
			extractStyleProperties: function(properties) {
				try {
					var stylePropertiesArr = new Array();
					if(properties != '') {
						var proArr = $.trim(properties).split(';');
						$.each(proArr, function(index, item) {
							var proStyleArr = common.filterSpaceTrim(item).split(':');
							if(proStyleArr[1] == '' || proStyleArr[0] == '') {							
							} else {
								stylePropertiesArr.push({key:proStyleArr[0], value:proStyleArr[1]});
							}						
						});
					}
					return stylePropertiesArr;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},				
			
			/*********
			 * @ Desc: Render the response on dialog box pop up after save.
			 * @ Params: Object
			 * @ Returns: N/A
			/*************/
			savedFormData: function(data) {
				try {
					console.log(data);
					if(data === 0 && data !== null) {
						$('.ui-dialog-title').html('Exists!');
						$('#dialog-modal')
							.html('<div id="information" class="alert alert-error errormsg error cb">Form was not Successfully Saved. This is already Exists!</div><center><input type="button" class="btn dialog_close" value="Ok" align="center"></center>');
					} else if(data && data != null && data != 'exists') {
						$('.ui-dialog-title').html('Saved!');
						$('#dialog-modal')
							.html('<div id="information" class="alert alert-success errormsg error cb">Form was Successfully Saved!</div><center><input type="button" class="btn dialog_close" value="Ok" align="center"></center>');
						$('#update_form_id').val(data);
						$('#form_template_name')
							.prop('readonly', true);
						
						//get the list of the activity log in edit mode.						
						if(data != undefined && data != "") {
							templateObj = new Template();
							templateObj.setValue('template_id', data);
							templateObj.setValue('async', Template.async);
							templateObj.setValue('target', 'activity_log');
							templateObj.getActivityLog();
						}
						
					} else {
						$('.ui-dialog-title').html('Not Saved!');
						$('#dialog-modal')
							.html('<div id="information" class="alert alert-error errormsg error cb">Form was not Successfully Saved. This is under construction!!!</div><center><input type="button" class="btn dialog_close" value="Ok" align="center"></center>');
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Show dialog box pop up of form list.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			showListDialog: function(dataTemplate) {
				try {
					$("#tabs").tabs({ active: 1 });
					$("#dialog-modal")
						.find('#information')
						.remove();
					$("#dialog-modal")
						.find('#save_loc')
						.remove();
					$( "#form_dialog_modal" ).dialog({					 
						width: 750,
						height: (dataTemplate == 'regular') ? 350 : 450,
						draggable: false,
						title: (dataTemplate == 'regular') ? "Open Form List" : "Draft From List",
						open: function(event, ui) {
							$('.show-library-data').attr('data-template', dataTemplate);
							form_builder.getSavedForm('centrally', dataTemplate);
						}
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},				
			
			/*********
			 * @ Desc: Get the list of form via ajax request.
			 * @ Params: library type
			 * @ Returns: N/A
			/*************/
			getSavedForm: function(type, dataTemplate) {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('library_type', type);
					templateObj.setValue('data_template', dataTemplate);
					templateObj.setValue('target', 'show_form');								
					templateObj.show();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Delete the form via ajax request.
			 * @ Params: form id, library type
			 * @ Returns: N/A
			/*************/
			deleteForm: function(formId, type, dataTemplate) {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('library_type', type);
					templateObj.setValue('form_id', formId);
					templateObj.setValue('data_template', dataTemplate);
					templateObj.setValue('target', 'delete_form');								
					templateObj.deleteTemplate();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Delete the form via ajax request.
			 * @ Params: form id, library type
			 * @ Returns: N/A
			/*************/
			publishTemplate: function(formId, type, dataTemplate) {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('library_type', type);
					templateObj.setValue('form_id', formId);
					templateObj.setValue('data_template', dataTemplate);
					templateObj.setValue('target', 'publish_template');								
					templateObj.publishTemplate();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},

			/*********
			 * @ Desc: Get the template form with value via ajax request.
			 * @ Params: form id, library type
			 * @ Returns: N/A
			/*************/
			getTemplateForm: function(formId, type) {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('library_type', type);
					templateObj.setValue('form_id', formId);
					templateObj.setValue('target', 'show_template_form');								
					templateObj.getTemplateForm();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the template form with value via ajax request.
			 * @ Params: form id, library type
			 * @ Returns: N/A
			/*************/
			deleteUploadedImage: function(Obj) {
				try {
					var templateObj = new Template();
					templateObj.setValue('id', $(Obj).attr('data-id'));
					templateObj.setValue('target', 'delete_image');								
					templateObj.deleteUploadedImage();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: reset the image list after deleting the records
			 * @ Params: success data, params type
			 * @ Returns: N/A
			/*************/
			resetImageList: function(data, params) {
				try {
					var imageId = '';
					if(data.hasOwnProperty('template_image')) {
						imageId = data.template_image.id;
					} else {
						imageId = data.id;
					}

					$('#image-list-box-table').find('tr[id=imagelist_' + imageId + ']').hide("slow", function() {
						$(this).remove();
					});
					form_builder.getImages();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: render form list again after get the form content with actual value record.
			 * @ Params: success data, params type
			 * @ Returns: N/A
			/*************/
			renderTemplateForm: function(data, params) {
				try {
					var templateId = data.template_id;
					var rowContent = data.content;
					//console.log(rowContent);
					
					var rowName = $('#form_name_' + templateId).html();
					
					$('.form-template-name').html(rowName);
					$('#form_template_name')
						.prop('readonly', true)
						.val(rowName);
					
					$('#update_form_id').val(templateId);					
					$('#template_form_value').val(1);					
					$('ul#list').html(rowContent);
					$('#form_dialog_modal')
						.dialog( "close" );
					
					$('ul#list').each(function() {
						var totalFields = $(this).find('div.form-row').length;
						$('#fields_count').val(totalFields);
					});
					
					var elementHeight = {};
					$('ul#list div.form-row').each(function(index) {
						var liId = $(this).attr('id');
						$('#' + liId).draggable({containment: 'parent'});
						$('#' + liId).find('.ui-resizable').resizable({
							minHeight: 1,
							minWidth: 1,
							maxHeight: $('ul#list').height(),
							maxWidth: $('ul#list').width(),
							resize: function( event, ui ) {
								if($('#update_form_id').val() != undefined && $('#update_form_id').val() != "") {
									common.captureChangesInEditor(event, ui, this);
								}
							}
						});
						var options = {
							bgColor : '#ffffff'
						};
						$('.sigPad').signaturePad(options);	
						$('#' + liId).auderoContextMenu("context-menu");
						
						var controlsElementObj = $(this).children(':first');
						
						if($(controlsElementObj).hasClass('datepicker') || $(controlsElementObj).attr('datepicker') == 'datepicker') {
							if($(controlsElementObj).hasClass('hasDatepicker')) {
								$('#' + liId)
									.find(".ui-datepicker-trigger")
									.remove();
							}
							$(controlsElementObj).removeClass('hasDatepicker');
							common.applyDatePicker(controlsElementObj);
						}
						if($(controlsElementObj).hasClass('datetimepicker') || $(controlsElementObj).attr('datetime-picker') == 'datetimepicker') {
							if($(controlsElementObj).hasClass('hasDatepicker')) {
								$('#' + liId)
									.find(".ui-datepicker-trigger")
									.remove();
							}
							$(controlsElementObj).removeClass('hasDatepicker');
							common.applyDateTimePicker(controlsElementObj);	
						}
						
						$('#fields_count').val(liId.slice(3));
						elementHeight[ parseInt($('#' + liId).css('top'), 10) ] = index;
					});
					
					var maxHeight = common.maxKey(elementHeight);

					//$('ul#list').css(
					//	'height', (maxHeight < 355) ? 395 : maxHeight + 40
					//);				
					
					
					//Set Ruler
					common.resetRuler();
					form_builder.resetDocument();
					
					//Set selected template library
					$('#locations')
						.find("option")
						.removeAttr("selected","selected");
					$('#locations')
						.find("option[value='" + rowTypeId +"']")
						.prop("selected","selected");
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: render form list again after delete record.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			resetFormList: function(data, params) {
				try {
					form_builder.getSavedForm(params['data']['library_type'], params['data']['data_template']);
					$('.form-template-name').html('Untitled Form');
					$('#form_template_name')
						.removeAttr('readonly')
						.val('');
				} catch (e) {
				   console.log(e.message, e.name);
				}						
			},
			
			/*********
			 * @ Desc: Render the list of form into dialog box.
			 * @ Params: data
			 * @ Returns: N/A
			/*************/
			renderFormList: function(data, type) {
				try {
					$('#tabs-' + type).html(data);
					$('.delete-template').attr('data-type', type);
					$('.edit-form').attr('data-type', type);
					$('.publish-template').attr('data-type', type);
					$('.library_type').val(type);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Render the form content into form editor.
			 * @ Params: Object of row of form list
			 * @ Returns: N/A
			/*************/
			renderFormContent: function(Obj) {
				try {
					var rowId = $(Obj).attr('data-id');
					var rowTypeId = $(Obj).attr('data-typeid');
					
					templateObj = new Template();
					templateObj.setValue('template_id', rowId);
					templateObj.setValue('async', Template.async);
					templateObj.setValue('target', 'activity_log');
					templateObj.getActivityLog();
					
					var rowContent = $('#content_' + rowId).html();
					var rowName = $('#form_name_' + rowId).html();
					//console.log(rowContent);
					
					$('.form-template-name').html(rowName);
					$('#form_template_name')
						.prop('readonly', true)
						.val(rowName);
					$('#update_form_id').val(rowId);
					$('#template_form_value').val(0);
					$('ul#list').html(rowContent);
					$('#form_dialog_modal')
						.dialog( "close" );
					
					var previewUrl = $(Obj).find('.preview-template').attr('href');
					$('.preview_button_box')
						.removeClass('hide')
						.find('a')
						.attr('href', previewUrl);
					
					$('ul#list').each(function() {
						var totalFields = $(this).find('div.form-row').length;
						$('#fields_count').val(totalFields);
					});
					
					var elementHeight = {};
					$('ul#list div.form-row').each(function(index) {
						var liId = $(this).attr('id');
						$('#' + liId).draggable({containment: 'parent'});
						$('#' + liId).find('.ui-resizable').resizable({
							minHeight: 1,
							minWidth: 1,
							maxHeight: $('ul#list').height(),
							maxWidth: $('ul#list').width(),
							resize: function( event, ui ) {
								if($('#update_form_id').val() != undefined && $('#update_form_id').val() != "") {
									common.captureChangesInEditor(event, ui, this);
								}
							}
						});
						var options = {
							bgColor : '#ffffff'
						};
						$('.sigPad').signaturePad(options);	
						$('#' + liId).auderoContextMenu("context-menu");
						
						var controlsElementObj = $(this).children(':first');
						
						if($(controlsElementObj).hasClass('datepicker') || $(controlsElementObj).attr('datepicker') == 'datepicker') {
							if($(controlsElementObj).hasClass('hasDatepicker')) {
								$('#' + liId)
									.find(".ui-datepicker-trigger")
									.remove();
							}
							$(controlsElementObj).removeClass('hasDatepicker');
							common.applyDatePicker(controlsElementObj);
						}
						if($(controlsElementObj).hasClass('datetimepicker') || $(controlsElementObj).attr('datetime-picker') == 'datetimepicker') {
							if($(controlsElementObj).hasClass('hasDatepicker')) {
								$('#' + liId)
									.find(".ui-datepicker-trigger")
									.remove();
							}
							$(controlsElementObj).removeClass('hasDatepicker');
							common.applyDateTimePicker(controlsElementObj);	
						}							
						$('#fields_count').val(liId.slice(3));
						elementHeight[ parseInt($('#' + liId).css('top'), 10) ] = index;
					});
					
					var maxHeight = common.maxKey(elementHeight);
					
					//$('ul#list').css(
					//	'height', (maxHeight < 355) ? 395 : maxHeight + 40
					//);				
					
					
					//Set Ruler
					common.resetRuler();
					form_builder.resetDocument();
					
					//Set selected template library
					$('#locations')
						.find("option")
						.removeAttr("selected","selected");
					$('#locations')
						.find("option[value='" + rowTypeId +"']")
						.prop("selected","selected");
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Reset the template editor after rendering the data
			 * @ Params: Object of row of form list
			 * @ Returns: N/A
			/*************/
			resetDocument: function() {
				try {
					$('ul#list div.form-row').each(function(index) {
						var liId = $(this).attr('id');
						var inputElement = $('#' + liId).children(':first');
						var type = common.getTagName(inputElement);
						if(type == 'submit') {
							$('ul#list').css(
								'width', $(inputElement).attr('data-form-width')
							);
							$('ul#list').css(
								'height', $(inputElement).attr('data-form-height')
							);
						}
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Show dialog box for adding select option list
			 * @ Params: Object of row of form list
			 * @ Returns: N/A
			/*************/
			showOptionDialog: function(Obj) {
				try {
					$( "#dialog-modal" ).dialog({					 
						width: 600,
						height: 'auto',
						draggable: false,
						title: "Add Option list",
						open: function(event, ui) {							
							form_builder.setSelectOptions(Obj);
						}
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},			
			
			/*********
			 * @ Desc: Set the option list of select drop down
			 * @ Params: Object of select drop down element
			 * @ Returns: N/A
			/*************/
			setSelectOptions: function(Obj) {
				try {
					//console.log(Obj);
					var dialogBoxHtml = $('#add-options-box').html();					
					$('#dialog-modal').html(dialogBoxHtml);
					var selectID = $(Obj).attr('id');
					$('.select_options_done').attr('data-select', selectID);
					var optionLength = 0;
					$('.options-list-place').each(function(){
						optionLength = $(this).find('p.options-list').length;
					});
					
					this.parseOptions(Obj);
					
					/*if(optionLength <= 0)
						this.createOption();*/
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Show input box for custom pattern
			 * @ Params: Object of row of form list
			 * @ Returns: N/A
			/*************/
			setCustomPattern: function(Obj) {
				try {
					$( "#add-pattern-modal" ).dialog({					 
						width: 600,
						height: 'auto',
						draggable: false,
						title: "Add Custom Pattern",
						close: form_builder.closePatternDialog,
						open: function(event, ui) {							
							var selectID = $(Obj).attr('id');
							$('.select_pattern_done').attr('data-select', selectID);
						}
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Create Option list
			 * @ Params: Object of select drop down element
			 * @ Returns: N/A
			/*************/
			setOptionList: function(Obj) {
				try {
					this.createOption();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Create Option val and label
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			createOption: function() {
				try {
					var count = $('.add_select_options').attr('data-option');
					count++;
					var optionObj = $('#add-options').clone();
					optionObj.children().attr("id", "option_" + count);
					optionObj.children().find('input[data-type=label]')
						.attr("id", 'select_options_label_' + count)
						.attr("name", 'select_options_label_' + count);
					optionObj.children().find('input[data-type=value]')
						.attr("id", 'select_options_value_' + count)
						.attr("name", 'select_options_value_' + count);
					optionObj.children().find('.removeOption')
						.attr("class", 'remove-option_select removeOption');
					childrenOptionObj = optionObj.children();
					$('.options-list-place').append(childrenOptionObj);
					$('#add-options-box div.options-list-place').html('');
					$('.add_select_options').attr('data-option', count);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Parse the Option list val and label
			 * @ Params: Object of select drop down
			 * @ Returns: N/A
			/*************/
			parseOptions: function(Obj) {
				try {
					var count = $('.add_select_options').attr('data-option');
					$(Obj).find('option').each(function() {
					
						var optionVal = $(this).val();
						var optionLabel = $(this).text();
						var optionObj = $('#add-options').clone();
						//console.log(optionVal);
						if(optionVal != 'no' && optionVal != 'add_options') {
							count++;							
							optionObj.children().attr("id", "option_" + count);
							optionObj.children().find('input[data-type=label]')
								.attr("id", 'select_options_label_' + count)
								.attr("name", 'select_options_label_' + count)
								.attr("value", optionLabel);
							optionObj.children().find('input[data-type=value]')
								.attr("id", 'select_options_value_' + count)
								.attr("name", 'select_options_value_' + count)
								.attr("value", optionVal);
							optionObj.children().find('.removeOption')
								.attr("class", 'remove-option_select removeOption');
							childrenOptionObj = optionObj.children();
							$('.options-list-place').append(childrenOptionObj);	
							$('#add-options-box div.options-list-place').html('');
							$('.add_select_options').attr('data-option', count);
						}						
					});	
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Show dialog box for selecting image from list.
			 * @ Params: Object of row of form list
			 * @ Returns: N/A
			/*************/
			showImageUploadDialog: function(Obj) {
				try {
					form_builder.renderImageListBox();
					$( "#file-upload-modal" ).dialog({					 
						width: 600,
						height: 'auto',
						draggable: false,
						title: "Select Image from list",
						close: form_builder.closeImageDialog,
						open: function(event, ui) {
							var selectID = $(Obj).attr('id');
							$('.select_image_done').attr('data-select', selectID);
							if($(Obj).attr('data-image') != '') {
								$('#image-list-box-table input[type=radio]').each(function(){
									if($(this).val() != '') {
										if($(this).val() == $(Obj).attr('data-image')){
											$(this).prop('checked', true);
										}
									}
								});
							}
						}
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Render the list of the template images into pop up box
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			renderImageListBox: function() {
				try {
					//console.log(dataImages.length);
					$('#status').text('');
					$("#image-list-box-table tbody").each(function() {
						$(this).find('tr:gt(0)').remove();
					});
					if(dataImages.length > 0) {
						$.each(dataImages, function(index, item) {
						
							var imgCloneObj = $('#image_list_row').clone();
							var imgRowObj = $(imgCloneObj).children().find('tr');
							var imageId = ""; 
							var imageName = "";
							if(item.hasOwnProperty('template_image')) {
								imageId = item.template_image.id;
								imageName = item.template_image.image_name;
							} else {
								imageId = item.id;
								imageName = item.image_name;
							}
							
							$(imgCloneObj).find('#imagelist_').attr("id", "imagelist_" + imageId);
							$(imgRowObj).find('#radio_select_')
								.attr("id", "radio_select_" + imageId);
							$(imgRowObj).find('input[type="radio"]')
								.attr("value", imageName);
							$(imgRowObj).find('#img_name_')
								.attr("id", "img_name_" + imageId)
								.html(imageName);
							$(imgRowObj).find('#img_preview_')
								.attr("id", "img_preview_" + imageId)
								.html('<img src="' + baseUrl +'/images/upload/' + imageName + '" alt="" width="60" />');
							$(imgRowObj).find('#img_status_')
								.attr("id", "img_status_" + imageId)
								.html('Active');
							$(imgRowObj).find('#img_action_')
								.attr("id", "img_action_" + imageId)
							$(imgRowObj).find('#delete_image')
								.attr("data-id", imageId);
							
							$('#image-list-box-table').append(imgRowObj);
						});
					} else {
						$('#image-list-box-table').append('<tr id="no-image-items"><td colspan="5">No image listed here!.</td></tr>');
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Perform action to select image into drop down field
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			closeImageDialog: function() {
				try {
					var imageVal = $('[id^=data-image-]').attr('data-image');
					var dataImageObj = $('[id^=data-image-]');
					$(dataImageObj).val(imageVal);
					form_builder.getImages();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			
			/*********
			 * @ Desc: Perform action to select pattern into drop down field
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			closePatternDialog: function() {
				try {
					var patternVal = $('[id^=pattern-]').attr('data-pattern');
					var dataPatternObj = $('[id^=pattern-]');
					patternVal = patternVal.replace(/\\/g, '\\\\');
					$(dataPatternObj).find("option[value='" + patternVal + "']").attr("selected","selected");	
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Define different types of attributes of form element
			 * @ Params: N/A
			 * @ Returns: Array
			/*************/
			definedAttrs: function() {
				try {
					return new Array('id','name','class','width','pattern','length','height','style',
							'max','min','rows','cols','data-obj','data-type','data-css','data-num',
							'for','title','src','href','checked','selected','value','required','placeholder',
							'type','method','action','data-action','data-params','data-target','data-replace');
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the field types of draggable tools
			 * @ Params: draggable object
			 * @ Returns: String
			/*************/
			fieldType: function(ui) {
				try {
					var fieldType = ui.draggable.attr('data-type');
					return fieldType;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the html of the cross box content
			 * @ Params: N/A
			 * @ Returns: HTML
			/*************/
			crossButton: function() {
				try {
					var cbox = $('#close-box').html();
					return cbox;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Set the style propeties on ui draggable object
			 * @ Params: draggable object and count
			 * @ Returns: N/A
			/*************/
			customDrag: function(ui, count, Obj) {
				try {					
					var newPosX = ui.offset.left - $(Obj).offset().left;
					var newPosY = ui.offset.top - $(Obj).offset().top;
					$('#id_' + count).css('top', newPosY);
					$('#id_' + count).css('left', newPosX);
					$('#id_' + count).css('position', 'absolute');
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Add new fields on form content editor if object drop in it.
			 * @ Params: draggable object and draged Object
			 * @ Returns: N/A
			/*************/
			addFields: function(ui, Obj) {
				try {
					var fieldType = this.fieldType(ui);
					if(fieldType !='' && fieldType != null && fieldType != undefined) {
						var rowCount = $('#fields_count').val();
						rowCount++; 					
						fieldType = fieldType.slice(8);					
						dropHtml = this.FormFields().fields_render(rowCount, fieldType);
						$(Obj).append( dropHtml );
						var elementIdObj = $('#id_' + rowCount);
						$(elementIdObj).draggable({containment: 'parent'});
						if(fieldType == 'div-block' 
							|| fieldType == 'line' 
							|| fieldType == 'image' 
							|| fieldType == 'group') {
							$(elementIdObj).children(':first').resizable({
								minHeight: 1,
								minWidth: 1,
								maxHeight: $(Obj).height(),
								maxWidth: $(Obj).width(),
								resize: function( event, ui ) {
									if($('#update_form_id').val() != undefined && $('#update_form_id').val() != "") {
										common.captureChangesInEditor(event, ui, this);
									}
								}
							});
						}
						
						if(fieldType == 'simple-signature') {
							var options = {
							  bgColour : '#ffffff'
							};
							$('.sigPad').signaturePad(options);
							
						} else if(fieldType == 'inking-overlay') {
							
							var options = {
								lineColour : '#ffffff',
								bgColour : '#ffffff'
							};
							$('.sigPad').signaturePad(options);
						}
						
						if(fieldType == 'date-picker') {
							$(elementIdObj).children(':first').removeClass('hasDatepicker');
							common.applyDatePicker($(elementIdObj).children(':first'));
						}
						
						if(fieldType == 'date-time-picker') {
							$('#id_' + rowCount).children(':first').removeClass('hasDatepicker');
							common.applyDateTimePicker($('#id_' + rowCount).children(':first'));
						}
						
						this.customDrag(ui, rowCount, Obj);
						$(elementIdObj).auderoContextMenu("context-menu");
						$('#fields_count').val(rowCount);
						
						return elementIdObj;
					} else {
						return false;
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the list of persistent via ajax request.
			 * @ Params: id of select dropdown, selected value and object of select drop down
			 * @ Returns: N/A
			/*************/
			getPersistencePattern: function(id, attributeVal, selObj) {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('id', '');
					templateObj.setValue('select_id', id);
					templateObj.setValue('attribute_val', attributeVal);
					templateObj.setValue('target', 'persistence');								
					templateObj.getPersistent();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Render the persistent pattern into drop down
			 * @ Params: data via ajax request and parameters passed into ajax
			 * @ Returns: N/A
			/*************/
			renderPersistencePattern: function(data, params) {
				try {
					optionObj = $('#' + params['select_id']);
					
					$('option[value!=no]', optionObj).remove();
					
					$.each(data, function(index, item) {
						$(optionObj).append(new Option(item.template_persistent.label, item.template_persistent.id));
						$(optionObj).find("option[value='" + params['attribute_val'] +"']").attr("selected","selected");
					});		
					
					$(optionObj)[0].outerHTML;
					$(optionObj).removeClass('ajax-dropdown-loading');
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Render the persistent pattern into drop down
			 * @ Params: data via ajax request and parameters passed into ajax
			 * @ Returns: N/A
			/*************/
			assignPersistence: function(data, params) {
				try {
					dataPersistant = Template.persistentsArray;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Render the data event into drop down
			 * @ Params: data via ajax request and parameters passed into ajax
			 * @ Returns: N/A
			/*************/
			assignEvents: function(data, params) {
				try {
					dataEvent = Template.eventsArray;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Render the image list
			 * @ Params: data via ajax request and parameters passed into ajax
			 * @ Returns: N/A
			/*************/
			assignImageList: function(data, params) {
				try {
					dataImages = Template.imagesArray;
					form_builder.renderImageListBox();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the list of user repository locations via ajax request.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			getLocations: function() {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('target', 'locations');								
					templateObj.getLocations();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the list of user repository locations via ajax request.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			getPersistent: function() {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('target', 'persistence');								
					templateObj.getPersistents();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the list of template events via ajax request.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			getEvents: function() {
				try {
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('target', 'template_event');								
					templateObj.getEvents();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Get the list of template images via ajax request.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			getImages: function() {
				try {
					var templateObj = new Template();
					templateObj.setValue('target', 'template_image');								
					templateObj.getImages();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},

			/*********
			 * @ Desc: Render the user locations into drop down
			 * @ Params: data via ajax request and parameters passed into ajax
			 * @ Returns: N/A
			/*************/
			renderLocations: function(data, params) {
				try {						
					optionObj = $("#locations");
					attributesValue = '';
					$(optionObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
					
					if(Template.locationsArray.length > 0) {
						$.each(Template.locationsArray, function(index, item) {
							if(item.hasOwnProperty('template_library')) {
								var o = new Option(item.template_library.name, item.template_library.id);
								//$(o).attr('data-url', item.template_library.url);
								$(o).html(item.template_library.name);
							} else {
								var o = new Option(item.name, item.id);
								//$(o).attr('data-url', item.url);
								$(o).html(item.name);
							}
							$(optionObj).append(o);
							$(optionObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
						});
					}
					$(optionObj).removeClass('ajax-dropdown-loading');
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},

			/*********
			 * @ Desc: Render the activity log into the log box
			 * @ Params: data via ajax request and parameters passed into ajax
			 * @ Returns: N/A
			/*************/
			renderAcitivityLog: function(data, params) {
				try {
					if(data != null && common.len(data) > 0) {						
						var logId = "";
						if(data.hasOwnProperty('template_activity_log')) {
							activityControlsLog = JSON.parse(data.template_activity_log.activity_log)[0];
							logId = data.template_activity_log.id;
						} else {
							activityControlsLog = JSON.parse(data.activity_log)[0];
							logId = data.id;
						}
						$('.view_all_activity')
							.removeClass('hide')
							.find('a')
							.attr('href', 'view_activity_log.html#id=' + logId);
						common.setActivityLog(activityControlsLog);
					} else {
						delete activityControlsLog;
						activityControlsLog = {};
						$('#activity_log_content').html( 						
							$('#default_activity_log')
								.clone()
								.removeAttr('id')
						);
						$('.view_all_activity').addClass('hide');
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},			

			/*********
			 * @ Desc: Create the clone of tools element and Make new html of control
			 * @ Params: N/A
			 * @ Returns: Object
			/*************/
			FormFields : function() {
				try {
					return {
					
						'fields_render' : function(count, type){
							
							var cloneObj = $('#' + type).clone();
							cloneObj.children().attr("id", "id_" + count);
							cloneObj.children().children(':first').attr("id", type + "_" + count);
							cloneObj.children().children(':first').attr("name", type + "_" + count);
							childrenObj = cloneObj.children();
							
							return childrenObj;
						}				
						
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},				
			
			/*********
			 * @ Desc: Get the properties of element and Render the full properties of selected element on right side window. 
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			formPropertiesFields : function() {
				try {
					return {
					
						'properties_render' : function(fieldObj, selObj, type){
							//console.log($(selObj));
							//console.log(type);
							if(type == 'editor-form')
								parentId = $(selObj).attr('id');
							else
								parentId = $(selObj).parent().attr('id');
								
							var properties = '';
							var i = 0;
							
							var attributes = {}; 

							$.each(selObj.attributes, function(index, attr) {
								attributes[ attr.name ] = attr.value;
							});
							
							if(common.len(attributes) > 0) {
								//console.log(fieldObj);
								//console.log(attributes);							
							}							
							
							$.each(fieldObj, function(index, value) {
								var attribute = (value.label.toLowerCase().substring(0, 5) == 'data-') 
												? value.label.toLowerCase()
												: common.filterKey(value.label.toLowerCase());
												
								var inputField = '';
								
								var attributesValue = '';								
								if(attributes.hasOwnProperty(attribute)) {
									//console.log(attribute);
									attributesValue = attributes[attribute];										
								} else {								
									attributesValue = value.value;									
								}
								
								var errorClass = '';
								switch(attribute) {
									case 'id':
										errorClass = ' id-check-validation';
									break;
									case 'name':
										errorClass = ' name-check-validation';
									break;
									case 'autosuggest':
										errorClass = ' autosuggest-check-validation';
									break;
									case 'datetime-picker':
										errorClass = ' datetime-picker-check-validation';
									break;
									case 'datepicker':
										errorClass = ' datepicker-check-validation';
									break;
								}
								
								if(type == 'editor-form') {									
									if(attribute == 'id') {
										inputObj = document.createElement("input");
										inputObj.type = "text";
										inputObj.setAttribute("name", value.label.toLowerCase());
										inputObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										inputObj.setAttribute("class", "properties_val");
										inputObj.setAttribute("readonly", true);
										inputObj.setAttribute("value", attributesValue);
										
										inputField = $(inputObj)[0].outerHTML;
									} else {
										inputObj = document.createElement("input");
										inputObj.type = "text";
										inputObj.setAttribute("name", value.label.toLowerCase());
										inputObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										inputObj.setAttribute("class", "properties_val" + errorClass);
										inputObj.setAttribute("value", attributesValue);
										
										inputField = $(inputObj)[0].outerHTML;
									}
								} else {
									inputObj = document.createElement("input");
									inputObj.type = "text";
									inputObj.setAttribute("name", value.label.toLowerCase());
									inputObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
									inputObj.setAttribute("class", "properties_val" + errorClass);
									inputObj.setAttribute("value", attributesValue);
									
									inputField = $(inputObj)[0].outerHTML;
								}
								
								switch(attribute) {
									case 'readonly':
										readonlyObj = document.createElement("select");
										readonlyObj.setAttribute("name", value.label.toLowerCase());
										readonlyObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										readonlyObj.setAttribute("class", "properties_val");
										
										//add readonly option by default										
										o = new Option('No', 'no');
										$(o).html('No');
										$(readonlyObj).append(o);										
										o = new Option('Yes', 'readonly');
										$(o).html('Yes');
										$(readonlyObj).append(o);
										
										$(readonlyObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
										inputField = $(readonlyObj)[0].outerHTML;
									break;
									case 'autocomplete':
										autocompleteObj = document.createElement("select");
										autocompleteObj.setAttribute("name", value.label.toLowerCase());
										autocompleteObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										autocompleteObj.setAttribute("class", "properties_val");
											
										//add autocomplete option by default										
										o = new Option('Off', 'off');
										$(o).html('Off');
										$(autocompleteObj).append(o);										
										o = new Option('On', 'on');
										$(o).html('On');
										$(autocompleteObj).append(o);
										
										$(autocompleteObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
										inputField = $(autocompleteObj)[0].outerHTML;
									break;
									case 'required':
										requiredObj = document.createElement("select");
										requiredObj.setAttribute("name", value.label.toLowerCase());
										requiredObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										requiredObj.setAttribute("class", "properties_val");
											
										//add required option by default
										o = new Option('No', 'no');
										$(o).html('No');
										$(requiredObj).append(o);
										o = new Option('Yes', 'required');
										$(o).html('Yes');
										$(requiredObj).append(o);
										
										$(requiredObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
										inputField = $(requiredObj)[0].outerHTML;
									break;
									case 'disabled':
										disabledObj = document.createElement("select");
										disabledObj.setAttribute("name", value.label.toLowerCase());
										disabledObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										disabledObj.setAttribute("class", "properties_val");
										
										//add disabled option by default
										o = new Option('No', 'no');
										$(o).html('No');
										$(disabledObj).append(o);
										o = new Option('Yes', 'disabled');
										$(o).html('Yes');
										$(disabledObj).append(o);
										
										$(disabledObj).find("option[value='" + attributesValue +"']").attr("selected","selected");	
										inputField = $(disabledObj)[0].outerHTML;
									break;
									case 'multiple':
										multipleObj = document.createElement("select");
										multipleObj.setAttribute("name", value.label.toLowerCase());
										multipleObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										multipleObj.setAttribute("class", "properties_val");
											
										//add required option by default
										o = new Option('No', 'no');
										$(o).html('No');
										$(multipleObj).append(o);
										o = new Option('Yes', 'multiple');
										$(o).html('Yes');
										$(multipleObj).append(o);
										
										$(multipleObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
										inputField = $(multipleObj)[0].outerHTML;
									break;
									case 'datepicker':
										datePickerObj = document.createElement("select");
										datePickerObj.setAttribute("name", value.label.toLowerCase());
										datePickerObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										datePickerObj.setAttribute("data-element", parentId);
										datePickerObj.setAttribute("class", "properties_val date_prop" + errorClass);
											
										//add required option by default
										o = new Option('No', 'no');
										$(o).html('No');
										$(datePickerObj).append(o);
										o = new Option('Yes', 'datepicker');
										$(o).html('Yes');
										$(datePickerObj).append(o);
										
										$(datePickerObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
										inputField = $(datePickerObj)[0].outerHTML;
									break;
									case 'datetime-picker':
										dateTimePickerObj = document.createElement("select");
										dateTimePickerObj.setAttribute("name", value.label.toLowerCase());
										dateTimePickerObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										dateTimePickerObj.setAttribute("data-element", parentId);
										dateTimePickerObj.setAttribute("class", "properties_val date_time_prop" + errorClass);
											
										//add required option by default
										o = new Option('No', 'no');
										$(o).html('No');
										$(dateTimePickerObj).append(o);
										o = new Option('Yes', 'datetimepicker');
										$(o).html('Yes');
										$(dateTimePickerObj).append(o);
										
										$(dateTimePickerObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
										inputField = $(dateTimePickerObj)[0].outerHTML;
									break;
									case 'autosuggest':
										autoSuggestObj = document.createElement("select");
										autoSuggestObj.setAttribute("name", value.label.toLowerCase());
										autoSuggestObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										autoSuggestObj.setAttribute("data-element", parentId);
										autoSuggestObj.setAttribute("class", "properties_val autosuggest_prop" + errorClass);
											
										//add required option by default
										o = new Option('No', 'no');
										$(o).html('No');
										$(autoSuggestObj).append(o);
										o = new Option('Yes', 'enabled');
										$(o).html('Yes');
										$(autoSuggestObj).append(o);
										
										$(autoSuggestObj).find("option[value='" + attributesValue +"']").attr("selected","selected");
										inputField = $(autoSuggestObj)[0].outerHTML;
									break;

									case 'align':
										alignObj = document.createElement("select");
										alignObj.setAttribute("name", value.label.toLowerCase());
										alignObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										alignObj.setAttribute("class", "properties_val");
										$(alignObj)
											.append(new Option('', 'no'));
										
										//add alignment option by default										
										o = new Option('Left', 'left');
										$(o).html('Left');
										$(alignObj).append(o);
										o = new Option('Right', 'right');
										$(o).html('Right');
										$(alignObj).append(o);
										o = new Option('Center', 'center');
										$(o).html('Center');										
										$(alignObj).append(o);

										$(alignObj).find("option[value='" + attributesValue +"']").attr("selected","selected");										
										inputField = $(alignObj)[0].outerHTML;
									break;
									case 'options':
										optionObj = document.createElement("select");
										optionObj.setAttribute("name", value.label.toLowerCase());
										optionObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										optionObj.setAttribute("data-option", 0);
										optionObj.setAttribute("class", "properties_val add_select_options");
										$(optionObj)
											.append(new Option('', 'no'));
											
										o = new Option('Add Option...', 'add_options');
										$(o).html('Add Option');
										$(optionObj).append(o);
										
										$('option[value=no]', selObj).remove();
										$(selObj).find("option").clone().appendTo(optionObj);
										$(optionObj).find("option[value='" + attributesValue +"']").attr("selected","selected");										
										inputField = $(optionObj)[0].outerHTML;	
									break;
									case 'data-image':
										optionObj = document.createElement("select");
										optionObj.setAttribute("name", value.label.toLowerCase());
										optionObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										optionObj.setAttribute("data-image", attributesValue);
										optionObj.setAttribute("class", "properties_val add_image_upload");
										$(optionObj)
											.append(new Option('', 'no'));
											
										o = new Option('Choose files...', 'choose_files');
										$(o).html('Choose files...');
										$(optionObj).append(o);
										
										$('option[value=no]', selObj).remove();
										if(attributesValue != '') {
											ao = new Option(attributesValue, attributesValue);
											$(ao).html(attributesValue);
											$(optionObj).append(ao);
										}
										$(optionObj).find("option[value='" + attributesValue +"']").attr("selected","selected");										
										inputField = $(optionObj)[0].outerHTML;	
									break;
									case 'data-barcode-type':
										optionObj = document.createElement("select");
										optionObj.setAttribute("name", value.label.toLowerCase());
										optionObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										optionObj.setAttribute("data-image", attributesValue);
										optionObj.setAttribute("class", "properties_val");
											
										o = new Option('2D', '2D');
										$(o).html('2D');
										$(optionObj).append(o);										
										o = new Option('3D', '3D');
										$(o).html('3D');
										$(optionObj).append(o);
								
										$(optionObj).find("option[value='" + attributesValue +"']").attr("selected","selected");										
										inputField = $(optionObj)[0].outerHTML;	
									break;
									case 'data-persistent':
										var persistenceDropDownId = value.label.toLowerCase() + '-' + i;									
										optionObj = document.createElement("select");
										optionObj.setAttribute("name", value.label.toLowerCase());
										optionObj.setAttribute("id", persistenceDropDownId);
										optionObj.setAttribute("class", "properties_val");
										optionObj.setAttribute("multiple", true);
										$(optionObj)
											.append(new Option('', 'no'));										
										$(optionObj).addClass('ajax-dropdown-loading');
										
										if(dataPersistant.length > 0) {
											$.each(dataPersistant, function(index, item) {
												if(item.hasOwnProperty('template_persistent')) {
													var o = new Option(item.template_persistent.label, item.template_persistent.id);
													$(o).html(item.template_persistent.label);
												} else {
													var o = new Option(item.label, item.id);
													$(o).html(item.label);
												}
												$(optionObj).append(o);												
												if(attributesValue.length > 1) {
													pesistentAttributesValue = attributesValue.split(',');
													$.each(pesistentAttributesValue, function(index, items){
														$(optionObj).find("option[value='" + items +"']").attr("selected","selected");
													});											
												} else {
													attributesValue = 'no';
													$(optionObj).find("option[value=" + attributesValue +"]").attr("selected","selected");
												}
											});
										}									
										
										$(optionObj).removeClass('ajax-dropdown-loading');
										inputField = $(optionObj)[0].outerHTML;	
									break;
									case 'data-event':
										var eventDownId = value.label.toLowerCase() + '-' + i;									
										optionObj = document.createElement("select");
										optionObj.setAttribute("name", value.label.toLowerCase());
										optionObj.setAttribute("id", eventDownId);
										optionObj.setAttribute("class", "properties_val");
										$(optionObj)
											.append(new Option('', 'no'));
										$(optionObj).addClass('ajax-dropdown-loading');
										
										if(dataEvent.length > 0) {
											$.each(dataEvent, function(index, item) {
												if(item.hasOwnProperty('template_life_cycle_event')) {
													var o = new Option(item.template_life_cycle_event.life_cycle_event, item.template_life_cycle_event.id);
													$(o).html(item.template_life_cycle_event.life_cycle_event);
												} else {
													var o = new Option(item.life_cycle_event, item.id);
													$(o).html(item.life_cycle_event);
												}
												$(optionObj).append(o);
												$(optionObj).find("option[value='" + attributesValue + "']").attr("selected","selected");
											});
										}									
										
										$(optionObj).removeClass('ajax-dropdown-loading');
										inputField = $(optionObj)[0].outerHTML;	
									break;
									case 'data-condition':     
										conditionalParameterObj = document.createElement("textarea");
										conditionalParameterObj.setAttribute("name", value.label.toLowerCase());
										conditionalParameterObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										conditionalParameterObj.setAttribute("class", "properties_val");
										conditionalParameterObj.setAttribute("rows", "5");
										conditionalParameterObj.setAttribute("cols", "9");
										$(conditionalParameterObj).html(attributesValue);
										inputField = $(conditionalParameterObj)[0].outerHTML;
									break;
									case 'pattern':
										patternObj = document.createElement("select");
										patternObj.setAttribute("name", value.label.toLowerCase());
										patternObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										patternObj.setAttribute("class", "properties_val add_pattern");
										patternObj.setAttribute("data-pattern", attributesValue);
										$(patternObj)
											.append(new Option('', 'no'));
										o = new Option('Add Custom', 'add_custom_pattern');
										$(o).html('Add Custom');
										$(patternObj).append(o);
										
										var pattern = form_builder.pattern();
										
										var alreadyExists = false;
										$.each(pattern, function(index, item) {
											if(attributesValue == item[Object.keys(item)])
												alreadyExists = true;
											return;
										});
										
										if(alreadyExists) {
											$.each(pattern, function(index, item) {
												o = new Option(Object.keys(item), item[Object.keys(item)]);
												$(o).html(Object.keys(item));
												$(patternObj).append(o);
											});											
										} else {
											if(attributesValue != '') {
												var newPattern = {};
												var newPatternLabel = $(selObj).attr('data-pattern-label');
												newPattern[ newPatternLabel ] = attributesValue;
												pattern.push(newPattern);
											}
											
											$.each(pattern, function(index, item) {
												o = new Option(Object.keys(item), item[Object.keys(item)]);
												$(o).html(Object.keys(item));
												$(patternObj).append(o);
											});											
										}	
										
										attributesValue = attributesValue.replace(/\\/g, '\\\\');
										$(patternObj).find("option[value='" + attributesValue + "']").attr("selected","selected");	
										inputField = $(patternObj)[0].outerHTML;
									break;
									case 'style':
										inputHiddenObj = document.createElement("input");
										inputHiddenObj.type = "hidden";
										inputHiddenObj.setAttribute("name", value.label.toLowerCase());
										inputHiddenObj.setAttribute("id", value.label.toLowerCase() + '-' + i);
										inputHiddenObj.setAttribute("class", "properties_val");
										inputHiddenObj.setAttribute("value", value.value);
											
										inputField = $(inputHiddenObj)[0].outerHTML;
									break;
								
								}

								properties += '<tr data-id="' + parentId + '" data-type="' + type + '">' +
												  '<td valign="top" nowrap="nowrap" class="prop-table-label">' +
												  '' + ((attribute == 'style') ? '<strong>' + value.label +'</strong>' : value.label) + '<span class="prop-table-detail">' + value.description + '</span>' +
												  '</td>' +
												  '<td valign="top" class="prop-table-value">' +
												  '<div class="valueDiv">' + inputField + '</div>' +
												  '</td>'
												'</tr>';
								i++;
							});

							var j = i - 1;

							var attributesStyle = {};
							if(attributes.style != undefined) {
								var styleProperties = form_builder.extractStyleProperties(attributes.style);						
								
								$.each(styleProperties, function(index, attr) {
									attributesStyle[ attr.key.toLowerCase() ] = attr.value;
								});
							}
							
							if(fieldObj.style != undefined) {
								$.each(fieldObj.style.value, function(index, item) {
									var attribute = item.label.toLowerCase();
									var inputField = '';								
									var attributesValue = '';
									
									if(attributesStyle.hasOwnProperty(attribute)) {
										attributesValue = common.filterSpaceTrim(attributesStyle[ attribute ]);
									} else {
										attributesValue = common.filterSpaceTrim(item.value);
									}
									
									switch(attribute) {
										case 'list-style':
											listStyleObj = document.createElement("select");
											listStyleObj.setAttribute("name", item.label.toLowerCase());
											listStyleObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											listStyleObj.setAttribute("class", "properties_val");
											$(listStyleObj)
												.append(new Option('', 'no'));
											
											//add alignment option by default										
											o = new Option('Circle', 'circle');
											$(o).html('Circle');
											$(listStyleObj).append(o);
											o = new Option('Disc', 'disc');
											$(o).html('Disc');
											$(listStyleObj).append(o);
											o = new Option('Square', 'square');
											$(o).html('Square');										
											$(listStyleObj).append(o);
											o = new Option('None', 'none');
											$(o).html('None');										
											$(listStyleObj).append(o);										

											$(listStyleObj).find("option[value='" + attributesValue +"']").attr("selected","selected");										
											inputField = $(listStyleObj)[0].outerHTML;
										break;
										case 'text-decoration':										
											textDecorationObj = document.createElement("select");
											textDecorationObj.setAttribute("name", item.label.toLowerCase());
											textDecorationObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											textDecorationObj.setAttribute("class", "properties_val");
											$(textDecorationObj)
												.append(new Option('', 'no'));
											
											//Text-decoration option by default	
											var textDecoration = form_builder.textDecoration();																				
											$.each(textDecoration, function( index, item ) {											
												o = new Option( item, item.toLowerCase());
												$(o).html(item);
												$(textDecorationObj).append(o);
											});
																					
											$(textDecorationObj).find("option[value=" + attributesValue +"]").attr("selected","selected");										
											inputField = $(textDecorationObj)[0].outerHTML;
										break;
										case 'text-align':										
											textAlignObj = document.createElement("select");
											textAlignObj.setAttribute("name", item.label.toLowerCase());
											textAlignObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											textAlignObj.setAttribute("class", "properties_val");
											$(textAlignObj)
												.append(new Option('', 'no'));
											
											//Text-align option by default	
											var textAlign = form_builder.textAlign();																				
											$.each(textAlign, function( index, item ) {											
												o = new Option( item, item.toLowerCase());
												$(o).html(item);
												$(textAlignObj).append(o);
											});
																					
											$(textAlignObj).find("option[value=" + attributesValue +"]").attr("selected","selected");										
											inputField = $(textAlignObj)[0].outerHTML;
										break;
										case 'font-style':										
											fontStyleObj = document.createElement("select");
											fontStyleObj.setAttribute("name", item.label.toLowerCase());
											fontStyleObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											fontStyleObj.setAttribute("class", "properties_val");
											$(fontStyleObj)
												.append(new Option('', 'no'));
											
											//Font-style option by default	
											var fontStyle = form_builder.fontStyle();																				
											$.each(fontStyle, function( index, item ) {											
												o = new Option( item, item.toLowerCase());
												$(o).html(item);
												$(fontStyleObj).append(o);
											});
																					
											$(fontStyleObj).find("option[value=" + attributesValue +"]").attr("selected","selected");										
											inputField = $(fontStyleObj)[0].outerHTML;
										break;
										case 'font-weight':										
											fontWeightObj = document.createElement("select");
											fontWeightObj.setAttribute("name", item.label.toLowerCase());
											fontWeightObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											fontWeightObj.setAttribute("class", "properties_val");
											$(fontWeightObj)
												.append(new Option('', 'no'));
											
											//Font weight option by default	
											var fontWeight = form_builder.fontWeight();																				
											$.each(fontWeight, function( index, item ) {											
												o = new Option( item, item.toLowerCase());
												$(o).html(item);
												$(fontWeightObj).append(o);
											});
																					
											$(fontWeightObj).find("option[value=" + attributesValue +"]").attr("selected","selected");										
											inputField = $(fontWeightObj)[0].outerHTML;
										break;
										case 'font-size':										
											fontSizeObj = document.createElement("select");
											fontSizeObj.setAttribute("name", item.label.toLowerCase());
											fontSizeObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											fontSizeObj.setAttribute("class", "properties_val");
											$(fontSizeObj)
												.append(new Option('', 'no'));							
											for(var i = 8; i <= 72; i++) {
												o = new Option( i, i + 'px');
												$(o).html(i);
												$(fontSizeObj).append(o);	
											}
											
											$(fontSizeObj).find("option[value='" + attributesValue +"']").attr("selected","selected");										
											inputField = $(fontSizeObj)[0].outerHTML;
										break;
										case 'font-family':
											
											fontFamilyObj = document.createElement("select");
											fontFamilyObj.setAttribute("name", item.label.toLowerCase());
											fontFamilyObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											fontFamilyObj.setAttribute("class", "properties_val");
											$(fontFamilyObj)
												.append(new Option('', 'no'));
											
											//Font family option by default	
											var fonts = form_builder.fontFamily();																				
											$.each(fonts, function( index, item ) {											
												o = new Option( item, item.toLowerCase());
												$(o).html(item);
												$(fontFamilyObj).append(o);
											});
											//console.log(form_builder.editorFormFont);
											$(fontFamilyObj).find("option[value='" + ((attributesValue != '') ? attributesValue : form_builder.editorFormFont) +"']").attr("selected","selected");
											inputField = $(fontFamilyObj)[0].outerHTML;
										break;
										case 'color':	
											inputColorObj = document.createElement("input");
											inputColorObj.type = "text";
											inputColorObj.setAttribute("name", item.label.toLowerCase());
											inputColorObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											inputColorObj.setAttribute("class", "properties_val colorpicker");
											var valueString = (attributesValue != '') ? attributesValue : "rgb(0, 0, 0)";
											inputColorObj.setAttribute("value", valueString );                                                                                   
											inputField = $(inputColorObj)[0].outerHTML;  	                     
										break;
										case 'background-color':  	                  
											inputBackgroundColorObj = document.createElement("input");
											inputBackgroundColorObj.type = "text";
											inputBackgroundColorObj.setAttribute("name", item.label.toLowerCase());
											inputBackgroundColorObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											inputBackgroundColorObj.setAttribute("class", "properties_val colorpicker");
											var valueString = form_builder.backGroundValue(type, attributesValue);											
											inputBackgroundColorObj.setAttribute("value", valueString); 	          
											inputField = $(inputBackgroundColorObj)[0].outerHTML;
										break;  
										default:
											inputObj = document.createElement("input");
											inputObj.type = "text";
											inputObj.setAttribute("name", item.label.toLowerCase());
											inputObj.setAttribute("id", item.label.toLowerCase() + '-' + j);
											inputObj.setAttribute("class", "properties_val");
											inputObj.setAttribute("value", attributesValue);
											
											inputField = $(inputObj)[0].outerHTML;
										break;
									}
									
									properties += '<tr data-id="' + parentId + '" data-type="' + type + '">' +
												  '<td valign="top" nowrap="nowrap" class="prop-table-label">' +
												  '' + item.label + '<span class="prop-table-detail">' + item.description + '</span>' +
												  '</td>' +
												  '<td valign="top" class="prop-table-value">' +
												  '<div class="valueDiv">' + inputField + '</div>' +
												  '</td>'
												'</tr>';								
									j++;
								});
							
							}
								
							return properties;
						}				
						
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: get the Background value of the control based on the control type.
			 * @ Params: element type, attributes value
			 * @ Returns: N/A
			/*************/
			backGroundValue: function(type, attributesValue) {
				try {
					var valueString = "";
					if(type == 'text' 
						|| type == 'textarea' 
						|| type == 'select' 
						|| type == 'simple-signature' 
						|| type == 'inking-overlay' 
						|| type == 'date-time-picker' 
						|| type == 'submit') {
						valueString = (attributesValue != '') ? attributesValue : "rgb(255, 255, 255)";
					} else {
						valueString = (attributesValue != '') ? attributesValue : "rgba(255, 255, 255, 0)";
					}
					return valueString;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},

			/*********
			 * @ Desc: Scroll div block on page scroll.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			divSectionScroll: function(htmlDom) {
				try {
					var el = $(htmlDom);
					var originalelpos = el.offset().top; // take it where it originally is on the page
					var parentDiv = $('.form-builder');
					var parentDivpos = parentDiv.height();
					
					//run on scroll
					$(window).scroll(function () {
						parentDivpos = parentDiv.height();						
						var el = $(htmlDom);
						var elpos = el.offset().top; // take current situation
						var windowpos = $(window).scrollTop();
						var finaldestination = 0;

						if(windowpos == 0) {
							finaldestination = windowpos;
						} else {
							if(windowpos >= originalelpos) {
								finaldestination = (windowpos - originalelpos);
							}
						}
							
						if((windowpos + el.height()) >= parentDivpos)
							el.stop().animate({ 'top': (parentDivpos - el.height()) }, 500);
						else
							el.stop().animate({ 'top': finaldestination }, 500);
						
						$('.sp-container').addClass('sp-hidden');
					});					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},				

			/*********
			 * @ Desc: Handle the controls up/down/left/right by keyboard key
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			handleKeys: function(e) {
				try {
					if($(draggableEventOn).hasClass('form-row')) {
						var	draggableElement = $(draggableEventOn);
						var	withinContainer = $('ul#list');
						var dragDistance = 1; // Distance in pixels the draggable should be moved

						var position = draggableElement.position();
						//console.log(e.keyCode);
						// Reposition if one of the directional keys is pressed
						switch (e.keyCode) {
							case 37: position.left -= dragDistance; break; // Left
							case 38: position.top  -= dragDistance; break; // Up
							case 39: position.left += dragDistance; break; // Right
							case 40: position.top  += dragDistance; break; // Down
							default: return true; // Exit and bubble
						}

						// Keep draggable within container
						if (position.left >= 0 && position.top >= 0 &&
							position.left + draggableElement.width() <= withinContainer.width() &&
							position.top + draggableElement.height() <= withinContainer.height()) {
							draggableElement.css(position);
						}

						// Disabled page scroll.
						e.preventDefault();
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},

			/*********
			 * @ Desc: Get Element Object based on element id
			 * @ Params: N/A
			 * @ Returns: Object
			/*************/
			getBarcodeObject: function(id) {
				try {
					var object = null;
					if (document.layers) {
						object = document.layers[id];
					} else if (document.all) {
						object = document.all[id];
					} else if (document.getElementById) {
						object = document.getElementById(id);
					}
					return object;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			}
		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
var left;
var top;
var outerwidth;
var outerheight;
jQuery(document).ready(function($){
	
	$('body').on('keydown', function(e){
		form_builder.handleKeys(e);	
	});
	
	form_builder.init();
	form_builder.divSectionScroll('.left-content');
	form_builder.divSectionScroll('.right-content');
	
	var $superpanel = $("#form_panel");

	var offset = $superpanel.offset();
	left = offset.left;
	top = offset.top;
	outerheight = $superpanel.outerHeight();
	outerwidth = $superpanel.outerWidth();
	
	$( "#toolbox li.drags" ).draggable({
		appendTo: "body",
		helper: "clone"
	});
	
	$( "#form_area ul#list" ).droppable({
		activeClass: "ui-state-default",
		hoverClass: "ui-state-hover",
		accept: ":not(.ui-sortable-helper)",
		drop: function( event, ui ) {
			var elementIdObj = form_builder.addFields(ui, this);
			var currentDropObj = (!elementIdObj) ? this : elementIdObj;
			if($('#update_form_id').val() != undefined && $('#update_form_id').val() != "") {
				common.captureChangesInEditor(event, ui, currentDropObj);
			}
			$( this ).find( ".placeholder" ).remove();			
		}
	}).sortable({
		items: "div:not(.placeholder)",
		sort: function(e) {
			// gets added unintentionally by droppable interacting with sortable
			// using connectWithSortable fixes this, but doesn't allow you to customize active/hoverClass options
			$( this ).removeClass( "ui-state-default" );
		}
	});
	
});