$(function(){
	var btnUpload=$('#upload');
	var status=$('#status');
	var imageName = '';
	new AjaxUpload(btnUpload, {
		action: baseUrl + '/template/upload_image',
		name: 'uploadfile',
		onSubmit: function(file, ext){
			 if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))){
				// extension is not allowed
				status.text('Only JPG, PNG or GIF files are allowed').fadeOut(5000);
				return false;
			}
			status.text('Uploading...').fadeOut(5000);
		},
		onComplete: function(file, response){			
			responsePre = $('<pre></pre>').html(response).text();
			responsePreObj = $.parseJSON(responsePre);
			
			//On completion clear the status
			status.text('');			
			if(responsePreObj[0].hasOwnProperty('success')) {
				renderImageList(responsePreObj);
			} else {
				alert('Please choose correct picture to upload.');
			}
		}
	});
	
	renderImageList = function(responsePreObj) {
		try {
			//$('<li></li>').appendTo('#files').html('<img src="images/upload/'+ responsePreObj[0].success +'" alt="" width="170" />');
			var imageHtml = '';
			imageHtml = '<tr id="' + responsePreObj[0].id + '">' + 
						'<td valign="top" class="prop-table-value"><input type="radio" name="image_select" value="' + responsePreObj[0].name + '"></td>' +
						'<td valign="top">' + responsePreObj[0].name + '</td>' +
						'<td valign="top"><img src="images/upload/' + responsePreObj[0].name + '" alt="" width="60" /></td>' +
						'<td valign="top">Active</td>' +
						'<td valign="top"><input type="button" name="delete_image" id="delete_image" data-id="' + responsePreObj[0].id + '" value="Delete"></td>' +
						'</tr>';
						
			$('#image-list-box-table')
				.find('#no-image-items')
				.remove();
			$('#image-list-box-table').append(imageHtml);
		} catch (e) {
		   console.log(e.message, e.name);
		}
	}

});