/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD
 * @ Dependency : "common.js"
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */
template_form = {};

(function($) {
	
		template_form = {				
		
			/*********
			 * @ Desc: Initialize default function with page load. Define the different types of action perform on document.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			init: function() {				

				/*********
				 * @ Desc: Click function on "show-library-data" class, In this action, show the list of form according to library selection
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var type = $(this).attr("data-type");
						var activeTab = (type == 'centrally') ? 1 : 0
						var dataForm = $(this).attr("data-form");
						template_form.loadTemplateForm(type, activeTab, dataForm);
					}																		
				}, '.show-library-data');
				/*********
				 * @ Desc: Click function on "draftForm" or "publishedForm" class, In this action, show the list of form according to data-form selection
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var dataForm = $(this).attr('data-form')
						$('.show-library-data').attr('data-form', dataForm);	
						template_form.loadTemplateForm('centrally', 1, dataForm);						
					}																		
				}, '.draftForm, .publishedForm');
				/*********
				/*********
				 * @ Desc: Click function on "draftForm" or "publishedForm" class, In this action, show the list of form according to data-form selection
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var dataId = $(this).attr('data-id')
						var dataForm = $(this).attr('data-form');	
						var type = $(this).attr('data-type');	
						var activeTab = (type == 'centrally') ? 1 : 0
						template_form.publishForm(type, activeTab, dataForm, dataId);						
					}																		
				}, '.publish-form');
				
				/*********
				 * @ Desc: Click function on anchor tag for pagination of form template listing.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						var templateObj = new Template();
						templateObj.setValue('async', Template.async);
						templateObj.setValue('url', this.href + '&library_type=' + $('#library_type').val());
						templateObj.setValue('library_type', $('#library_type').val());							
						templateObj.setValue('data_form', $('.show-library-data').attr('data-form'));							
						templateObj.setValue('target', 'form_list');							
						templateObj.templateFormPagination();
						//$.getScript(this.href + '&library_type=' + $('#library_type').val());
						return false;														
					}
				}, '.form-list-user .pagination a.template-form-pagination');
				
				/*********
				 * @ Desc: Click function on anchor tag for pagination of form template listing.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						$('.toolbar a').removeClass('active');												
						$(this).addClass('active');												
					}
				}, '.toolbar a');
				
			},
			
			/*********
			 * @ Desc: Render the list of form into dialog box.
			 * @ Params: data, type of the form
			 * @ Returns: N/A
			/*************/
			renderTemplateFormList: function(data, type) {
				try {
					$('#tabs-' + type).html(data);
					$('.delete-form').attr('data-type', type);
					$('.edit-form').attr('data-type', type);
					$('.library_type').val(type);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: load template form of user.
			 * @ Params: type of the form, active tab index, data form
			 * @ Returns: N/A
			/*************/
			loadTemplateForm: function(type, activeTab, dataForm) {
				try {
					$("#tabs").tabs({ active: activeTab });
					
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('library_type', type);							
					templateObj.setValue('data_form', dataForm);					
					templateObj.setValue('target', 'form_list');							
					templateObj.showTemplateFormList();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: publish form of user.
			 * @ Params: type of the form, active tab index, data form, id of the template form
			 * @ Returns: N/A
			/*************/
			publishForm: function(type, activeTab, dataForm, dataId) {
				try {
					$("#tabs").tabs({ active: activeTab });
					
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('library_type', type);							
					templateObj.setValue('data_form', dataForm);							
					templateObj.setValue('data_id', dataId);							
					templateObj.setValue('target', 'publish_form');							
					templateObj.publishForm();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			}
			
		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
jQuery(document).ready(function($){
	template_form.init();
	template_form.loadTemplateForm('centrally', 1, 'draft');	
	
});