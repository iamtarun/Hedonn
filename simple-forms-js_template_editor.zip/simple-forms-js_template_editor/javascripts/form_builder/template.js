/* 
 * @ Created On : June 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD, Template class 
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */
(function($) {
	Template = function() {
		this.base_url = "http://192.168.15.144:3000",
		this.initialize = function() {
			try {
				//alert('Initialized!');
				this.getEvents();
				this.getPersistents();
				this.getLocations();
				this.getImages();				
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.save = function() {
			try {
				
				params = {
					'url': this.base_url + this.locations_url + '/save',
					'async': this.async,
					'data': {
								'content': this.content,
								'name': this.name,
								'id': this.id,
								'column': this.column,
								'locations': this.locations,
								'template_type': this.template_type,
								'activity_log': this.activity_log
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('Save function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.show = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/show',
					'async': this.async,
					'data': {
								'library_type': this.library_type,
								'data_template': this.data_template
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('Show function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.deleteTemplate = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/delete',
					'async': this.async,
					'data': {
								'form_id': this.form_id,
								'library_type': this.library_type,
								'data_template': this.data_template
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('Delete function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.publishTemplate = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/publish_template',
					'async': this.async,
					'data': {
								'library_type': this.library_type,
								'form_id': this.form_id,
								'data_template': this.data_template
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('Publish function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.templatePagination = function() {
			try {
				params = {
					'url': this.url,
					'async': this.async,
					'data': {
								'library_type': this.library_type,
								'data_template': this.data_template
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('Template Pagination function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.templateFormPagination = function() {
			try {
				params = {
					'url': this.url,
					'async': this.async,
					'data': {
								'library_type': this.library_type,
								'data_form': this.data_form
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('Template Pagination function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.templateFormSearchPagination = function() {
			try {
				params = {
					'url': this.url,
					'async': this.async,
					'data': {},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('Template Pagination function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},

		this.getImages = function() {
			try {
				
				params = {
					'url': this.base_url + '/template/get_template_image',
					'async': this.async,
					'data': {},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('GetImage function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getEvents = function() {
			try {
				
				params = {
					'url': this.base_url + '/template/get_template_event',
					'async': this.async,
					'data': {},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('GetEvents function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getPersistents = function() {
			try {
				
				params = {
					'url': this.base_url + '/template/get_persistence',
					'async': this.async,
					'data': {},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('GetPersistents function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getLocations = function() {
			try {
				
				params = {
					'url': this.base_url + '/template/get_locations',
					'async': this.async,
					'data': {},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('GetLocations function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getActivityLog = function() {
			try {
				
				params = {
					'url': this.base_url + '/template/get_activity_log',
					'async': this.async,
					'data': {
								'template_id': this.template_id
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('GetActivityLog function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.deleteUploadedImage = function() {
			try {
				
				params = {
					'url': this.base_url + '/template/delete_image',
					'async': this.async,
					'data': {
								'id': this.id
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('DeleteUploadedImage function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getTemplateForm = function() {
			try {
				
				params = {
					'url': this.base_url + '/template/show_template_form',
					'async': this.async,
					'data': {
								'library_type': this.library_type,
								'form_id': this.form_id
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('GetTemplateForm function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.showTemplateForm = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/show_form',
					'async': this.async,
					'data': {
								'id': this.id,
								'library_type': this.library_type,
								'form_id': this.form_id,
								'new_form': this.new_form
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('ShowTemplateForm function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.saveTemplateForm = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/save_form_template',
					'async': this.async,
					'data': {
								'template_id': this.template_id,
								'data_json': this.data_json,
								'patient_id': this.patient_id,
								'library_type': this.library_type,
								'file_upload': this.file_upload,
								'file_upload_element': this.file_upload_element
							},
					'target': this.target
				}
				this.getResponse(params);
				//alert('SaveTemplateForm function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.publishForm = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/publish_form',
					'async': this.async,
					'data': {
								'data_form': this.data_form,
								'data_id': this.data_id,
								'library_type': this.library_type
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('PublishForm function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.showTemplateFormList = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/form_list',
					'async': this.async,
					'data': {
								'data_form': this.data_form,
								'library_type': this.library_type
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('ShowTemplateFormList function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getTemplateFormList = function() {
			try {
				
				params = {
					'url': this.base_url + this.url,
					'async': this.async,
					'data': {
								'data': this.data
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('GetTemplateFormList function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.printTemplateFormData = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/create_inking_image',
					'async': this.async,
					'data': {
								'data_json': this.data_json
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('PrintTemplateFormData function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.deletePrintOverlay = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/delete_inking_image',
					'async': this.async,
					'data': {
								'image_path': this.image_path
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('DeletePrintOverlay function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getPersistentAutoSuggest = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/get_persistent_url',
					'async': this.async,
					'data': {
								'data_persistent': this.data_persistent
							},
					'auto_suggest_element_id': this.auto_suggest_element_id,
					'target': this.target
				}				
				this.getResponse(params);
				//alert('GetPersistentAutoSuggest function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getAutoSuggestData = function() {
			try {
				
				params = {
					'url': this.base_url + this.url,
					'async': this.async,
					'data': {
								'keyword': this.keyword,
								'template_id': this.template_id,
								'data_persistent': this.data_persistent
							},
					'auto_suggest_element_id': this.auto_suggest_element_id,
					'target': this.target
				}				
				return this.getResponse(params);
				//alert('GetAutoSuggestData function called!');
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.uploadTemplateFile = function() {
			try {				
				var current_element = this.current_element;				
				var btnUpload = $(current_element).children(':first');
				var status = $(current_element).find('.status');
				var template_id = this.template_id;
				new AjaxUpload(btnUpload, {
					action: this.base_url + '/api/template/upload_template_file',
					name: 'uploadfile',
					onSubmit: function(file, ext){						
						template_form_data.setFileLabel(current_element, file);						
						var extension = file.substring(file.lastIndexOf('.') + 1);
						var imageArray = file.split('.');
						var uniqueNumber = common.generateUniqueNumber();
						var newFileName = imageArray[0] + "_" + uniqueNumber + "." + ext;						
						var elementId = $(current_element).attr('id');
						
						template_form_data.setFileUploaded(elementId, newFileName);					
						
						this.setData({ 'file_name': newFileName, 'template_id':template_id});						
					},
					onComplete: function(file, response){			
						console.log(response);
					}
				});
				
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.showTemplateFile = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/view_file',
					'async': this.async,
					'data': {
								'id': this.id
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('ShowTemplateFile function called!');
			} catch (e) {
			   console.log(e.message, e.name);			 
			}
		},
		
		this.showActivityLog = function() {
			try {
				
				params = {
					'url': this.base_url + '/api/template/show_activity_log',
					'async': this.async,
					'data': {
								'id': this.id
							},
					'target': this.target
				}				
				this.getResponse(params);
				//alert('ShowActivityLog function called!');
			} catch (e) {
			   console.log(e.message, e.name);			 
			}
		},
		
		this.getxmlhttpobject = function() {
			var xmlhttp = null; 
			try {
				/* Firefox, Opera 8.0+, Safari*/ 
				xmlhttp = new XMLHttpRequest(); 
			} catch (e){ 
				/*Internet Explorer */ 
					try{ 
						xmlhttp = new ActiveXObject("Msxml2.XMLHTTP"); 
					} catch (e){ 
						xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
					} 
			}
			return xmlhttp;
		}
		
		/*********
		 * @ Desc: Send ajax request.
		 * @ Params: Object
		 * @ Returns: N/A
		/*************/
		this.getResponse = function(params) { 
			try {
				jQuery.browser = {};
				jQuery.browser.mozilla = /mozilla/.test(navigator.userAgent.toLowerCase()) && !/webkit/.test(navigator.userAgent.toLowerCase());
				jQuery.browser.webkit = /webkit/.test(navigator.userAgent.toLowerCase());
				jQuery.browser.opera = /opera/.test(navigator.userAgent.toLowerCase());
				jQuery.browser.msie = /msie/.test(navigator.userAgent.toLowerCase());
				if (jQuery.browser.msie && window.XDomainRequest) {
					var query = '';
					async = true;
					if(params['target'] == 'show_form') {
						$('#tabs-' + params['data']['library_type']).html('');
						$("#tabs-" + params['data']['library_type']).addClass('loading');
					} else if(params['target'] == 'save_form') {						
						$("#dialog-modal").html('');
						common.showDialog('Saving Form');
						$("#dialog-modal").addClass('loading');									
					} else if(params['target'] == 'show_form_data') {
						common.showDialog('Loading Template Form');
						$("#dialog-modal").addClass('loading');
					} else if(params['target'] == 'save_form_data') {
						common.showDialog('Saving Template Form');
						$("#dialog-modal").addClass('loading');
					} else if(params['target'] == 'locations') {
						$("#locations").addClass('ajax-dropdown-loading');									
					} else if(params['target'] == 'show_form_new_edit') {
						common.showDialog('Loading Template Form');
						$("#dialog-modal").addClass('loading');
					} else if((params['target'] == 'form_list') || (params['target'] == 'publish_form')) {
						$('#tabs-' + params['data']['library_type']).html('');
						$("#tabs-" + params['data']['library_type']).addClass('loading');
					} else if(params['target'] == 'template_form_list') {
						$("#tabs-centrally").html('');
						$("#tabs-centrally").addClass('loading');
					} else if(params['target'] == 'print_form') {
						common.showDialog('Loading to Print Template Form');
						$("#dialog-modal").addClass('loading');
					} else if(params['target'] == 'show_auto_suggest_data') {
						async = false;
						$('#' + params["auto_suggest_element_id"]).addClass('ajax-dropdown-loading');
					} else if(params['target'] == 'view_file') {
						common.showDialog('Loading Template Form');
						$("#dialog-modal").addClass('loading');
					} else if(params['target'] == 'activity_log') {
						$("#activity_log").addClass('loading');
					} else if(params['target'] == 'show_activity_log') {
						common.showDialog('Loading Activity Log');
						$("#dialog-modal").addClass('loading');
					}
					
					var xmlhttp = this.getxmlhttpobject();					
					xmlhttp.onreadystatechange = function() {
						if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
							//alert(xmlhttp.responseText);
							var data = xmlhttp.responseText;
							switch(params['target']) {
								case 'save_form':									
									$("#dialog-modal").removeClass('loading');
									form_builder.savedFormData(xmlhttp.responseText);
								break;
								case 'show_form':
									$("#tabs-" + params['data']['library_type']).removeClass('loading');
									form_builder.renderFormList(data, params['data']['library_type']);
								break;
								case 'persistence':
									Template.persistentsArray = eval(data);
									form_builder.assignPersistence(eval(data), params);								
								break;
								case 'template_event':
									Template.eventsArray = eval(data);
									form_builder.assignEvents(eval(data), params);	
								break;
								case 'delete_form':	
									form_builder.resetFormList(eval(data), params);								
								break;
								case 'show_template_form':
									form_builder.renderTemplateForm(data, params);								
								break;
								case 'locations':
									Template.locationsArray = eval(data);
									form_builder.renderLocations(eval(data), params);								
								break;
								case 'delete_image':
									form_builder.resetImageList(eval(data), params);								
								break;
								case 'template_image':
									Template.imagesArray = eval(data);
									form_builder.assignImageList(eval(data), params);								
								break;
								case 'publish_template':
									form_builder.resetFormList(eval(data), params);								
								break;
								case 'show_form_data':
									$("#dialog-modal").removeClass('loading');
									$('#dialog-modal').dialog("close");
									preview_form.renderForm(data);
								break;
								case 'save_form_data':
									$("#dialog-modal").removeClass('loading');
									template_form_data.renderFormData(eval("(" + data + ")"));
								break;
								case 'show_form_new_edit':
									$("#dialog-modal").removeClass('loading');
									$('#dialog-modal').dialog("close");
									template_form_data.renderForm(data);
								break;
								case 'form_list':
									$("#tabs-" + params['data']['library_type']).removeClass('loading');
									template_form.renderTemplateFormList(data, params['data']['library_type']);
								break;
								case 'publish_form':
									$("#tabs-" + params['data']['library_type']).removeClass('loading');
									template_form.renderTemplateFormList(eval(data), params['data']['library_type']);
								break;
								case 'template_form_list':
									$("#tabs-centrally").removeClass('loading');
									template_form_edit.renderTemplateFormList(data);
								break;
								case 'print_form':
									common.renderPrintTemplateFormData(eval("(" + data + ")"));
								break;
								case 'auto_suggest_load':
									Template.autoSuggestUrlArray.push({'data_url':data, 'element':params["auto_suggest_element_id"], 'data_persistent':params["data"]["data_persistent"]});
									//common.renderAutoSuggestControl(data, params["auto_suggest_element_id"]);
								break;
								case 'show_auto_suggest_data': 
									$('#' + params["auto_suggest_element_id"]).removeClass('ajax-dropdown-loading');
									return data;
									//common.renderAutoSuggest(eval(data), params["auto_suggest_element_id"]);
								break;
								case 'view_file':
									$("#dialog-modal").removeClass('loading');
									$('#dialog-modal').dialog("close");
									file_browse.renderForm(data);
								break;
								case 'activity_log':
									$("#activity_log").removeClass('loading');
									form_builder.renderAcitivityLog(eval("(" + data + ")"), params);
								break;
								case 'show_activity_log':
									$("#dialog-modal").removeClass('loading');
									$('#dialog-modal').dialog("close");
									view_log.renderForm(data);
								break;
							}
						} else if(xmlhttp.readyState == 4 && xmlhttp.status == 12029) {
							common.renderApiFailure();
						}
					}
					
					xmlhttp.open('POST', params['url'], async);
					xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
					xmlhttp.setRequestHeader("Content-length", common.len(params['data']));
					xmlhttp.setRequestHeader("Connection", "close");
					xmlhttp.send(((common.len(params['data']) > 0) ? $.param(params['data']) : null));					
					
					if(params['target'] == 'show_auto_suggest_data') {
						if (xmlhttp.status === 200) {
							return xmlhttp.responseText;
						}
					}
					
				} else {
					
					var getXHR = $.ajax({
						type: 'POST',
						url: params['url'],
						async: (params["async"] == 0) ? false : true ,
						data: params['data'],
						beforeSend: function(xhr) {
							if(params['target'] == 'show_form') {
								$('#tabs-' + params['data']['library_type']).html('');
								$("#tabs-" + params['data']['library_type']).addClass('loading');
							} else if(params['target'] == 'save_form') {
								$("#dialog-modal").html('');
								common.showDialog('Saving Form');
								$("#dialog-modal").addClass('loading');									
							} else if(params['target'] == 'show_form_data') {
								common.showDialog('Loading Template Form');
								$("#dialog-modal").addClass('loading');
							} else if(params['target'] == 'save_form_data') {								
								xhr.setRequestHeader('Content-Type', 'multipart/form-data');		
								//xhr.setRequestHeader("X-CSRF-Token", $('meta[name=csrf-token]').attr('content'));						
								common.showDialog('Saving Template Form');
								$("#dialog-modal").addClass('loading');
							} else if(params['target'] == 'locations') {
								$("#locations").addClass('ajax-dropdown-loading');									
							} else if(params['target'] == 'show_form_new_edit') {
								common.showDialog('Loading Template Form');
								$("#dialog-modal").addClass('loading');
							} else if((params['target'] == 'form_list') || (params['target'] == 'publish_form')) {
								$('#tabs-' + params['data']['library_type']).html('');
								$("#tabs-" + params['data']['library_type']).addClass('loading');
							} else if(params['target'] == 'template_form_list') {
								$("#tabs-centrally").html('');
								$("#tabs-centrally").addClass('loading');
							} else if(params['target'] == 'print_form') {
								common.showDialog('Loading to Print Template Form');
								$("#dialog-modal").addClass('loading');
							} else if(params['target'] == 'show_auto_suggest_data') {
								$('#' + params["auto_suggest_element_id"]).addClass('ajax-dropdown-loading');
							} else if(params['target'] == 'view_file') {
								common.showDialog('Loading Template Form');
								$("#dialog-modal").addClass('loading');
							} else if(params['target'] == 'activity_log') {
								$("#activity_log").addClass('loading');
							} else if(params['target'] == 'show_activity_log') {
								common.showDialog('Loading Activity Log');
								$("#dialog-modal").addClass('loading');
							}
						},
						complete: function() {
						},
						success: function(data) {								
							//console.log(data); 
							switch(params['target']) {
								case 'save_form':									
									$("#dialog-modal").removeClass('loading');
									form_builder.savedFormData(data);
								break;
								case 'show_form':
									$("#tabs-" + params['data']['library_type']).removeClass('loading');
									form_builder.renderFormList(data, params['data']['library_type']);
								break;
								case 'persistence':
									Template.persistentsArray = data;
									form_builder.assignPersistence(data, params);								
								break;
								case 'template_event':
									Template.eventsArray = data;
									form_builder.assignEvents(data, params);	
								break;
								case 'delete_form':	
									form_builder.resetFormList(data, params);								
								break;
								case 'show_template_form':
									form_builder.renderTemplateForm(data, params);								
								break;
								case 'locations':
									Template.locationsArray = data;
									form_builder.renderLocations(data, params);								
								break;
								case 'delete_image':
									form_builder.resetImageList(data, params);								
								break;
								case 'template_image':
									Template.imagesArray = data;
									form_builder.assignImageList(data, params);								
								break;
								case 'publish_template':
									form_builder.resetFormList(data, params);								
								break;
								case 'show_form_data':
									$("#dialog-modal").removeClass('loading');
									$('#dialog-modal').dialog("close");
									preview_form.renderForm(data);
								break;
								case 'save_form_data':									
									$("#dialog-modal").removeClass('loading');
									template_form_data.renderFormData(data);
								break;
								case 'show_form_new_edit':
									$("#dialog-modal").removeClass('loading');
									$('#dialog-modal').dialog("close");
									template_form_data.renderForm(data);
								break;
								case 'form_list':
									$("#tabs-" + params['data']['library_type']).removeClass('loading');
									template_form.renderTemplateFormList(data, params['data']['library_type']);
								break;
								case 'publish_form':
									$("#tabs-" + params['data']['library_type']).removeClass('loading');
									template_form.renderTemplateFormList(data, params['data']['library_type']);
								break;
								case 'template_form_list':
									$("#tabs-centrally").removeClass('loading');
									template_form_edit.renderTemplateFormList(data);
								break;
								case 'print_form':
									common.renderPrintTemplateFormData(data);
								break;
								case 'auto_suggest_load':
									Template.autoSuggestUrlArray.push({'data_url':data, 'element':params["auto_suggest_element_id"], 'data_persistent':params["data"]["data_persistent"]});
									//common.renderAutoSuggestControl(data, params["auto_suggest_element_id"]);
								break;
								case 'show_auto_suggest_data':
									$('#' + params["auto_suggest_element_id"]).removeClass('ajax-dropdown-loading');
									//common.renderAutoSuggest(data, params["auto_suggest_element_id"]);
								break;
								case 'view_file':
									$("#dialog-modal").removeClass('loading');
									$('#dialog-modal').dialog("close");
									file_browse.renderForm(data);
								break;
								case 'activity_log':
									$("#activity_log").removeClass('loading');
									form_builder.renderAcitivityLog(data, params);
								break;
								case 'show_activity_log':
									$("#dialog-modal").removeClass('loading');
									$('#dialog-modal').dialog("close");
									view_log.renderForm(data);
								break;
							}
						},
						error: function(xhr, status, error) {
							if(xhr.readyState == 0 && xhr.status == 0) {
								common.renderApiFailure();							
							}
						}
					});
					
					return getXHR.responseText;
				}				
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getParams = function() {
			try {
				var params = {};
				$.each(this, function(index, item) {
					if($.isFunction(item)) return;					
					params[ index ] = item;					
				});
				return params;
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.setValue = function(name, value) {
			try {
				this[name] = value;
			} catch (e) {
			   console.log(e.message, e.name);
			}
		},
		
		this.getValue = function(name) {
			try {
				return this[name];
			} catch (e) {
			   console.log(e.message, e.name);
			}
		}
	};
	
	Template.fileUploadObj = {};
	Template.locationsArray = [];
	Template.eventsArray = [];
	Template.persistentsArray = [];
	Template.imagesArray = [];
	Template.autoSuggestUrlArray = [];
	Template.async = 1;
	Template.sync = 0;
	
})(jQuery);