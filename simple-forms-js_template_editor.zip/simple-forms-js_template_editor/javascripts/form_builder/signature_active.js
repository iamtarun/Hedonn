jQuery(document).ready(function($){
	var options = {
	  bgColour : '#ffffff',
	  drawOnly : true
	};
	$('.form-simple-signature').find('.sigPad').signaturePad(options);	
});