/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */
config_controls = {};

(function($) {
	
		config_controls = {
			/*********
			 * @ Desc: Inialize different types of form fields into variable.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			config_fields_attributes: {
				'label' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'label' : {
						'label' : 'Label',
						'value' : '',
						'description' : 'Text of Label'
					},
					'Name' : {
						'label' : 'Name',
						'value' : '',
						'description' : 'Name of Label'
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : 'Description of field types'
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'display' : {
								'label' : 'Display',
								'value' : '',
								'description' : 'Ex. block or inline-block or none'
							},
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'text' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'auto-suggest' : {
						'label' : 'Auto-suggest',
						'value' : '',
						'description' : 'Auto-suggest on controls'
					},
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'placeholder' : {
						'label' : 'Placeholder',
						'value' : '',
						'description' : ''
					},
					'size' : {
						'label' : 'Size',
						'value' : '',
						'description' : ''
					},
					'maxlength' : {
						'label' : 'Maxlength',
						'value' : '',
						'description' : ''
					},
					'autocomplete' : {
						'label' : 'Auto-complete',
						'value' : '',
						'description' : ''
					},
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'required' : {
						'label' : 'Required',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'datepicker' : {
						'label' : 'Date-picker',
						'value' : '',
						'description' : ''
					},
					'datetimepicker' : {
						'label' : 'Date-time-picker',
						'value' : '',
						'description' : ''
					},
					'pattern' : {
						'label' : 'Pattern',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},				
				'radio' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'required' : {
						'label' : 'Required',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'checkbox' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'required' : {
						'label' : 'Required',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'textarea' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'placeholder' : {
						'label' : 'Placeholder',
						'value' : '',
						'description' : ''
					},
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'size' : {
						'label' : 'Size',
						'value' : '',
						'description' : ''
					},
					'maxlength' : {
						'label' : 'Maxlength',
						'value' : '',
						'description' : ''
					},
					'required' : {
						'label' : 'Required',
						'value' : '',
						'description' : ''
					},
					'rows' : {
						'label' : 'Rows',
						'value' : '',
						'description' : ''
					},
					'cols' : {
						'label' : 'Cols',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'select' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'options' : {
						'label' : 'Options',
						'value' : '',
						'description' : ''
					},
					'required' : {
						'label' : 'Required',
						'value' : '',
						'description' : ''
					},
					'multiple' : {
						'label' : 'Multiple',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},					
				'submit' : {
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'size' : {
						'label' : 'Size',
						'value' : '',
						'description' : ''
					},
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'file' : {
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'placeholder' : {
						'label' : 'Placeholder',
						'value' : '',
						'description' : ''
					},
					'size' : {
						'label' : 'Size',
						'value' : '',
						'description' : ''
					},					
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'required' : {
						'label' : 'Required',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},					
					'pattern' : {
						'label' : 'Pattern',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'editor-form' : {
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'div' : {
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. none or underline'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'bullet' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'label' : {
						'label' : 'Label',
						'value' : '',
						'description' : 'Text of Label'
					},
					'Name' : {
						'label' : 'Name',
						'value' : '',
						'description' : 'Name of Label'
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : 'Description of field types'
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'list-style' : {
								'label' : 'List-style',
								'value' : '',
								'description' : 'Ex. disc or circle'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'barcode' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'Name' : {
						'label' : 'Name',
						'value' : '',
						'description' : 'Name of Label'
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : 'Description of field types'
					},
					'data-barcode-type' : {
						'label' : 'Data-Barcode-Type',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'display' : {
								'label' : 'Display',
								'value' : '',
								'description' : 'Ex. block or inline-block or none'
							},
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000 or red'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 100px or 100'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 100'
							}
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'image' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'Name' : {
						'label' : 'Name',
						'value' : '',
						'description' : 'Name of Label'
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : 'Description of field types'
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'image' : {
						'label' : 'Data-Image',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'display' : {
								'label' : 'Display',
								'value' : '',
								'description' : 'Ex. block or inline-block or none'
							},
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'simple-signature' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'Name' : {
						'label' : 'Name',
						'value' : '',
						'description' : 'Name of Label'
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : 'Description of field types'
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'display' : {
								'label' : 'Display',
								'value' : '',
								'description' : 'Ex. block or inline-block or none'
							},
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'inking-overlay' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'Name' : {
						'label' : 'Name',
						'value' : '',
						'description' : 'Name of Label'
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : 'Description of field types'
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'display' : {
								'label' : 'Display',
								'value' : '',
								'description' : 'Ex. block or inline-block or none'
							},
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'date-picker' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'placeholder' : {
						'label' : 'Placeholder',
						'value' : '',
						'description' : ''
					},
					'size' : {
						'label' : 'Size',
						'value' : '',
						'description' : ''
					},
					'maxlength' : {
						'label' : 'Maxlength',
						'value' : '',
						'description' : ''
					},
					'autocomplete' : {
						'label' : 'Auto-complete',
						'value' : '',
						'description' : ''
					},
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'required' : {
						'label' : 'Required',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'pattern' : {
						'label' : 'Pattern',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'date-time-picker' : {
					'data-persistent' : {
						'label' : 'Data-Persistent',
						'value' : '',
						'description' : 'Persistent Pattern list'
					},
					'data-event' : {
						'label' : 'Data-Event',
						'value' : '',
						'description' : 'Plugin event list'
					},
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : ''
					},
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'data-description' : {
						'label' : 'Data-Description',
						'value' : '',
						'description' : ''
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'placeholder' : {
						'label' : 'Placeholder',
						'value' : '',
						'description' : ''
					},
					'size' : {
						'label' : 'Size',
						'value' : '',
						'description' : ''
					},
					'maxlength' : {
						'label' : 'Maxlength',
						'value' : '',
						'description' : ''
					},
					'autocomplete' : {
						'label' : 'Auto-complete',
						'value' : '',
						'description' : ''
					},
					'readonly' : {
						'label' : 'Read-only',
						'value' : '',
						'description' : ''
					},
					'required' : {
						'label' : 'Required',
						'value' : '',
						'description' : ''
					},
					'value' : {
						'label' : 'Value',
						'value' : '',
						'description' : ''
					},
					'pattern' : {
						'label' : 'Pattern',
						'value' : '',
						'description' : ''
					},
					'data-condition' : {
						'label' : 'Data-Condition',
						'value' : '',
						'description' : 'Ex : '
					},
					'data-group-name' : {
						'label' : 'Data-group-name',
						'value' : '',
						'description' : 'Ex : '
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. underline or none'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				},
				'group' : {
					'id' : {
						'label' : 'ID',
						'value' : '',
						'description' : ''
					},
					'name' : {
						'label' : 'Name',
						'value' : '',
						'description' : 'Ex : Data group name'
					},
					'class' : {
						'label' : 'Class',
						'value' : '',
						'description' : ''
					},
					'alt' : {
						'label' : 'Alt',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'title' : {
						'label' : 'Title',
						'value' : '',
						'description' : 'Ex : abc'
					},
					'style' :{
						'label' : 'Style',
						'value' : {
							'background-color' : {
								'label' : 'Background-Color',
								'value' : '',
								'description' : 'Ex. #000000 or black'
							},
							'border' : {
								'label' : 'Border',
								'value' : '',
								'description' : 'Ex. 1px solid #ffffff'
							},
							'margin' : {
								'label' : 'Margin',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'padding' : {
								'label' : 'Padding',
								'value' : '',
								'description' : 'Ex. 5px or 5px 2px 3px 5px'
							},
							'color' : {
								'label' : 'Color',
								'value' : '',
								'description' : 'Ex. #000000'
							},
							'font-size' : {
								'label' : 'Font-size',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'font-family' : {
								'label' : 'Font-family',
								'value' : '',
								'description' : 'Ex. arial, sans-serif'
							},
							'font-weight' : {
								'label' : 'Font-weight',
								'value' : '',
								'description' : 'Ex. bold'
							},
							'font-style' : {
								'label' : 'Font-style',
								'value' : '',
								'description' : 'Like. italic or normal'
							},
							'text-decoration' : {
								'label' : 'Text-decoration',
								'value' : '',
								'description' : 'Like. none or underline'
							},
							'text-align' : {
								'label' : 'Text-align',
								'value' : '',
								'description' : 'Ex. left'
							},
							'line-height' : {
								'label' : 'Line-height',
								'value' : '',
								'description' : 'Ex. 12px'
							},
							'letter-spacing' : {
								'label' : 'Letter-spacing',
								'value' : '',
								'description' : 'Ex. 2px'
							},
							'height' : {
								'label' : 'Height',
								'value' : '',
								'description' : 'Ex. 50px or auto'
							},
							'width' : {
								'label' : 'Width',
								'value' : '',
								'description' : 'Ex. 100px or 50%'
							}							
						},
						'description' : 'Css stylesheet attributes'
					}
				}
			}
		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
jQuery(document).ready(function($){
	
});