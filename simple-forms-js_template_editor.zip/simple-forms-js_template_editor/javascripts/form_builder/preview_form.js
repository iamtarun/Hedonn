/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD
 * @ Dependency : "common.js"
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */

preview_form = {};

(function($) {
	
		preview_form = {
			
			/*********
			 * @ Desc: Initialize default function with page load. Define the different types of action perform on document.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			init: function() {
				
				var options = {
				  bgColour : '#ffffff',
				  drawOnly : true
				};
				$('.form-simple-signature').find('.sigPad').signaturePad(options);
				//$(".form-inking-overlay").hide();
				
				/*********
				 * @ Desc: Save the form value and Make url of data persistent and save it via ajax request.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					submit: function (e) {
						e.preventDefault();
						//console.log($(this).serialize());
						var valid = true;										
						var paramsAttributes = new Array();
						$('div.form-row').each(function() {
							var controlId = $(this).attr('id');
							var selObj = $(this).children(':first');
							
							var attributes = {}; 

							$.each(selObj[0].attributes, function(index, attr) {
								if(attr.name != 'style' 
									&& attr.name != 'class' 
									&& attr.name != 'label' 
									&& attr.name != 'value') {
									attributes[ attr.name ] = attr.value;
									if(attr.name == 'id') {
										var tagname = common.getTagName($('#' + attr.value));
										attributes[ 'data-tag' ] = tagname;
										var dataType = $('#' + attr.value).attr('data-type');
										if(dataType == undefined) {
											attributes[ 'value' ] = $('#' + attr.value).val();
										} else {
											switch(dataType) {
												case 'inking-overlay':
													attributes[ 'value' ] = $('#' + attr.value).find('input.output').val();
													break;
												case 'simple-signature':
													attributes[ 'value' ] = $('#' + attr.value).find('input.output').val();
													break;
												case 'image':
													attributes[ 'value' ] = $('#' + attr.value).val();
													break;
												case 'barcode':
													attributes[ 'value' ] = $('#' + attr.value).val();
													break;
											}
										}
									}
								}
								
							});
							
							if(common.len(attributes) > 0) {
								if(attributes.name == 'email') {
									if(!common.validate(attributes) && valid) {
										valid = false;
									}
								} else {
									if(attributes.hasOwnProperty('required') && !common.validate(attributes) && valid) {
										valid = false;
									}
								}
							}
							
							paramsAttributes.push({controls:attributes});
							
						});
											
						var finalFormJson = JSON.stringify(paramsAttributes);
						
						$('.form_display').find('.form-simple-signature').each(function() {
							var signature = $(this).find('.sigPad input[type="hidden"].output').val();
							if(signature == '' || signature == undefined) {
								if(confirm('Would You like to sign before submit!')) {
									$('.form_display').find(".form-inking-overlay").slideToggle(500);
									valid = false;
								} else {
									valid = false;
								}
							}						
						});
						
						if(valid) {
							alert("Template Form is Ok!");
						}
					
					}																		
				}, 'form');
				
				/*********
				 * @ Desc: Click functin on "input[type=checkbox]" class, In this action, Set checked attributes true or false
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						if($(this).is(":checked") == false) {
							$(this).removeAttr('checked');
						} else {
							$(this).prop('checked', true);
						}
					}																		
				}, 'input[type=checkbox], input[type=radio]');							
				
			},
			
			/*********
			 * @ Desc: Load the template form by ajax request
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			loadDocument: function() {
				try {
					var documentUrl = document.URL;				
					var urlSplit = documentUrl.split('#');
					var parameters = urlSplit[1];
					var id = common.getParameterByName("id");
					var libraryType = common.getParameterByName("library_type");
					
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('id', id);							
					templateObj.setValue('library_type', libraryType);							
					templateObj.setValue('target', 'show_form_data');							
					templateObj.showTemplateForm();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Validate the form before save based on conditions.
			 * @ Params: Object
			 * @ Returns: boolean
			/*************/
			renderForm: function(data) {
				try {
					$('#form_content_load').html(data);
					preview_form.loadDefaultDocument();
					common.dataCondition();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},		
			
			/*********
			 * @ Desc: Set default value with page load.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			loadDefaultDocument: function() {
				try {
					var elementHeight = {};
					
					$('.form_display div.form-row').each(function(index) {
						var liId = $(this).attr('id');
						elementHeight[ parseInt($('#' + liId).css('top'), 10) ] = index;					
					});
					
					var maxHeight = common.maxKey(elementHeight);

					//$('.form_display').css(
					//	'height', maxHeight + 60
					//);
					
					$('img.selected_image').each(function() {
						var height = $(this).attr('height');
						var width = $(this).attr('width');
						var path = $(this).attr('src');
						if(path != '') {
							var imageNameArr = path.split('/');
							var imageName = imageNameArr.pop();
							if(imageName != '') {
								var imageArray = imageName.split('.');
								imageNameNew = imageArray[0] + '_' + parseInt(width) + '_' + parseInt(height) + "." + imageArray[1];
								imagePathNew = baseUrl + '/images/upload_template_image/' + imageNameNew;
								$(this).attr('src', imagePathNew);
								$(this).attr('alt', imageNameNew);
							}
						}
					});			
					
					$('.form_display div.form-row').each(function(index) {
						var liId = $(this).attr('id');
						var inputElement = $('#' + liId).children(':first');
						var type = common.getTagName(inputElement);
						if(type == 'submit') {
							$('.form_display').css(
								'width', $(inputElement).attr('data-form-width')
							);
							$('.form_display').css(
								'height', $(inputElement).attr('data-form-height')
							);
							$('#form_content').css(
								'width', $(inputElement).attr('data-form-width')
							);
							$('#form_content').css(
								'height', $(inputElement).attr('data-form-height')
							);
						}
						
						var controlsElement = $(this).children(':first');
						if($(controlsElement).attr('autosuggest') == 'enabled' 
							&& $(controlsElement).attr('data-persistent') != undefined
							&& $(controlsElement).attr('data-persistent') != '') {
							var dataPersistent = $(controlsElement).attr('data-persistent');
							var templateObj = new Template();
							templateObj.setValue('async', Template.async);
							templateObj.setValue('data_persistent', dataPersistent);
							templateObj.setValue('auto_suggest_element_id', liId);		
							templateObj.setValue('target', 'auto_suggest_load');							
							templateObj.getPersistentAutoSuggest();
						}
						
						common.collectElementByGroupName(controlsElement);
						
					});
					
					if(dataGroupArray.length > 0) {
						groupElements = common.seperateElementByGroupName(dataGroupArray);
						if(common.len(groupElements) > 0) {
							common.renderGroupElements(groupElements);						
						}
					}
					
					$('.form_display').find('.form-inking-overlay').each(function() {
						$('#show_inking_overlay_header').show();
						var controlsID = $(this);					
						var height = $('.form_display').height();
						var width = $('.form_display').width();
						$(this).height(height);
						$(this).width(width);
						$(this).parent().width(width);
						$(this).parent().height(height);
						$(this).parent().css('left', 0);
						$(this).parent().css('top', 0);
						$(controlsID).find('canvas')
							.attr('width', (width - 2))
							.attr('height', height);
						$(controlsID).children(':first')
							.width(width)
							.height(height);
						$(controlsID).find('.sigPad').width(width);
						$(controlsID).find('.sigNav').width(width);
						$(controlsID).find('.sigWrapper').height(height);
					});
					
					$('.form_display div.form-row').find('.form-date-picker').each(function() {
						$(this).removeClass('hasDatepicker');
						common.applyDatePicker(this);
					});
					
					$('.form_display div.form-row').find('.form-date-time-picker').each(function() {
						$(this).removeClass('hasDatepicker');
						common.applyDateTimePicker(this);
					});					
					
					$('.form_display div.form-row').find('.form-textbox').each(function() {
						if($(this).hasClass('hasDatepicker') && $(this).attr('datetime-picker') == 'datetimepicker') {
							$(this).removeClass('hasDatepicker');
							common.applyDateTimePicker(this);
						}
					});
					
					$('.form_display div.form-row').find('.form-textbox').each(function() {
						if($(this).hasClass('hasDatepicker') && $(this).attr('datepicker') == 'datepicker') {
							$(this).removeClass('hasDatepicker');
							common.applyDatePicker(this);
						}
					});
					
					$('.form_display').find(".form-row").css('z-index', 1);					
					$('.form_display').find(".form-inking-overlay").parent().css('z-index', 0);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			}		
			
		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
jQuery(document).ready(function($){
	preview_form.init();
	preview_form.loadDocument();
});