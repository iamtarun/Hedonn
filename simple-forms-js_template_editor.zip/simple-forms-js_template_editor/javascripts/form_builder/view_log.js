/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD
 * @ Dependency : "template.js", "common.js"
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */

view_log = {};

(function($) {
	
		view_log = {
			
			/*********
			 * @ Desc: Initialize default function with page load. Define the different types of action perform on document.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			init: function() {								
				
			},
			
			/*********
			 * @ Desc: Load the template form by ajax request
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			loadDocument: function() {
				try {
					var documentUrl = document.URL;				
					var urlSplit = documentUrl.split('#');
					var parameters = urlSplit[1];
					var id = common.getParameterByName("id");
					
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('id', id);
					templateObj.setValue('target', 'show_activity_log');							
					templateObj.showActivityLog();
					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Validate the form before save based on conditions.
			 * @ Params: Object
			 * @ Returns: boolean
			/*************/
			renderForm: function(data) {
				try {
					$('#view_activity_log').html(data);
					view_log.loadDefaultDocument();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},		
			
			/*********
			 * @ Desc: Set default value with page load.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			loadDefaultDocument: function() {
				try {
					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			}		
			
		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
jQuery(document).ready(function($){
	view_log.init();
	view_log.loadDocument();
});