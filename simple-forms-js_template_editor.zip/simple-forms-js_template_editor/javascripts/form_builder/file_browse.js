/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD
 * @ Dependency : "common.js"
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */

file_browse = {};

(function($) {
	
		file_browse = {
			
			/*********
			 * @ Desc: Initialize default function with page load. Define the different types of action perform on document.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			init: function() {								
				
			},
			
			/*********
			 * @ Desc: Load the template form by ajax request
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			loadDocument: function() {
				try {
					var documentUrl = document.URL;				
					var urlSplit = documentUrl.split('#');
					var parameters = urlSplit[1];
					var id = common.getParameterByName("id");
					$('#view_file_iframe').attr('src', baseUrl + "/api/template/view_file/" + id).load(function() {
										
					});
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Validate the form before save based on conditions.
			 * @ Params: Object
			 * @ Returns: boolean
			/*************/
			renderForm: function(data) {
				try {
					console.log(data);
					file_browse.loadDefaultDocument();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},		
			
			/*********
			 * @ Desc: Set default value with page load.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			loadDefaultDocument: function() {
				try {
					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			}		
			
		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
jQuery(document).ready(function($){
	file_browse.init();
	file_browse.loadDocument();
});