/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD
 * @ Dependency : "common.js"
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */
template_form_edit = {};

(function($) {
	
		template_form_edit = {				
		
			/*********
			 * @ Desc: Initialize default function with page load. Define the different types of action perform on document.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			init: function() {				
				
				/*********
				 * @ Desc: Search the template form using keyword via ajax request.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					submit: function (e) {
					e.preventDefault();
					var valid = true;
					var keyword = $('#keyword').val();
					if(keyword == '') {
						$('#keyword')
							.focus()
							.addClass('form-builder-error');
						//valid = false;
					} else {
						$('#keyword')
							.removeClass('form-builder-error');
					}
					var finalFormJson = $(this).serializeArray();
					if(valid) {
						var templateObj = new Template();
						templateObj.setValue('async', Template.async);
						templateObj.setValue('url', $(this).attr('action'));							
						templateObj.setValue('data', finalFormJson);
						templateObj.setValue('target', 'template_form_list');							
						templateObj.getTemplateFormList();
					}
					
					}																		
				}, 'form');
				
				/*********
					 * @ Desc: Click function on anchor tag for pagination of form template listing.
					 * @ Params: N/A
					 * @ Returns: N/A
					/*************/
					$(document).on({
						click: function (e) {
							e.stopPropagation();
							var templateObj = new Template();
							templateObj.setValue('async', Template.async);
							templateObj.setValue('url', this.href + '&keyword=' + $('#keyword').val() + '&template_id=' + $('#template_id').val() + '&library_type=' + $('#library_type').val());
							templateObj.setValue('target', 'template_form_list');							
							templateObj.templateFormSearchPagination();
							//$.getScript(this.href + '&keyword=' + $('#keyword').val() + '&template_id=' + $('#template_id').val() + '&library_type=' + $('#library_type').val());
							return false;														
						}
					}, '#form_template_list .pagination a.search-pagination');
				
			},
			
			/*********
			 * @ Desc: load doucment by searching.
			 * @ Params: Object
			 * @ Returns: N/A
			/*************/
			loadDocumentSearch: function() {
				try {
					var documentUrl = document.URL;				
					var urlSplit = documentUrl.split('#');
					var parameters = urlSplit[1];
					var id = common.getParameterByName("id");
					var libraryType = common.getParameterByName("library_type");
					$('#template_id').val(id);				
					$('#library_type').val(libraryType);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: render list of the template.
			 * @ Params: data of the template list
			 * @ Returns: N/A
			/*************/			
			renderTemplateFormList: function(data) {
				try {
					$("#tabs-centrally").html(data);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: publish form of user.
			 * @ Params: form type, active tab index, data form, id of the template form
			 * @ Returns: N/A
			/*************/
			publishForm: function(type, activeTab, dataForm, dataId) {
				try {
					$("#tabs").tabs({ active: activeTab });
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('library_type', type);
					templateObj.setValue('data_form', dataForm);
					templateObj.setValue('data_id', dataId);
					templateObj.setValue('target', 'publish_form');							
					templateObj.publishForm();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			}
			
		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
jQuery(document).ready(function($){

	template_form_edit.init();	
	template_form_edit.loadDocumentSearch();	
	
});