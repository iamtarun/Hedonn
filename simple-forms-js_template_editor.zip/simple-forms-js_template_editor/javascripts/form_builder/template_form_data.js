/* 
 * @ Created On : April 2013
 * @ Project : simplifyMD-P1
 * @ Desc : Development Purpose for form builder in simplifyMD
 * @ Dependency : "common.js"
 * @ Author : Ajit Kumar 2
 * @ Email ID : ajitk2@chetu.com
 * @ Developed By : Ajit Kumar
 *
 */
 
template_form_data = {};

(function($) {
	
		template_form_data = {
		
			/*********
			 * @ Desc: Initialize default function with page load. Define the different types of action perform on document.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			init: function() {
				//$(".form-inking-overlay").hide();
				
				/*********
				 * @ Desc: Save the form value and Make url of data persistent and save it vai ajax request.
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					submit: function (e) {
						e.preventDefault();
						var valid = true;
						var paramsAttributes = new Array();
						$('div.form-row').each(function() {
							var controlId = $(this).attr('id');
							var selObj = $(this).children(':first');
							
							var attributes = {}; 
							var styleAttributes = {};
							$.each(selObj[0].attributes, function(index, attr) {
								if(attr.name != 'style' 
									&& attr.name != 'class' 
									&& attr.name != 'label' 
									&& attr.name != 'value') {
									attributes[ attr.name ] = attr.value;
									if(attr.name == 'id') {
										var tagname = common.getTagName($('#' + attr.value));
										attributes[ 'data-tag' ] = tagname;
										var dataType = $('#' + attr.value).attr('data-type');
										var elementStyle = $('#' + attr.value).parent().attr('style');
										
										styleAttributes[ attr.value ] = elementStyle;
										
										if(dataType == undefined) {
											attributes[ 'value' ] = $('#' + attr.value).val();
										} else {
											switch(dataType) {
												case 'inking-overlay':
													attributes[ 'value' ] = $('#' + attr.value).find('input.output').val();
													break;
												case 'simple-signature':
													attributes[ 'value' ] = $('#' + attr.value).find('input.output').val();
													break;
												case 'image':
													attributes[ 'value' ] = $('#' + attr.value).val();
													break;
												case 'barcode':
													attributes[ 'value' ] = $('#' + attr.value).val();
													break;
												case 'date-picker':
													attributes[ 'value' ] = $('#' + attr.value).val();
													break;
												case 'date-time-picker':
													attributes[ 'value' ] = $('#' + attr.value).val();
													break;
												case 'file':
													attributes[ 'value' ] = $('#' + attr.value).val();
													break;
											}
										}
									}
								}
								
							});						
							
							if(common.len(attributes) > 0) {
								if(attributes.name == 'email') {
									if(!template_form_data.validate(attributes) && valid) {
										valid = false;
									}
								} else {
									if(attributes.hasOwnProperty('required') && !template_form_data.validate(attributes) && valid) {
										valid = false;
									}
								}
							}
							
							//paramsAttributes.push({controls:attributes, style:styleAttributes});
							paramsAttributes.push({controls:attributes});
							
						});
						
						var finalFormJson = JSON.stringify(paramsAttributes);
						
						$('.form_display').find('.form-simple-signature').each(function() {
							var signature = $(this).find('.sigPad input[type="hidden"].output').val();
							if(signature == '' || signature == undefined) {
								if(confirm('Would You like to sign before submit!')) {
									valid = false;
								} else {
									valid = false;
								}
							}						
						});
						
						//return false;
						if(valid) {
							var templateObj = new Template();
							templateObj.setValue('async', Template.async);
							templateObj.setValue('template_id', $('#template_id').val());							
							templateObj.setValue('data_json', finalFormJson);							
							templateObj.setValue('patient_id', $('#patient_id').val());							
							templateObj.setValue('library_type', $('#library_type').val());							
							templateObj.setValue('file_upload', $('#current_file_upload').val());							
							templateObj.setValue('file_upload_element', $('#current_file_upload_ids').val());							
							templateObj.setValue('target', 'save_form_data');							
							templateObj.saveTemplateForm();
						}
					
					}																		
				}, 'form');
				
				/*********
				 * @ Desc: Click functin on "input[type=checkbox]" class, In this action, Set checked attributes true or false
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						if($(this).is(":checked") == false) {
							$(this).removeAttr('checked');
						} else { 
							$(this).attr('checked', true);
						}
					}																		
				}, 'input[type=checkbox]');
				
				/*********
				 * @ Desc: Click functin on "input[type=radio]" class, In this action, Set checked attributes true or false
				 * @ Params: N/A
				 * @ Returns: N/A
				/*************/
				$(document).on({
					click: function (e) {
						e.stopPropagation();
						if($(this).is(":checked") == true) {
							var name = $(this).attr('name');
							var id = $(this).attr('id');
							$('[name^=' + name + ']').removeAttr('checked');
							$(this).attr('checked', true);
							$(this).prop('checked', true);
						}
					}																		
				}, 'input[type=radio]');
				
			},
			
			/*********
			 * @ Desc: Validate the form before save based on conditions.
			 * @ Params: Object
			 * @ Returns: boolean
			/*************/
			renderForm: function(data) {
				try {
					$('#form_content_load').html(data);
					template_form_data.loadDefaultDocument();
					template_form_data.renderTemplate(form_values, template_files);
					common.dataCondition();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Render the response on dialog box pop up after save.
			 * @ Params: Object
			 * @ Returns: N/A
			/*************/
			renderFormData: function(data) {
				try {
					//console.log(data);				
					if(common.len(data) > 0) {
						if(data.template_form_id != '' && data.template_form_id != undefined) {							
							template_form_data.dialogError('template-form-success');							
							$('#template_form_id').val(data);
							$('#current_file_upload').val('');
							$('#current_file_upload_ids').val('');
							template_form_data.setInkingOverlayTop();
						} else {
							template_form_data.dialogError('template-form-error');
						}
						
						if(data.template_files != undefined) {
							if(common.len(data.template_files) > 0) {
								$('.form-file').each(function(index, item){
									if($(this).next().html() != '') {
										var id = $(this).attr('id');
										if(data.template_files[ id ] != undefined) {										
											$(this).attr('data-file-id', data.template_files[ id ]);
											$(this).parent().find('#file_upload_' + id).remove();
											$(this).parent().find('#view_file_upload_' + id).remove();
											$(this).parent().append('<div id="view_file_upload_' + id + '" style="position:absolute;left:' + ($(this).outerWidth() + 5) +'px;top:6px;"><a href="' + baseUrl +'/api/template/view_file/' + data.template_files[ id ] + '" data-view-url="' + baseUrl +'/api/template/view_file/' + data.template_files[ id ] + '" target="_blank" class="preview-file"><img src="images/form_builder/blank.gif" alt="View file" width="14" height="10"/></a></div>');
										}
									}
								});
							} else {
								template_form_data.dialogError('template-file-error');						
							}
						}
					} else {
						template_form_data.dialogError('template-form-error');
					}					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Show the dialog box error message based on the passed type
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			dialogError: function(type) {
				try {
					switch(type) {
						case 'template-form-success':
							$('.ui-dialog-title').html('Saved!');
							$('#dialog-modal')
								.html('<div id="information" class="alert alert-success ">Template form was Successfully Saved!</div><center><input type="button" class="btn dialog_close" value="Ok" align="center"></center>');
						break;
						case 'template-form-error':
							$('.ui-dialog-title').html('Error!');
							$('#dialog-modal')
								.html('<div id="information" class="alert alert-error ">Template form was not Successfully Saved!</div><center><input type="button" class="btn dialog_close" value="Ok" align="center"></center>');
						break;
						case 'template-file-error':
							$('.ui-dialog-title').html('Error!');
							$('#dialog-modal')
								.html('<div id="information" class="alert alert-error ">Template form and Files were not Successfully Saved! or File is too large file!</div><center><input type="button" class="btn dialog_close" value="Ok" align="center"></center>');
						break;				
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Load the template form by ajax request
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			loadDocument: function() {
				try {
					var documentUrl = document.URL;				
					var urlSplit = documentUrl.split('#');
					var parameters = urlSplit[1];
					var id = common.getParameterByName("id");
					var libraryType = common.getParameterByName("library_type");
					var formId = common.getParameterByName("form_id");
					var newForm = common.getParameterByName("new_form");
					
					var templateObj = new Template();
					templateObj.setValue('async', Template.async);
					templateObj.setValue('id', id);							
					templateObj.setValue('library_type', libraryType);							
					templateObj.setValue('form_id', (formId != '') ? formId : '');							
					templateObj.setValue('new_form', (newForm != '') ? newForm : '');							
					templateObj.setValue('target', 'show_form_new_edit');							
					templateObj.showTemplateForm();
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},

			/*********
			 * @ Desc: Set default value with page load.
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			loadDefaultDocument: function() {
				try {
					var elementHeight = {};
					
					$('.form_display div.form-row').each(function(index) {
						var liId = $(this).attr('id');
						elementHeight[ parseInt($('#' + liId).css('top'), 10) ] = index;					
					});
					
					var maxHeight = common.maxKey(elementHeight);

					//$('.form_display').css(
					//	'height', maxHeight + 60
					//);
					
					$('img.selected_image').each(function() {
						var height = $(this).attr('height');
						var width = $(this).attr('width');
						var path = $(this).attr('src');
						if(path != '') {
							var imageNameArr = path.split('/');
							var imageName = imageNameArr.pop();
							if(imageName != '') {
								var imageArray = imageName.split('.');
								imageNameNew = imageArray[0] + '_' + parseInt(width) + '_' + parseInt(height) + "." + imageArray[1];
								imagePathNew = baseUrl + '/images/upload_template_image/' + imageNameNew;
								$(this).attr('src', imagePathNew);
								$(this).attr('alt', imageNameNew);
							}
						}
					});			
					
					$('.form_display div.form-row').each(function(index) {
						var liId = $(this).attr('id');
						var inputElement = $('#' + liId).children(':first');
						var type = common.getTagName(inputElement);
						if(type == 'submit') {
							$('.form_display').css(
								'width', $(inputElement).attr('data-form-width')
							);
							$('.form_display').css(
								'height', $(inputElement).attr('data-form-height')
							);
							$('#form_content').css(
								'width', $(inputElement).attr('data-form-width')
							);
							$('#form_content').css(
								'height', $(inputElement).attr('data-form-height')
							);
						}
						
						var controlsElement = $(this).children(':first');
						if($(controlsElement).attr('autosuggest') == 'enabled' 
							&& $(controlsElement).attr('data-persistent') != undefined 
							&& $(controlsElement).attr('data-persistent') != '') {
							var dataPersistent = $(controlsElement).attr('data-persistent');
							var templateObj = new Template();
							templateObj.setValue('async', Template.async);
							templateObj.setValue('async', Template.async);
							templateObj.setValue('data_persistent', dataPersistent);		
							templateObj.setValue('auto_suggest_element_id', liId);		
							templateObj.setValue('target', 'auto_suggest_load');							
							templateObj.getPersistentAutoSuggest();
						}
						
						if($(controlsElement).attr('data-type') == 'file') {
							templateObj = new Template();
							templateObj.setValue('current_element', controlsElement);
							templateObj.setValue('template_id', $('#template_id').val());
							templateObj.uploadTemplateFile();
						}
						
						common.collectElementByGroupName(controlsElement);
						
					});
					
					if(dataGroupArray.length > 0) {
						groupElements = common.seperateElementByGroupName(dataGroupArray);
						if(common.len(groupElements) > 0) {
							common.renderGroupElements(groupElements);						
						}
					}
					
					$('.form_display').find('.form-inking-overlay').each(function() {
						$('#show_inking_overlay_header').show();
						var optionss = {
						  drawOnly : true,
						  penColour : '#145394',
						  validateFields : false						  
						};
						$(this).find('.sigPad').signaturePad(optionss);
						var height = $('.form_display').height();
						var width = $('.form_display').width();
						$(this).append('<div id="stop_overlay" style="position:absolute; top:0px; left:0px;"></div>');
						$('#stop_overlay').css('width', width);
						$('#stop_overlay').css('height', height);
						
						var controlsID = $(this);					
						
						$(this).height(height);
						$(this).width(width);
						$(this).parent().width(width);
						$(this).parent().height(height);
						$(this).parent().css('left', 0);
						$(this).parent().css('top', 0);
						$(controlsID).find('canvas')
							.attr('width', (width - 2))
							.attr('height', height);
						$(controlsID).children(':first')
							.width(width)
							.height(height);
						$(controlsID).find('.sigPad').width(width);
						$(controlsID).find('.sigNav').width(width);
						$(controlsID).find('.sigWrapper').height(height);					
					});
					
					$('.form_display div.form-row').find('.form-date-picker').each(function() {
						$(this).removeClass('hasDatepicker');
						common.applyDatePicker(this);
					});
					
					$('.form_display div.form-row').find('.form-date-time-picker').each(function() {
						$(this).removeClass('hasDatepicker');
						common.applyDateTimePicker(this);
					});
					
					$('.form_display div.form-row').find('.form-textbox').each(function() {
						if($(this).hasClass('hasDatepicker') && $(this).attr('datetime-picker') == 'datetimepicker') {
							$(this).removeClass('hasDatepicker');
							common.applyDateTimePicker(this);
						}
					});
					
					$('.form_display div.form-row').find('.form-textbox').each(function() {
						if($(this).hasClass('hasDatepicker') && $(this).attr('datepicker') == 'datepicker') {
							$(this).removeClass('hasDatepicker');
							common.applyDatePicker(this);
						}
					});
					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: get the group Element row after pasing the JSON.
			 * @ Params: JSON, group name
			 * @ Returns: N/A
			/*************/
			getGroupElementRows: function(formValuesJson, groupItemName) {
				try {
					var groupElementByRow = {};
									
					$.each(formValuesJson, function(index, item){
						if(groupItemName == item.controls["data-group-name"]) {
							if(item.controls["data-row"] != undefined) {
								if( Object.prototype.toString.call( groupElementByRow[ item.controls["data-row"] ] ) !== '[object Array]' ) groupElementByRow[ item.controls["data-row"] ] = [];
								groupElementByRow [ item.controls["data-row"] ] [ index ] = item.controls.value;							
							}
						}
					});
					
					var newGroupElementArray = {};
					if(common.len(groupElementByRow) > 0) {
						$.each(groupElementByRow, function(index, elements) {
							var newGroup = {};
							var k = 0;
							$.each(elements, function(i, item) {							
								if(item != undefined) {
									newGroup[ k ] = item;
									k++;
								}
							});
							newGroupElementArray[ index ] = newGroup;
						});				
					}
					
					return newGroupElementArray;
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},

			/*********
			 * @ Desc: Set the fields value after pasing the JSON.
			 * @ Params: JSON
			 * @ Returns: N/A
			/*************/
			renderTemplate: function(formValuesJson, templateFileJson) {
				try {
					if(formValuesJson != undefined) {
						var groupItem = {};
						$.each(formValuesJson, function(index, item){
						
							var itemTag = item.controls["data-tag"];
							var itemVal = item.controls.value;						
							var itemId = item.controls.id;
							var itemName = item.controls.name;
							var itemType = item.controls.type;
							var itemDataType = item.controls["data-type"];						
							
							if(itemDataType == undefined) {
								if(itemTag == 'checkbox' || itemTag == 'radio') {
									if (item.controls.checked == 'checked') { 
										$('#' + itemId).attr('checked', true);
									} else {
										$('#' + itemId).removeAttr('checked');
									}
								} else if(itemTag == 'select') {
									$('#' + itemId).find("option[value='" + itemVal +"']").attr("selected","selected");
								} else if(itemTag == 'textarea') {
									$('#' + itemId).html(itemVal);
								} else {
									$('#' + itemId).val(itemVal);
									$('#' + itemId).attr('value', itemVal);
								}
							} else {
								switch(itemDataType) {
									case 'simple-signature':
										var sig = itemVal;
										if(sig != "") {
											$('#' + itemId).find('.sigPad').signaturePad({displayOnly:true}).regenerate(sig);
										}
									break;
									case 'inking-overlay':
										var sig = itemVal;
										if(sig != "") {
											$('#' + itemId).find('.sigPad').signaturePad({displayOnly:true}).regenerate(sig);
										}
									break;
									case 'barcode':
									break;
									case 'image':
									break;
									case 'group':
										groupItem[ index ] = itemName;
									break;
									case 'date-picker':
										$('#' + itemId).val(itemVal);
										$('#' + itemId).attr('value', itemVal);
									break;
									case 'date-time-picker':
										$('#' + itemId).val(itemVal);
										$('#' + itemId).attr('value', itemVal);
									break;
								}
							}

						});		
						
						// generate to render group element
						if(common.len(groupItem) > 0) {
							$.each(groupItem, function(index, groupItemName) {
							
								var addOptionsCount = 0;
								var lastElementId = '';
								var currentGroups = '';
								
								var groupElementByRow = template_form_data.getGroupElementRows(formValuesJson, groupItemName);
								
								var groupElementRowCount = common.len(groupElementByRow);
								$('.addmore-group-' + groupItemName).attr('data-click-count', groupElementRowCount);
								
								if(groupElementRowCount > 0) {
									$.each(groupElementByRow, function(index, item) {
										if(common.len(groupElements) > 0) {
												
											$('div.form_display div.form-row a.remove-group').each(function(index) {
												if($(this).hasClass('remove-group-' + groupItemName)) {													
													lastElementId = $(this).attr('data-last-id');
												}
											});
											
											common.createGroupRow(groupElements, groupItemName, addOptionsCount, lastElementId, item);
											
										}
										addOptionsCount++;
									});								
								}								
							});							
						}
						
					}
					
					if(templateFileJson != undefined) {
						var fileID = {};
						$.each(templateFileJson, function(index, item) {							
							if(item.hasOwnProperty('template_file')) {
								fileID[ index ] = item.template_file.id;
							} else {
								fileID[ index ] = item.id;
							}							
						});	
						
						if(common.len(fileID) > 0) {
							$('.form-file').each(function(index, element){
								var id = $(this).attr('id');
								if(fileID[ index ] != undefined) {
									$(this).attr('data-file-id', fileID[ index ]);
									$(this).parent().append('<div id="view_file_upload_' + id + '" style="position:absolute;left:' + ($(this).outerWidth() + 5) +'px;top:6px;"><a href="' + baseUrl +'/api/template/view_file/' + fileID[ index ] + '" data-view-url="' + baseUrl +'/api/template/view_file/' + fileID[ index ] + '" target="_blank" class="preview-file"><img src="images/form_builder/blank.gif" alt="View file" width="14" height="10"/></a></div>');
								}
							});
						}
					}
					
					template_form_data.setInkingOverlayTop();
					
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Set the Inking overlay on top based on the overlay output
			 * @ Params: N/A
			 * @ Returns: N/A
			/*************/
			setInkingOverlayTop: function() {
				try {
					var overlay_output = $('.form_display').find(".form-inking-overlay").find('.output').val();
					if(overlay_output != '') {					
						$('.form_display').find(".form-row").css('z-index', 0);					
						$('.form_display').find(".form-inking-overlay").parent().css('z-index', 1);
					} else {
						$('.form_display').find(".form-row").css('z-index', 1);					
						$('.form_display').find(".form-inking-overlay").parent().css('z-index', 0);
					}
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Set the label of the file which is to be upload.
			 * @ Params: current element object, file
			 * @ Returns: N/A
			/*************/
			setFileLabel: function(elementIdObj, file) {
				try {
					$(elementIdObj).parent().find('#file_upload_' + $(elementIdObj).attr('id')).remove();
					$(elementIdObj).parent().find('#view_file_upload_' + $(elementIdObj).attr('id')).remove();
					$(elementIdObj).parent().append('<div id="file_upload_' + $(elementIdObj).attr('id') + '" style="position:absolute;left:' + ($(elementIdObj).outerWidth() + 5) +'px;top:6px;">' + file + '</div>');
				} catch (e) {
				   console.log(e.message, e.name);
				}
			},
			
			/*********
			 * @ Desc: Set the uploaded file going to submit
			 * @ Params: current element object, new file
			 * @ Returns: N/A
			/*************/
			setFileUploaded: function(elementId, newFileName) {
				try {
					Template.fileUploadObj[ elementId ] = newFileName;
					var i = 1;
					var newFiles = "";
					var newElementId = "";
					$.each(Template.fileUploadObj, function(index, item){
						var inc = (common.len(Template.fileUploadObj) == i) ? "" : ",";
						newFiles = newFiles + item + inc;
						newElementId = newElementId + index + inc;
						i++;
					});
					
					$('#current_file_upload').val(newFiles);
					$('#current_file_upload_ids').val(newElementId);
				} catch (e) {
				   console.log(e.message, e.name);
				}
			}
		};
		
})(jQuery);

/*********
 * @ Desc: Jquery ready function 
 * @ Params: N/A
 * @ Returns: N/A
/*************/
jQuery(document).ready(function($){
	template_form_data.init();
	template_form_data.loadDocument();	
});